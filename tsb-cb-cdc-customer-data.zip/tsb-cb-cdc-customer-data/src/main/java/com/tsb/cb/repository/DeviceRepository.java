package com.tsb.cb.repository;

import com.tsb.cb.model.DeviceRecord;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DeviceRepository extends CassandraRepository<DeviceRecord, String> {
}
