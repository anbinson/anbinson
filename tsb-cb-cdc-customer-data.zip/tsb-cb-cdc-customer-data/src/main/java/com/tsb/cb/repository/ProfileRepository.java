package com.tsb.cb.repository;

import com.tsb.cb.model.ProfileRecord;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProfileRepository extends CassandraRepository<ProfileRecord, String> {
}
