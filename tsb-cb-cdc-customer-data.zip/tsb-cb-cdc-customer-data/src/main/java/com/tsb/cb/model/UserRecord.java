package com.tsb.cb.model;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(value = "user")
@Data
@Builder
public class UserRecord {
    @PrimaryKey("user_id")
    private String userId;

    @Column("das_user")
    private String dasUser;
    @Column("numpersona")
    private String numpersona;
    @Column("hmac")
    private String hmac;
    @Column("hmac_created_at")
    private String hmacCreatedAt;
    @Column("hmac_device_id")
    private String hmacDeviceId;
}
