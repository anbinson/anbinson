package com.tsb.cb.processor;


import com.tsb.cb.model.DeviceRecord;
import com.tsb.cb.model.HmacRecord;
import com.tsb.cb.model.ProfileRecord;
import com.tsb.cb.model.UserRecord;
import com.tsb.cb.repository.DeviceRepository;
import com.tsb.cb.repository.HmacRepository;
import com.tsb.cb.repository.ProfileRepository;
import com.tsb.cb.repository.UserRepository;
import com.tsb.cb.schema.avro.PE11.PE11Customer;
import com.tsb.cb.schema.avro.ems.EmsUsersByUserId;
import com.tsb.cb.schema.avro.tbbvbsenrollments.DeviceByDASUser;
import com.tsb.cb.stream.schema.CustomerWriteHmacRequest;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.streams.kstream.KTable;
import org.slf4j.MDC;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.function.Consumer;

import javax.annotation.PostConstruct;

@Slf4j
@Service
@RequiredArgsConstructor
public class StreamProcessor {

    private final ProfileRepository profileRepository;
    private final DeviceRepository deviceRepository;
    private final UserRepository userRepository;
    private final HmacRepository hmacRepository;
    private final MeterRegistry meterRegistry;
    
    private Counter devicesInCounter; 
    private Counter devicesOutCounter;
    private Counter usersInCounter;
    private Counter usersOutCounter;
    private Counter profilesInCounter;
    private Counter profilesOutCounter;

    @PostConstruct
    public void init() {
    	log.info("Create and register metric counters with Meter registry");
    	devicesInCounter = Counter.builder("tsbcb_cdc_devices_in_total")
    								.description("Total number of input devices since process start")
    								.register(meterRegistry);
    	devicesOutCounter = Counter.builder("tsbcb_cdc_devices_out_total")
									.description("Total number of output devices since process start")
									.register(meterRegistry);
    	
    	usersInCounter = Counter.builder("tsbcb_cdc_users_in_total")
									.description("Total number of input users since process start")
									.register(meterRegistry);
    	usersOutCounter = Counter.builder("tsbcb_cdc_users_out_total")
									.description("Total number of output users since process start")
									.register(meterRegistry);
    	
    	profilesInCounter = Counter.builder("tsbcb_cdc_profiles_in_total")
									.description("Total number of input profiles since process start")
									.register(meterRegistry);
    	
    	profilesOutCounter = Counter.builder("tsbcb_cdc_profiles_out_total")
									.description("Total number of output profiles since process start")
									.register(meterRegistry);
    	
    }
    
    /**
     * Consume Users stream (from cdc) and store it in scylladb
     * PE11 Customers contain customer's data such as numpersona
     *
     * @return a stream of customer data
     */
    @Bean
    public Consumer<KTable<String, EmsUsersByUserId>> processUsersStream() {
        return input -> input
                .toStream()
                // filter (and trace) messages
                .filter((k, user) -> {
                    log.debug("Received a message from EmsUsersByUserId");
                    usersInCounter.increment();
                    return user != null &&
                            StringUtils.isNotBlank(user.getDASUSER()) &&
                            StringUtils.isNotBlank(user.getNUMPERSONA());
                })
                .foreach((k, user) -> {
                    // store the customer in db
                    if (userRepository.existsById(user.getUSERID())) {
                        userRepository.updateUser(user.getNUMPERSONA(), user.getDASUSER(), user.getUSERID());
                        log.debug("User updated in Scylladb");
                    } else {
                        userRepository.save(UserRecord.builder()
                                .dasUser(user.getDASUSER())
                                .numpersona(user.getNUMPERSONA())
                                .userId(user.getUSERID()).build());
                        log.debug("User inserted in Scylladb");                        
                    }
                    usersOutCounter.increment();
                });
    }

    /**
     * Consume Devices stream (from cdc) and store it in scylladb
     * Devices contain customer's device data such as device id
     *
     * @return a stream of customer data
     */
    @Bean
    public Consumer<KTable<String, DeviceByDASUser>> processDevicesStream() {
        return input -> input
                .toStream()
                // filter (and trace) messages
                .filter((k, device) -> {
                    log.debug("Received a message from DeviceByDASUser");
                    devicesInCounter.increment();
                    return device != null &&
                            StringUtils.isNotBlank(device.getDASUSER()) &&
                            StringUtils.isNotBlank(device.getDEVICEID());
                })
                .foreach((k, device) -> {
                    // store the customer in db
                    deviceRepository.save(DeviceRecord.builder()
                            .dasUser(device.getDASUSER())
                            .deviceId(device.getDEVICEID()).build());
                    log.debug("Device stored in Scylladb");
                    devicesOutCounter.increment();
                });
    }

    /**
     * Consume customer hmac stream and store it in scylladb
     *
     * @return a stream of customer data
     */
    @Bean
    public Consumer<KTable<String, CustomerWriteHmacRequest>> processHmacsStream() {
        return input -> input
                .toStream()
                // filter (and trace) messages
                .filter((k, hmac) -> {
                    MDC.put("XRequestId", hmac == null ? "" : hmac.getXRequestId());
                    log.debug("Received a message from CustomerWriteHmacRequest");
                    return hmac != null &&
                            StringUtils.isNotBlank(hmac.getUserId()) &&
                            StringUtils.isNotBlank(hmac.getHmac()) &&
                            StringUtils.isNotBlank(hmac.getHmacCreatedAt());
                })
                .foreach((k, hmac) -> {
                    // store the hmac in db
                    if (userRepository.existsById(hmac.getUserId())) {
                        userRepository.updateHmac(hmac.getHmac(),
                                hmac.getHmacCreatedAt(),
                                hmac.getDeviceId(),
                                hmac.getUserId());
                        hmacRepository.save(HmacRecord.builder()
                                .hmac(hmac.getHmac())
                                .hmacCreatedAt(hmac.getHmacCreatedAt())
                                .userId(hmac.getUserId())
                                .deviceId(hmac.getDeviceId()).build());
                        log.debug("HMAC stored in Scylladb");
                    } else {
                        log.error("Error: HMAC could not be stored in Scylladb. User doesn't exist");
                    }
                });
    }

    /**
     * Consume PE11 Customers stream (from cdc) and store it in scylladb
     * PE11 Customers contain customer's profile data such as first name and last name
     *
     * @return a stream of customer data
     */
    @Bean
    public Consumer<KTable<String, PE11Customer>> processPe11CustomersStream() {
        return input -> input
                .toStream()
                // filter (and trace) messages
                .filter((k, pe11Customer) -> {
                    log.debug("Received a message from PE11Customer");
                    profilesInCounter.increment();
                    return k != null && pe11Customer != null &&
                            StringUtils.isNotBlank(pe11Customer.getDESNOMBRE()) &&
                            StringUtils.isNotBlank(pe11Customer.getDESPRIAPEL());
                })
                .foreach((k, pe11Customer) -> {
                    // store the customer profile in db
                    profileRepository.save(ProfileRecord.builder()
                            .numpersona(String.valueOf(pe11Customer.getNUMPERSONA()))
                            .firstName(pe11Customer.getDESNOMBRE())
                            .lastName(pe11Customer.getDESPRIAPEL()).build());
                    log.debug("Customer profile stored in Scylladb");
                    profilesOutCounter.increment();
                });
    }

}
