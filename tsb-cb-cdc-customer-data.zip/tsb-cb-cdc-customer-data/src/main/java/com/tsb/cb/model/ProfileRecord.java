package com.tsb.cb.model;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(value = "profile")
@Data
@Builder
public class ProfileRecord {
    @PrimaryKey("numpersona")
    private String numpersona;

    @Column("first_name")
    private String firstName;
    @Column("last_name")
    private String lastName;
}
