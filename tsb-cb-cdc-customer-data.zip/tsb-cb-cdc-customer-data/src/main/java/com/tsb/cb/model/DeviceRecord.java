package com.tsb.cb.model;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(value = "device")
@Data
@Builder
public class DeviceRecord {
    @PrimaryKey("das_user")
    private String dasUser;

    @Column("device_id")
    private String deviceId;
}
