package com.tsb.cb.repository;

import com.tsb.cb.model.UserRecord;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends CassandraRepository<UserRecord, String> {
    @Query("update user SET numpersona = ?0 , das_user = ?1 WHERE user_id = ?2")
    void updateUser(String numpersona, String dasUser, String userId);

    @Query("UPDATE user SET hmac = ?0 , hmac_created_at = ?1 , hmac_device_id = ?2 WHERE user_id = ?3")
    void updateHmac(String hmac, String hmacCreatedAt, String hmacDeviceId, String userId);
}
