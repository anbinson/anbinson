package com.tsb.ods.repository;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

import com.tsb.ods.model.KC43Entity;


@Repository
public interface TransactionsHistoryRepository extends CassandraRepository<KC43Entity, String> {		
	@Query("delete from tsbods.MNF_PRT_KC43_TRANSACTION where codentid=?0")
	void deleteTransaction(String codentid);
}
