package com.tsb.ods.processor;
import java.util.function.Consumer;

import javax.annotation.PostConstruct;

import org.apache.kafka.streams.kstream.KTable;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tsb.ods.converter.Converter;
import com.tsb.ods.model.KC43Entity;
import com.tsb.ods.repository.TransactionsHistoryRepository;
import com.tsb.ods.stream.schema.avro.KC4301.KC43TransactionsHistory;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class StreamProcessor {

    private final TransactionsHistoryRepository transactonsHistoryRepository;
    private final MeterRegistry meterRegistry;
    
    private Counter transactonTypeInCounter; 
    private Counter transactonTypeOutCounter;

    @PostConstruct
    public void init() {
    	log.info("Create and register metric counters with Meter registry");
    	transactonTypeInCounter = Counter.builder("tsb_ods_in_transactonTypes_in_total")
    								.description("Total number of transactonTypes since process start")
    								.register(meterRegistry);
    	transactonTypeOutCounter = Counter.builder("tsb_ods_out_transactonTypes_in_total")
									.description("Total number of transactonTypes processed")
									.register(meterRegistry);
    	
    }
    

    /**
     * Consume transactonTypes stream (from ods) and store it in scylladb
     * 
     */
    @Bean
    public Consumer<KTable<String, KC43TransactionsHistory>> processTransactionsHistoryStream() {
    	
        return input -> input
                .toStream()
                .foreach((k, transactionsHistory) -> {
                	transactonTypeInCounter.increment();                	
                	KC43Entity kc43 = KC43Entity.builder()
                			.xx_yyyymm(transactionsHistory.getXXYYYYMM())
                			.codentid(transactionsHistory.getCODENTID())
							.tipproduct(transactionsHistory.getTIPPRODUCT())
							.codcontrat(Converter.decimalConverter(transactionsHistory.getCODCONTRAT()))
							.tsfechora(Converter.timestampConverter(transactionsHistory.getTSFECHORA()))
							.secopermul(transactionsHistory.getSECOPERMUL())
							.situacoper(transactionsHistory.getSITUACOPER())
							.tsprodsitu(Converter.timestampConverter(transactionsHistory.getTSPRODSITU()))
							.codoriop(transactionsHistory.getCODORIOP())
							.origenoper(transactionsHistory.getORIGENOPER())
							.indcoobj(transactionsHistory.getINDCOOBJ())
							.indgrupo(transactionsHistory.getINDGRUPO())
							.codopera(transactionsHistory.getCODOPERA())
							.codidist(transactionsHistory.getCODIDIST())
							.indicadore(transactionsHistory.getINDICADORE())
							.codidivi(transactionsHistory.getCODIDIVI())
							.impnetoper(Converter.decimalConverter(transactionsHistory.getIMPNETOPER()))
							.saldodesp(Converter.decimalConverter(transactionsHistory.getSALDODESP()))
							.fechavalor(Converter.dateConverter(transactionsHistory.getFECHAVALOR()))
							.fecontable(Converter.dateConverter(transactionsHistory.getFECONTABLE()))
							.concpreduc(transactionsHistory.getCONCPREDUC())
							.codentiop(transactionsHistory.getCODENTIOP())
							.codcentro(transactionsHistory.getCODCENTRO())
							.fecultact(Converter.dateConverter(transactionsHistory.getFECULTACT()))
							.horultact(Converter.timeConverter(transactionsHistory.getHORULTACT()))
							.codtermina(transactionsHistory.getCODTERMINA())
							.codusuario(transactionsHistory.getCODUSUARIO())
							.indicador2(transactionsHistory.getINDICADOR2())
							.fecsesion(Converter.dateConverter(transactionsHistory.getFECSESION()))
							.numaptbull(transactionsHistory.getNUMAPTBULL())
							.feccomunic(Converter.dateConverter(transactionsHistory.getFECCOMUNIC()))
							.numextracto(transactionsHistory.getNUMEXTRACTO())
							.numotpbull(transactionsHistory.getNUMOTPBULL())
							.indlibext(transactionsHistory.getINDLIBEXT())
							.docuasoc(transactionsHistory.getDOCUASOC())
							.docuinteg(transactionsHistory.getDOCUINTEG())
							.docureten(transactionsHistory.getDOCURETEN())
							.remtalexced(transactionsHistory.getREMTALEXCED())
							.bloqmoroso(transactionsHistory.getBLOQMOROSO())
							.refern43(transactionsHistory.getREFERN43())
							.infcomplem(transactionsHistory.getINFCOMPLEM())
							.indbarrido(transactionsHistory.getINDBARRIDO())
							.indmodvalor(transactionsHistory.getINDMODVALOR())
							.indanulmdc(transactionsHistory.getINDANULMDC())
							.codopebull(transactionsHistory.getCODOPEBULL())
							.codprobull(transactionsHistory.getCODPROBULL())
							.codasibull(transactionsHistory.getCODASIBULL())
							.refinterbul(transactionsHistory.getREFINTERBUL())
							.restoconcp(transactionsHistory.getRESTOCONCP())
							.referencor(transactionsHistory.getREFERENCOR())
							.codcomu(transactionsHistory.getCODCOMU())
							.at_creation_time(Converter.timestampConverter(transactionsHistory.getATCREATIONTIME()))
							.at_creation_user(transactionsHistory.getATCREATIONUSER())
							.xx_checksum(transactionsHistory.getXXCHECKSUM())
							.build();				
	                	
                	try {
						ObjectMapper objecmapper =new ObjectMapper();
						String str = objecmapper.writeValueAsString(kc43);
						log.info("Transaction History: "+ str);
						if ("DELETE".equals(transactionsHistory.getEXECTYPE())) {
							transactonsHistoryRepository.deleteTransaction(kc43.getCodentid());
							log.info("Transaction History deleted in Scylladb:"+ kc43.getCodentid());
						}
						else {                
							transactonsHistoryRepository.save(kc43);

							log.info("Transaction History stored in Scylladb:"+ kc43.getCodentid());
						}
					} catch (Exception e) { 
						e.printStackTrace();
					}
                	
//	                	if ("DELETE".equals(transactionsHistory.getEXECTYPE())) {
//	                		transactonsHistoryRepository.deleteById(kc43.getCodentid());
//	                		log.info("transacton history deleted in Scylladb"+ kc43.getCodentid());
//	                	}
//	                	else {				
//	                		transactonsHistoryRepository.save(kc43);
//		                	log.info("Transacton history stored in Scylladb"+ kc43.getCodentid());
//	                	}
                	
					transactonTypeOutCounter.increment();
					
                });
    }
}
