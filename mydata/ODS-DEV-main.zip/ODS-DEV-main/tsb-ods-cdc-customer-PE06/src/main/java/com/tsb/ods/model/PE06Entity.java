package com.tsb.ods.model;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.Builder;
import lombok.Data;

@Table(value = "MNF_PRT_PE06_CONTRACT")
@Data
@Builder
public class PE06Entity {

	@PrimaryKey("codentid")
	private String codentid;

	@Column("tipproduct")            
	private String tipproduct;

	@Column("codproduct")            
	private String codproduct;

	@Column("codcontrat")            
	private Double codcontrat;

	@Column("digcontrat")            
	private String digcontrat;

	@Column("indsitcont")            
	private String indsitcont;

	@Column("indnivconf")            
	private int indnivconf;

	@Column("indnivconb")            
	private int indnivconb;

	@Column("codsecbesp")            
	private int codsecbesp;

	@Column("indtipcont")            
	private String indtipcont;

	@Column("fecalta")            
	private LocalDate fecalta;

	@Column("fecbaja")            
	private LocalDate fecbaja;

	@Column("codtermina")            
	private String codtermina;

	@Column("codusuario")            
	private String codusuario;

	@Column("fecultact")            
	private LocalDate fecultact;

	@Column("horultact")            
	private LocalTime horultact;

	@Column("codcentro")            
	private String codcentro;

	@Column("codprodo")            
	private String codprodo;

	@Column("codidivi")            
	private String codidivi;

	@Column("codentcom")            
	private String codentcom;

	@Column("codctrcom")            
	private String codctrcom;

	@Column("indidioma")            
	private String indidioma;

	@Column("indincor")            
	private String indincor;

	@Column("indriesg")            
	private String indriesg;

	@Column("marca")            
	private String marca;

	@Column("colectivo")            
	private Double colectivo;

	@Column("fecsolit")            
	private LocalDate fecsolit;

	@Column("codususoli")            
	private String codususoli; 

	@Column("canale")            
	private String canale;

	@Column("procedene")            
	private String procedene;

	@Column("codsececo")            
	private int codsececo;

	@Column("codeba")            
	private int codeba;

	@Column("at_creation_time")              
	private Timestamp at_creation_time;

	@Column("at_creation_user")                
	private String at_creation_user;

	@Column("at_last_modified_time")              
	private Timestamp at_last_modified_time;

	@Column("at_last_modified_user")                
	private String at_last_modified_user;

	@Column("xx_checksum")            
	private String xx_checksum;

}
