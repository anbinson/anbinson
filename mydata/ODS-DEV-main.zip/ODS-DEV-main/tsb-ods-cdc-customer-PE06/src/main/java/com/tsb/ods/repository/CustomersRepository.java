package com.tsb.ods.repository;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

import com.tsb.ods.model.PE06Entity;


@Repository
public interface CustomersRepository extends CassandraRepository<PE06Entity, String> {		
	@Query("delete from tsbods.MNF_PRT_PE06_CONTRACT where codentid=?0")
	void deleteCustomer(String codentid);
}
