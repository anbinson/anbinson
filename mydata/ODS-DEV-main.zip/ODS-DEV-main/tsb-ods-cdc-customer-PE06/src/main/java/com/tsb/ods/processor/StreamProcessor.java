package com.tsb.ods.processor;
import java.util.function.Consumer;

import javax.annotation.PostConstruct;

import org.apache.kafka.streams.kstream.KTable;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tsb.ods.converter.Converter;
import com.tsb.ods.model.PE06Entity;
import com.tsb.ods.repository.CustomersRepository;
import com.tsb.ods.stream.schema.avro.PE06.PE06Contracts;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class StreamProcessor {

    private final CustomersRepository customersRepository;
    private final MeterRegistry meterRegistry;
    
    private Counter customerTypeInCounter; 
    private Counter customerTypeOutCounter;
    
    @PostConstruct
    public void init() {
    	log.info("Create and register metric counters with Meter registry");
    	customerTypeInCounter = Counter.builder("tsb_ods_in_customers_in_total")
    								.description("Total number of customers since process start")
    								.register(meterRegistry);
    	customerTypeOutCounter = Counter.builder("tsb_ods_out_customers_in_total")
									.description("Total number of customers processed")
									.register(meterRegistry);
    	
    }
    

    /**
     * Consume transactonTypes stream (from ods) and store it in scylladb
     * 
     */
    @Bean
    public Consumer<KTable<String, PE06Contracts>> processCustomersStream() {
    	
        return input -> input
                .toStream()
                .foreach((k, customer) -> {
                	customerTypeInCounter.increment();                	
                	PE06Entity pe06 = PE06Entity.builder()
                			.codentid(customer.getCODENTID())
                			.tipproduct(customer.getTIPPRODUCT())
                			.codproduct(customer.getCODPRODUCT())
                			.codcontrat(Converter.decimalConverter(customer.getCODCONTRAT()))
                			.digcontrat(customer.getDIGCONTRAT())
                			.indsitcont(customer.getINDSITCONT())
                			.indnivconf(customer.getINDNIVCONF())
                			.indnivconb(customer.getINDNIVCONB())
                			.codsecbesp(customer.getCODSECBESP())
                			.indtipcont(customer.getINDTIPCONT())
                			.fecalta(Converter.dateConverter(customer.getFECALTA()))
                			.fecbaja(Converter.dateConverter(customer.getFECBAJA()))
                			.codtermina(customer.getCODTERMINA())
                			.codusuario(customer.getCODUSUARIO())
                			.fecultact(Converter.dateConverter(customer.getFECULTACT()))
                			.horultact(Converter.timeConverter(customer.getHORULTACT()))
                			.codcentro(customer.getCODCENTRO())
                			.codprodo(customer.getCODPRODO())
                			.codidivi(customer.getCODIDIVI())
                			.codentcom(customer.getCODENTCOM())
                			.codctrcom(customer.getCODCTRCOM())
                			.indidioma(customer.getINDIDIOMA())
                			.indincor(customer.getINDINCOR())
                			.indriesg(customer.getINDRIESG())
                			.marca(customer.getMARCA())
                			.colectivo(Converter.decimalConverter(String.valueOf(customer.getCOLECTIVO())))
                			.fecsolit(Converter.dateConverter(customer.getFECSOLIT()))
                			.codususoli(customer.getCODUSUSOLI())
                			.canale(customer.getCANALE())
                			.procedene(customer.getPROCEDENE())
                			.codsececo(customer.getCODSECECO())
                			.codeba(customer.getCODEBA())
                			.at_creation_time(Converter.timestampConverter(customer.getATCREATIONTIME()))
                			.at_creation_user(customer.getATCREATIONUSER())
                			.at_last_modified_time(Converter.timestampConverter(customer.getATLASTMODIFIEDTIME()))
                			.at_last_modified_user(customer.getATLASTMODIFIEDUSER())
                			.xx_checksum(customer.getXXCHECKSUM())
							.build();				
	                	
                	try {
						ObjectMapper objecmapper =new ObjectMapper();
						String str = objecmapper.writeValueAsString(pe06);
						log.info("customer: "+ str);
						if ("DELETE".equals(customer.getEXECTYPE())) {
							customersRepository.deleteById(pe06.getCodentid());
							log.info("customer deleted in Scylladb:"+ pe06.getCodentid());
						}
						else {                
							customersRepository.save(pe06);

							log.info("customer stored in Scylladb:"+ pe06.getCodentid());
						}
					} catch (Exception e) { 
						e.printStackTrace();
					}
                	
                	customerTypeOutCounter.increment();
					
                });
    }
}
