# Conversational Banking - CDC Customer Data Write Topology
## Description
CDC Customer Data Topology reads CDC public / private topics and creates a custom Customer table (numpersona, userid, deviceid, etc.) in ScyllaDB as well as a kstream containing the customer data.

## Technology
* Java 11
* Spring Boot
* ScyllaDB
* Kafka

## Build
`mvn clean install`

## Monitoring
Ensure Prometheus has access to /actuator/prometheus.

## Database
Run the CQL queries for each environment (under /resources/cql).
### DEV
```
CREATE KEYSPACE IF NOT EXISTS tsbcb WITH replication = {'class':'SimpleStrategy', 'replication_factor' : 3};
CREATE TABLE IF NOT EXISTS tsbcb.user(user_id text, das_user text, numpersona text, hmac text, hmac_created_at text, hmac_device_id text, PRIMARY KEY (user_id));
CREATE TABLE IF NOT EXISTS tsbcb.device(das_user text, device_id text, PRIMARY KEY (das_user));
CREATE TABLE IF NOT EXISTS tsbcb.profile(numpersona text, first_name text, last_name text,  PRIMARY KEY (numpersona));
CREATE TABLE IF NOT EXISTS tsbcb.hmac(hmac text, user_id text, device_id text, hmac_created_at text, PRIMARY KEY (hmac));
```
### SIT
```
CREATE KEYSPACE IF NOT EXISTS tsbcb WITH replication = {'class':'SimpleStrategy', 'replication_factor' : 3};
CREATE TABLE IF NOT EXISTS tsbcb.user(user_id text, das_user text, numpersona text, hmac text, hmac_created_at text, hmac_device_id text, PRIMARY KEY (user_id));
CREATE TABLE IF NOT EXISTS tsbcb.device(das_user text, device_id text, PRIMARY KEY (das_user));
CREATE TABLE IF NOT EXISTS tsbcb.profile(numpersona text, first_name text, last_name text,  PRIMARY KEY (numpersona));
CREATE TABLE IF NOT EXISTS tsbcb.hmac(hmac text, user_id text, device_id text, hmac_created_at text, PRIMARY KEY (hmac));
```
## Topics
### DEV
* com.tsb.private.ems.users_by_user_id
* com.tsb.private.cdc.tbbv_bs_enrollments
* com.tsb.cb.customer.write.hmac.public.request
* com.tsb.private.cdc.pe11.customers

### SIT
* com.tsb.private.cb.users_by_user_id.0
* com.tsb.private.cb.tbbv_bs_enrollments.0
* com.tsb.cb.customer.write.hmac.public.request.0
* com.tsb.private.cb.pe11.customers.0

### DDL

Create table tsbods.MNF_PRT_PE06_CONTRACT
(CODENTID    TEXT,      --Contract entity code
TIPPRODUCT   TEXT,      --Basic product code
CODPRODUCT	 TEXT,		--Added
CODCONTRAT   DECIMAL,   --Contract number
DIGCONTRAT   TEXT,      --CONTRACT CONTROL DIGIT
INDSITCONT   TEXT,      --ACCOUNT CONTRACT STATUS
INDNIVCONF   INT,       --CONFIDENTIALITY LEVEL
INDNIVCONB   INT,       --CONFIDENTIALITY LEVEL (BATCH)
CODSECBESP   SMALLINT,  --BANCO ESPAÑA SECTOR CODE
INDTIPCONT   TEXT,      --CONTRACT TYPE
FECALTA      DATE,      --ADMISSION DATE
FECBAJA      DATE,      --DISMISSAL DATE
CODTERMINA   TEXT,      --TERMINAL CODE
CODUSUARIO   TEXT,      --USER CODE
FECULTACT    DATE,      --LAST UPDATE DATE
HORULTACT    TIME,      --LAST UPDATE TIME
CODCENTRO    TEXT,      --CENTRE CODE
CODPRODO     TEXT,      --DP01PROD PRODUCT CODE
CODIDIVI     TEXT,      --TS00CASD ALFANUMERIC S CODE
CODENTCOM    TEXT,      --SELLER ENTITY CODE
CODCTRCOM    TEXT,      --SELLER CENTRE CODE
INDIDIOMA    TEXT,      --COMUNICATION LANGUAGE
INDINCOR     TEXT,      --CORRESPONDENCE INTERCEPTION CODE
INDRIESG     TEXT,      --RISK GROUP INDICATOR
MARCA        TEXT,      --PENDING MARK
COLECTIVO    DECIMAL,    --COLLECTIVE CODE
FECSOLIT     DATE,      --CONTRACT REQUEST DATE
CODUSUSOLI   TEXT,  	--USER CODE
CANALE       TEXT,      --REQUEST ENTRY CHANNEL
PROCEDENE    TEXT,      --REQUEST ENTRY ORIGIN
CODSECECO    INT,       --ACCOUNTING SECTOR
CODEBA       INT,       --EBA
AT_CREATION_TIME TIMESTAMP, --ETL/BI Audit column
AT_CREATION_USER TEXT,      --ETL/BI Audit column
AT_LAST_MODIFIED_TIME   TIMESTAMP,  --ETL/BI Audit column
AT_LAST_MODIFIED_USER   TEXT,       --ETL/BI Audit column
XX_CHECKSUM   TEXT,                 --ETL/BI Audit column
PRIMARY KEY (CODENTID,TIPPRODUCT,CODCONTRAT)
);

select * from tsbods.MNF_PRT_PE06_CONTRACT;