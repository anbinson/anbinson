Create table MNF_PRT_BS46_TRANSACTION_TYPE
(CODCOMOP   TEXT,                             --COMPOSITION OPERATION
DESCOMOP   TEXT,                              --DESCRIPTION COMPOSITION
CODCOMUN   TEXT,                              --COMMON CONCEPT
IDIOMA   TEXT,                               
REDUCIDO   TEXT,                              --REDUCED
AT_CREATION_TIME   TIMESTAMP,                 --ETL/BI Audit column
AT_CREATION_USER   TEXT,                      --ETL/BI Audit column
AT_LAST_MODIFIED_TIME   TIMESTAMP,            --ETL/BI Audit column
AT_LAST_MODIFIED_USER   TEXT,                 --ETL/BI Audit column
XX_CHECKSUM   TEXT,                           --ETL/BI Audit column
PRIMARY KEY (CODCOMOP)
);