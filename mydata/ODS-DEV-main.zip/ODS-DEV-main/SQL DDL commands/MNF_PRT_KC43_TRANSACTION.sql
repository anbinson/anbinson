Create table MNF_PRT_KC43_TRANSACTION 
(XX_YYYYMM  TEXT,   --  Transaction Month
CODENTID TEXT,        --Contract entity code
TIPPRODUCT TEXT,     --Basic product code
CODCONTRAT DECIMAL,  --Contract number
TSFECHORA TIMESTAMP, --Movement TMS
SECOPERMUL SMALLINT, --Multiple sequence of operation
SITUACOPER TEXT,     --Movement situation
TSPRODSITU  TIMESTAMP,--TMS situation
CODORIOP TEXT,        --Operation source code
ORIGENOPER TEXT,      --Source object type 
INDCOOBJ TEXT,        --Contract object indicator
INDGRUPO TEXT,        --Operation group indicator 
CODOPERA TEXT,        --Operation code 
CODIDIST TEXT,        --Screen layout code
INDICADORE TEXT,      --Various indicators_ Check the values of each position and according to the application in General remarks
CODIDIVI  TEXT,       --Currency code
IMPNETOPER  DECIMAL,  --Transaction amount
SALDODESP DECIMAL,    --Running Balance
FECHAVALOR     DATE,  --Value date
FECONTABLE DATE,      --Accounting date
CONCPREDUC  SMALLINT, --Reduced motion concept 
CODENTIOP TEXT,       --Operating entity
CODCENTRO TEXT,       --Operating center
FECULTACT DATE,       --Last update date
HORULTACT TIME,       --Last update time
CODTERMINA TEXT,      --Terminal code last update
CODUSUARIO TEXT,      --User last update
INDICADOR2  TEXT,     --Various indicators_ Check the values of each position and according to the application in General remarks
FECSESION DATE,       --Session date
NUMAPTBULL DECIMAL,   --Bull point number
FECCOMUNIC DATE,      --Date of communication in the statement
NUMEXTRACTO SMALLINT, --Extract number
NUMOTPBULL DECIMAL,   --Bull operation number
INDLIBEXT TEXT,       --Notebook / statement indicator
DOCUASOC TEXT,        --Associated document indicator (Y / N)
DOCUINTEG TEXT,       --Integrated mail document indicator (Y / N)
DOCURETEN  TEXT,      --Document held indicator (Y / N)
REMTALEXCED TEXT,     --Remittance exceeded
BLOQMOROSO TEXT,      --Default lock indicator
REFERN43  TEXT,       --Indicator of existence of rule 43
INFCOMPLEM TEXT,      --Complementary information indicator
INDBARRIDO TEXT,      --Indicator if the movement belongs to a sweep account
INDMODVALOR TEXT,     --Indicator if the value date has been modified
INDANULMDC TEXT,      
CODOPEBULL SMALLINT,  --Bull operation code
CODPROBULL SMALLINT,  --Bull operation code
CODASIBULL SMALLINT,  --Bull operation code
REFINTERBUL DECIMAL,  --Internal reference BULL
RESTOCONCP TEXT,      --Rest of concept 
REFERENCOR TEXT,      --Source object
CODCOMU TEXT,         --Concept code
AT_CREATION_TIME TIMESTAMP,     -- BI/ETL Audit column
AT_CREATION_USER TEXT,     -- BI/ETL Audit column
XX_CHECKSUM TEXT,           --BI/ETL Audit column
PRIMARY KEY ((XX_YYYYMM,CODENTID,TIPPRODUCT,CODCONTRAT),TSFECHORA)
)WITH CLUSTERING ORDER BY (TSFECHORA DESC);