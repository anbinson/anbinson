package com.tsb.ods.processor;
import java.util.function.Consumer;
import javax.annotation.PostConstruct;

import org.apache.kafka.streams.kstream.KTable;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tsb.ods.converter.Converter;
import com.tsb.ods.model.BS46Entity;
import com.tsb.ods.repository.TransactionTypeRepository;
import com.tsb.ods.stream.schema.avro.BS4600.BS46TransactionType;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class StreamProcessor {

	private final TransactionTypeRepository transactonTypeRepository;
	private final MeterRegistry meterRegistry;

	private Counter transactonTypeInCounter; 
	private Counter transactonTypeOutCounter;

	@PostConstruct
	public void init() {
		log.info("Create and register metric counters with Meter registry");
		transactonTypeInCounter = Counter.builder("tsb_ods_in_transactonTypes_in_total")
				.description("Total number of transactonTypes since process start")
				.register(meterRegistry);
		transactonTypeOutCounter = Counter.builder("tsb_ods_out_transactonTypes_in_total")
				.description("Total number of transactonTypes processed")
				.register(meterRegistry);

	}


	/**
	 * Consume transactonTypes stream (from ods) and store it in scylladb
	 * 
	 */
	@Bean
	public Consumer<KTable<String, BS46TransactionType>> processtransactonTypesStream() {

		return input -> input
				.toStream()
				.foreach((k, transactonType) -> {
					transactonTypeInCounter.increment();   
					BS46Entity bs46 = BS46Entity.builder()
								.codcomop(transactonType.getCODCOMOP())
								.descomop(transactonType.getDESCOMOP())
								.codcomun(transactonType.getCODCOMUN())
								.idioma(transactonType.getIDIOMA())
								.reducido(transactonType.getREDUCIDO())
								.at_creation_time(Converter.timestampConverter(transactonType.getATCREATIONTIME()))
								.at_creation_user(transactonType.getATCREATIONUSER())
								.at_last_modified_time(Converter.timestampConverter(transactonType.getATLASTMODIFIEDTIME()))
								.at_last_modified_user(transactonType.getATLASTMODIFIEDUSER())
								.xx_checksum(transactonType.getXXCHECKSUM())
								.build();
					
					try {
						ObjectMapper objecmapper =new ObjectMapper();
						String str = objecmapper.writeValueAsString(bs46);
						log.info("transaction type: "+ str);
						if ("DELETE".equals(transactonType.getEXECTYPE())) {
							transactonTypeRepository.deleteById(bs46.getCodcomop());
							log.info("Transacton type deleted in Scylladb:"+ bs46.getCodcomop());
						}
						else if("UPDATE".equals(transactonType.getEXECTYPE())) {
							transactonTypeRepository.updateTransaction(bs46.getCodcomop(), bs46.getDescomop(), bs46.getCodcomun(),
									bs46.getIdioma(), bs46.getReducido(), bs46.getAt_last_modified_time(), 
									bs46.getAt_last_modified_user(), bs46.getXx_checksum());
							log.info("Transacton type updated in Scylladb:"+ bs46.getCodcomop());
						}
						else {                
							transactonTypeRepository.save(bs46);

							log.info("Transacton Type stored in Scylladb:"+ bs46.getCodcomop());
						}
					} catch (Exception e) { 
						e.printStackTrace();
					}
					//                	if ("DELETE".equals(transactonType.getEXECTYPE())) {
					//                		transactonTypeRepository.deleteById(bs46.getCodcomop());
					//                		log.info("transactonType type deleted in Scylladb"+ bs46.getCodcomop());
					//                	}
					//                	else {				
					//	                	transactonTypeRepository.save(bs46);
					//	                	log.info("Transacton Type stored in Scylladb"+ bs46.getCodcomop());
					//                	}

					transactonTypeOutCounter.increment();

				});
	}
}
