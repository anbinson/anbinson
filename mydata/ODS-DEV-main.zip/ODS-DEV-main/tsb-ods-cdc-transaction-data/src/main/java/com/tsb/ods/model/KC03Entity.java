package com.tsb.ods.model;

import lombok.Builder;
import lombok.Data;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(value = "MNF_PRT_KC03_TRANSACTION")
@Data
@Builder
public class KC03Entity {

    @PrimaryKey("codentid")
	private String codentid;
	
	@Column("tipproduct")            
	private String tipproduct;
	
	@Column("codcontrat")            
	private Double codcontrat; 
	
	@Column("tsfechora")             
	private Timestamp tsfechora;
	
	@Column("secopermul")            
	private int secopermul;
	
	@Column("situacoper")            
	private String situacoper;
	
	@Column("tsprodsitu")            
	private Timestamp tsprodsitu;
	
	@Column("codoriop")              
	private String codoriop;
	
	@Column("origenoper")            
	private String origenoper;
	
	@Column("indcoobj")              
	private String indcoobj;
	
	@Column("indgrupo")              
	private String indgrupo;
	
	@Column("codopera")              
	private String codopera;
	
	@Column("codidist")              
	private String codidist;
	
	@Column("indicadore")            
	private String indicadore;
	
	@Column("codidivi")              
	private String codidivi;
	
	@Column("impnetoper")            
	private Double impnetoper;
	
	@Column("fechavalor")            
	private LocalDate fechavalor;
	
	@Column("fecontable")            
	private LocalDate fecontable;
	
	@Column("feciniinac")            
	private LocalDate feciniinac;
	
	@Column("concpreduc")            
	private int concpreduc;
	
	@Column("codentiop")             
	private String codentiop;
	
	@Column("codcentro")             
	private String codcentro;
	
	@Column("fecultact")             
	private LocalDate fecultact;
	
	@Column("horultact")             
	private LocalTime horultact;
	
	@Column("codtermina")            
	private String codtermina;
	
	@Column("codusuario")            
	private String codusuario;
	
	@Column("indicador2")            
	private String indicador2;
	
	@Column("fecsesion")             
	private LocalDate fecsesion;
	
	@Column("numaptbull")            
	private Double numaptbull;
	
	@Column("feccomunic")            
	private LocalDate feccomunic;
	
	@Column("numextracto")           
	private int numextracto;
	
	@Column("numotpbull")            
	private Double numotpbull;
	
	@Column("indlibext")             
	private String indlibext;
	
	@Column("docuasoc")              
	private String docuasoc;
	
	@Column("docuinteg")             
	private String docuinteg;
	
	@Column("docureten")             
	private String docureten;
	
	@Column("remtalexced")           
	private String remtalexced;
	
	@Column("bloqmoroso")            
	private String bloqmoroso;
	
	@Column("refern43")              
	private String refern43;
	
	@Column("infcomplem")            
	private String infcomplem;
	
	@Column("indbarrido")            
	private String indbarrido;
	
	@Column("indmodvalor")           
	private String indmodvalor;
	
	@Column("indanulmdc")            
	private String indanulmdc;
	
	@Column("codopebull")            
	private int codopebull;
	
	@Column("codprobull")            
	private int codprobull;
	
	@Column("codasibull")            
	private int codasibull;
	
	@Column("refinterbul")           
	private Double refinterbul;
	
	@Column("restoconcp")            
	private String restoconcp;
	
	@Column("referencor")            
	private String referencor;
	
	@Column("codcomu")               
	private String codcomu;
	
	@Column("at_creation_time")            
	private Timestamp at_creation_time;
	
	@Column("at_creation_user")            
	private String at_creation_user;
	
	@Column("xx_checksum")
	private String xx_checksum;
	
	@Column("xx_yyyymm")
	private String xx_yyyymm;
}
 
