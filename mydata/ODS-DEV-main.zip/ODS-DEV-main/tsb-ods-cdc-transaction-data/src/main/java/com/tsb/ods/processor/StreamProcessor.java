package com.tsb.ods.processor;

import java.util.function.Consumer;

import javax.annotation.PostConstruct;

import org.apache.kafka.streams.kstream.KTable;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tsb.ods.converter.Converter;
import com.tsb.ods.model.KC03Entity;
import com.tsb.ods.repository.TransactionRepository;
import com.tsb.ods.stream.schema.avro.KC0300.KC03Transactions;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class StreamProcessor {

    private final TransactionRepository transactionRepository;
    private final MeterRegistry meterRegistry;
    
    private Counter transactionsInCounter; 
    private Counter transactionsOutCounter;

    @PostConstruct
    public void init() {
    	log.info("Create and register metric counters with Meter registry");
    	transactionsInCounter = Counter.builder("tsb_ods_in_transactions_in_total")
    								.description("Total number of transactions since process start")
    								.register(meterRegistry);
    	transactionsOutCounter = Counter.builder("tsb_ods_out_transactions_in_total")
									.description("Total number of transactions processed")
									.register(meterRegistry);
    	
    }
    

    /**
     * Consume Transactions stream (from ods) and store it in scylladb
     * 
     */
    @Bean
    public Consumer<KTable<String, KC03Transactions>> processTransactionsStream() {
    	
        return input -> input
                .toStream()
                .foreach((k, transaction) -> {
                	transactionsInCounter.increment();
                	
                	KC03Entity kc03 = KC03Entity.builder()
                			.codentid(transaction.getCODENTID())
							.tipproduct(transaction.getTIPPRODUCT())
							.codcontrat(Converter.decimalConverter(transaction.getCODCONTRAT()))
							.tsfechora(Converter.timestampConverter(transaction.getTSFECHORA()))
							.secopermul(transaction.getSECOPERMUL())
							.situacoper(transaction.getSITUACOPER())
							.tsprodsitu(Converter.timestampConverter(transaction.getTSPRODSITU()))
							.codoriop(transaction.getCODORIOP())
							.origenoper(transaction.getORIGENOPER())
							.indcoobj(transaction.getINDCOOBJ())
							.indgrupo(transaction.getINDGRUPO())
							.codopera(transaction.getCODOPERA())
							.codidist(transaction.getCODIDIST())
							.indicadore(transaction.getINDICADORE())
							.codidivi(transaction.getCODIDIVI())
							.impnetoper(Converter.decimalConverter(transaction.getIMPNETOPER()))
							.fechavalor(Converter.dateConverter(transaction.getFECHAVALOR()))
							.fecontable(Converter.dateConverter(transaction.getFECONTABLE()))
							.feciniinac(Converter.dateConverter(transaction.getFECINIINAC()))
							.concpreduc(transaction.getCONCPREDUC())
							.codentiop(transaction.getCODENTIOP())
							.codcentro(transaction.getCODCENTRO())
							.fecultact(Converter.dateConverter(transaction.getFECULTACT()))
							.horultact(Converter.timeConverter(transaction.getHORULTACT()))
							.codtermina(transaction.getCODTERMINA())
							.codusuario(transaction.getCODUSUARIO())
							.indicador2(transaction.getINDICADOR2())
							.fecsesion(Converter.dateConverter(transaction.getFECSESION()))
							.numaptbull(Converter.decimalConverter(transaction.getNUMAPTBULL()))
							.feccomunic(Converter.dateConverter(transaction.getFECCOMUNIC()))
							.numextracto(transaction.getNUMEXTRACTO())
							.numotpbull(Converter.decimalConverter(transaction.getNUMOTPBULL()))
							.indlibext(transaction.getINDLIBEXT())
							.docuasoc(transaction.getDOCUASOC())
							.docuinteg(transaction.getDOCUINTEG())
							.docureten(transaction.getDOCURETEN())
							.remtalexced(transaction.getREMTALEXCED())
							.bloqmoroso(transaction.getBLOQMOROSO())
							.refern43(transaction.getREFERN43())
							.infcomplem(transaction.getINFCOMPLEM())
							.indbarrido(transaction.getINDBARRIDO())
							.indmodvalor(transaction.getINDMODVALOR())
							.indanulmdc(transaction.getINDANULMDC())
							.codopebull(transaction.getCODOPEBULL())
							.codprobull(transaction.getCODPROBULL())
							.codasibull(transaction.getCODASIBULL())
							.refinterbul(Converter.decimalConverter(transaction.getREFINTERBUL()))
							.restoconcp(transaction.getRESTOCONCP())
							.referencor(transaction.getREFERENCOR())
							.codcomu(transaction.getCODCOMU())
							.at_creation_time(Converter.timestampConverter(transaction.getATCREATIONTIME()))
							.at_creation_user(transaction.getATCREATIONUSER())
							.xx_checksum(transaction.getXXCHECKSUM())
							.xx_yyyymm(transaction.getXXYYYYMM())
							.build();
					
                	try {
						ObjectMapper objecmapper =new ObjectMapper();
						String str = objecmapper.writeValueAsString(kc03);
						log.info("transaction: "+ str);
						if ("DELETE".equals(transaction.getEXECTYPE())) {
							transactionRepository.deleteTransaction(kc03.getCodentid(), kc03.getTipproduct(),
									kc03.getCodcontrat());
							log.info("Transacton deleted in Scylladb:"+ kc03.getCodentid());
						}
						else {                
							transactionRepository.save(kc03);

							log.info("Transacton stored in Scylladb:"+ kc03.getCodentid());
						}
					} catch (Exception e) { 
						e.printStackTrace();
					}
					transactionsOutCounter.increment();
					
                });
    }
}
