package com.tsb.ods.repository;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

import com.tsb.ods.model.KC03Entity;


@Repository
public interface TransactionRepository extends CassandraRepository<KC03Entity, String> {		
	@Query("delete from tsbods.MNF_PRT_KC03_TRANSACTION where codentid=?0 and tipproduct=?1 and codcontrat=?2")
	void deleteTransaction(String codentid, String tipproduct, Double codcontrat);
}
