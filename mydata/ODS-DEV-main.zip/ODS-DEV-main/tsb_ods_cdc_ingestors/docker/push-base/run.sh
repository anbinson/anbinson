#!/usr/bin/env sh
/tmp/app/run-app.sh