package uk.co.tsb.ods.cdc.ingestors.logging;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

import java.util.Set;

@Configuration
public class LoggingConfiguration {

    @Value("${request.logging.paths}")
    private Set<String> paths;

    @Bean
    public FilterRegistrationBean<RequestAndResponseLoggingFilter> loggingFilter(){
        FilterRegistrationBean<RequestAndResponseLoggingFilter> registrationBean = new FilterRegistrationBean<>();

        registrationBean.setFilter(new RequestAndResponseLoggingFilter());
        registrationBean.addUrlPatterns(paths.stream().toArray(String[]::new));
        registrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE);

        return registrationBean;
    }
}
