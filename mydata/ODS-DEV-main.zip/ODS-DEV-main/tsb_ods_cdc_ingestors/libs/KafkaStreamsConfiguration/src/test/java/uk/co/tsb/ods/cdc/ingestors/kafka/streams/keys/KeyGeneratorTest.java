package uk.co.tsb.ods.cdc.ingestors.kafka.streams.keys;

import org.hamcrest.Matchers;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;

public class KeyGeneratorTest {

    private KeyGenerator keyGenerator = new KeyGenerator();

    @Test
    public void testPositiveCase() {
        // given
        // when
        String result = keyGenerator.getPrivateTopicKey("111", "222", 333L);
        // then
        assertThat(result, Matchers.equalTo("111:222:333"));
    }

    @Test
    public void testNullCODENTID() {
        // given
        // when
        String result = keyGenerator.getPrivateTopicKey(null, "222", 333L);
        // then
        assertThat(result, Matchers.equalTo("222:333"));
    }

    @Test
    public void testEmptyCODENTID() {
        // given
        // when
        String result = keyGenerator.getPrivateTopicKey("", "222", 333L);
        // then
        assertThat(result, Matchers.equalTo("222:333"));
    }


    @Test
    public void testNullTIPPRODUCT() {
        // given
        // when
        String result = keyGenerator.getPrivateTopicKey("111", null, 333L);
        // then
        assertThat(result, Matchers.equalTo("111:333"));
    }

    @Test
    public void testEmptyTIPPRODUCT() {
        // given
        // when
        String result = keyGenerator.getPrivateTopicKey("111", "", 333L);
        // then
        assertThat(result, Matchers.equalTo("111:333"));
    }

    @Test
    public void testNullCODCONTRAT() {
        // given
        // when
        String result = keyGenerator.getPrivateTopicKey("111", "222", null);
        // then
        assertThat(result, Matchers.equalTo("111:222"));
    }

    @Test
    public void testAllNulls() {
        // given
        // when
        String result = keyGenerator.getPrivateTopicKey(null, null, null);
        // then
        assertThat(result, Matchers.equalTo(""));
    }
}
