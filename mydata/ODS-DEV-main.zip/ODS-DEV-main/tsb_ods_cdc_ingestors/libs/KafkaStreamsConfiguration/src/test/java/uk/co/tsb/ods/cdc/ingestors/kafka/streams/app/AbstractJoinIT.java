package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;

import io.confluent.kafka.streams.serdes.avro.SpecificAvroDeserializer;
import io.confluent.kafka.streams.serdes.avro.SpecificAvroSerde;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.After;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.utils.KafkaTestUtils;

import java.util.Map;

abstract public class AbstractJoinIT<IN_1 extends SpecificRecordBase, IN_2 extends SpecificRecordBase,
        IN_3 extends SpecificRecordBase, OUT extends SpecificRecordBase> {

    @Autowired
    private EmbeddedKafkaBroker embeddedKafkaBroker;

    @Value("${kafka.outputTopic}")
    protected String kafkaOutputTopic;

    protected Consumer<String, OUT> consumer;

    protected DefaultKafkaConsumerFactory<String, OUT> cf;
    protected DefaultKafkaProducerFactory<String, IN_1> pf;
    protected DefaultKafkaProducerFactory<String, IN_2> secondPf;
    protected DefaultKafkaProducerFactory<String, IN_3> thirdPf;

    @Before
    public void setUp() throws Exception {

        Map<String, Object> consumerProps = KafkaTestUtils.consumerProps("group", "false", embeddedKafkaBroker);
        consumerProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        consumerProps.put("specific.avro.reader", true);
        consumerProps.put("schema.registry.url", "http://fake:8081");

        SpecificAvroSerde specificAvroSerde = getSpecificAvroSerde();

        SpecificAvroDeserializer specificAvroDeserializer = (SpecificAvroDeserializer) specificAvroSerde.deserializer();
        specificAvroDeserializer.configure(consumerProps, false);


        cf = new DefaultKafkaConsumerFactory(
                consumerProps,
                new StringDeserializer(),
                specificAvroDeserializer
        );

        Map<String, Object> producerProps = KafkaTestUtils.producerProps(embeddedKafkaBroker);
        pf = new DefaultKafkaProducerFactory(
                producerProps,
                new StringSerializer(),
                specificAvroSerde.serializer()
        );

        secondPf = new DefaultKafkaProducerFactory(
                producerProps,
                new StringSerializer(),
                specificAvroSerde.serializer()
        );

        thirdPf = new DefaultKafkaProducerFactory(
                producerProps,
                new StringSerializer(),
                specificAvroSerde.serializer()
        );

        consumer = cf.createConsumer();
        embeddedKafkaBroker.consumeFromAnEmbeddedTopic(consumer, kafkaOutputTopic);
    }

    @After
    public void tearDown() {
        consumer.close();
        embeddedKafkaBroker.destroy();
    }

    protected abstract SpecificAvroSerde getSpecificAvroSerde();
}

