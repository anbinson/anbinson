package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.springframework.kafka.test.utils.KafkaTestUtils;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class KafkaIntegrationTestUtils {

    public static <T> List<ConsumerRecord<String, T>> waitForAtLeast(Consumer<String, T> consumer, int minSize, Long timeout) throws InterruptedException {
        final long startTime = System.currentTimeMillis();
        final int tryTimes = 4;
        List<ConsumerRecord<String, T>> result = new ArrayList<>();
        while (true) {
            var records = KafkaTestUtils.getRecords(consumer, timeout / tryTimes);
            records.iterator().forEachRemaining(r -> result.add(r));
            if (result.size() >= minSize) {
                break;
            }
            if (System.currentTimeMillis() - startTime > timeout) {
                throw new RuntimeException();
            }
        }
        return result;
    }

    public static <T> ConsumerRecord<String, T> waitForOne(Consumer<String, T> consumer, Long timeout) {
        ConsumerRecords<String, T> records = KafkaTestUtils.getRecords(consumer, timeout);
        assertThat(records).hasSize(1);
        return records.iterator().next();
    }
}
