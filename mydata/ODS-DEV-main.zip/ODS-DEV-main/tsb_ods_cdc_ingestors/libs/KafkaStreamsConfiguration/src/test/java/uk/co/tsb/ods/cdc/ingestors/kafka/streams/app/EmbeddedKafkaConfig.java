package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.rule.EmbeddedKafkaRule;

@Profile("test")
@Configuration
class EmbeddedKafkaConfig {

    @Bean
    EmbeddedKafkaBroker embeddedKafkaBroker(EmbeddedKafkaRule embeddedKafkaRule) {
        EmbeddedKafkaBroker embeddedKafka = embeddedKafkaRule.getEmbeddedKafka();
        return embeddedKafka;
    }

    @Bean
    EmbeddedKafkaRule embeddedKafkaRule(@Value("${kafka.inputTopic}") String inputTopic, @Value("${kafka.outputTopic}") String outputTopic) {
        return new EmbeddedKafkaRule(1, true, inputTopic, outputTopic);
    }

}