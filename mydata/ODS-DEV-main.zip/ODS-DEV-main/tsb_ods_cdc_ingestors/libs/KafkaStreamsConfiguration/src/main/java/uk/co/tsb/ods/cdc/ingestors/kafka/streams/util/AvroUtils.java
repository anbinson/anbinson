package uk.co.tsb.ods.cdc.ingestors.kafka.streams.util;

import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.avro.specific.SpecificRecord;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

public class AvroUtils {

    private AvroUtils() {
    }

    public static <T extends SpecificRecord> T loadAvroResource(String resource, T object) throws IOException {
        final InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream(resource);
        if (stream == null) {
            throw new IOException(String.format("Resource '%s' not found", resource));
        }

        String content = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))
                .lines()
                .collect(Collectors.joining("\n"));

        final SpecificDatumReader<T> reader = new SpecificDatumReader<>(object.getSchema());

        final Decoder decoder = DecoderFactory.get().jsonDecoder(object.getSchema(), content);

        return reader.read(null, decoder);
    }
}
