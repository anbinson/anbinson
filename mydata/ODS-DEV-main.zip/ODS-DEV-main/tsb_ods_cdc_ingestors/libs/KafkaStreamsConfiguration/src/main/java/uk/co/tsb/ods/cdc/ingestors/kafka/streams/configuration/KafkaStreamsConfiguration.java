package uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.error.handling.StreamCustomMetricsWrapper;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.keys.KeyGenerator;

@Configuration
public class KafkaStreamsConfiguration {

    @Bean
    public KeyGenerator keyGenerator() {
        return new KeyGenerator();
    }

    @Bean
    public StreamCustomMetricsWrapper streamCustomMetricsWrapper() {
        return new StreamCustomMetricsWrapper();
    }
}
