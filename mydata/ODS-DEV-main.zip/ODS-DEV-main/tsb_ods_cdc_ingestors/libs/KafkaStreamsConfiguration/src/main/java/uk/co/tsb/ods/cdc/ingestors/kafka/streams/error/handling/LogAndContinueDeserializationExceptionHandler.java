package uk.co.tsb.ods.cdc.ingestors.kafka.streams.error.handling;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.streams.errors.DeserializationExceptionHandler;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.Map;

public class LogAndContinueDeserializationExceptionHandler implements DeserializationExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(LogAndContinueDeserializationExceptionHandler.class);

    @Override
    public DeserializationHandlerResponse handle(ProcessorContext context, ConsumerRecord<byte[], byte[]> record, Exception exception) {
        if (log.isErrorEnabled()) {
            var msg = MessageFormat.format("Exception caught during deserialization, taskId: {0}, topic: {1}, partition: {2}, offset: {3}, errorMessage: {4}",
                    context.taskId(), record.topic(), record.partition(), record.offset(), exception.getMessage());
            log.error(msg, exception);
        }

        StreamCustomMetricsWrapper.countDeserializationExceptions();

        return DeserializationHandlerResponse.CONTINUE;
    }

    @Override
    public void configure(Map<String, ?> configs) {
    }
}
