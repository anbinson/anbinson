package uk.co.tsb.ods.cdc.ingestors.kafka.streams.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;

public class CharSequenceUtils {

    private static final Logger logger = LoggerFactory.getLogger(CharSequenceUtils.class);

    private static ObjectMapper objectMapper = new ObjectMapper();

    private CharSequenceUtils() {
        // hide constructor for utils class
    }

    /**
     * @return string or null!
     */
    public static String safeToString(CharSequence charSequence) {
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    public static String extractValFromCDCJson(String jsonString) {
        try {
            JsonNode node = objectMapper.readTree(jsonString);
            return node.get("string").asText();
        } catch (Exception e) {
            logger.error(MessageFormat.format("Could not parse CDC data, input={0}, errorMessage={1}", jsonString, e.getMessage()), e);
            return jsonString;
        }
    }
}
