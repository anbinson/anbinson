package uk.co.tsb.ods.cdc.ingestors.kafka.streams.error.handling;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.streams.errors.ProductionExceptionHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class LogAndFailProductionExceptionHandler implements ProductionExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(LogAndFailProductionExceptionHandler.class);

    @Override
    public ProductionExceptionHandlerResponse handle(final ProducerRecord<byte[], byte[]> record,
                                                                                final Exception exception) {
        log.error("Production exception caught during execution: {}", exception);

        StreamCustomMetricsWrapper.countProductionExceptions();

        return ProductionExceptionHandlerResponse.FAIL;
    }

    @Override
    public void configure(final Map<String, ?> configs) {
    }
}
