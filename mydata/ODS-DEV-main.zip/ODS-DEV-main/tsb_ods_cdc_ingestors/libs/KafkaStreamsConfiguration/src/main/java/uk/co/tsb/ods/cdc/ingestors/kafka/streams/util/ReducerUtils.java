package uk.co.tsb.ods.cdc.ingestors.kafka.streams.util;


public class ReducerUtils {

    public static <T> T onlySecond(T v1, T v2) {
        return v2;
    }

    public static <T> T alwaysNull(T v1, T v2) {
        return null;
    }

}
