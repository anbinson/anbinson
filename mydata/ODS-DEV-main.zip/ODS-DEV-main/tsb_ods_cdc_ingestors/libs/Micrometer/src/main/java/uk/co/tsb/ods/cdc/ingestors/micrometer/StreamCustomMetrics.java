package uk.co.tsb.ods.cdc.ingestors.micrometer;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicLong;

@Component
public class StreamCustomMetrics {

    private static final String DELIVERY = "delivery";
    private static final String DELIVERY_TYPE = "push,sms";
    private static final String INBOUND_PAYMENT = "inbound_payment";
    private static final String DESERIALIZATION = "deserialization";
    private static final String PRODUCTION = "production";
    private static final String TYPE = "type";
    private static final String INPUT = "input";

    private final Gauge usersRegisteredTotal;
    private final AtomicLong usersRegisteredTotalValue;

    private final Gauge usersPushEnabledTotal;
    private final AtomicLong usersPushEnabledTotalValue;

    private final Gauge notificationsSentTotal;
    private final AtomicLong notificationsSentTotalValue;

    private final Gauge activeDevicesTotal;
    private final AtomicLong activeDevicesTotalValue;

    private final Gauge activeUsersTotal;
    private final AtomicLong activeUsersTotalValue;

    private Counter recordsInTotalEnrichedUsers;
    private Counter recordsInTotalUserInfo;
    private Counter recordsInTotalUsersByDasUser;
    private Counter recordsInTotal;
    private Counter recordsInTotalKC03;
    private Counter recordsInTotalDV01;
    private Counter recordsInTotalPE16;
    private Counter recordsInTotalPE11;
    private Counter recordsInTotalPE06;
    private Counter recordsInTotalEmsDeviceToken;
    private Counter recordsInTotalDeviceByDasUser;
    private Counter recordsInTotalNotifiableEvents;
    private Counter recordsInTotalSnsToken;
    private Counter recordsInBytes;
    private Counter recordsOutTotal;
    private Counter deserializationExceptionTotal;
    private Counter productionExceptionTotal;
    private Counter notificationsTotal;
    private Counter notificationsFailuresTotal;
    private Counter notificationsBytesTotal;
    private Counter recordsInTotalAccessCodes;
    private Counter recordsInTotalCredentials;
    private Counter recordsInTotalContracts;
    private Counter recordsInTotalServices;
    private Counter recordsInTotalUserPreference;
    private Counter recordsInTotalUsersByNumPersona;

    public StreamCustomMetrics(MeterRegistry meterRegistry) {
        recordsInTotal = Counter.builder("records_in_total")
                .description("Total number of input records since process start")
                .register(meterRegistry);

        recordsInTotalKC03 = Counter.builder("records_in_total_kc03")
                .description("Total number of KC03 input records since process start")
                .tag(INPUT, "KC03")
                .register(meterRegistry);

        recordsInTotalDV01 = Counter.builder("records_in_total_dv01")
                .description("Total number of DV01 input records since process start")
                .tag(INPUT, "DV01")
                .register(meterRegistry);

        recordsInTotalPE16 = Counter.builder("records_in_total_pe16")
                .description("Total number of PE16 input records since process start")
                .tag(INPUT, "PE16")
                .register(meterRegistry);

        recordsInTotalPE11 = Counter.builder("records_in_total_pe11")
                .description("Total number of PE11 input records since process start")
                .tag(INPUT, "PE11")
                .register(meterRegistry);

        recordsInTotalPE06 = Counter.builder("records_in_total_pe06")
                .description("Total number of PE06 input records since process start")
                .tag(INPUT, "PE06")
                .register(meterRegistry);

        recordsInTotalEmsDeviceToken = Counter.builder("records_in_total_ems_device_token")
                .description("Total number of EMS_DEVICE_TOKEN input records since process start")
                .tag(INPUT, "EMS_DEVICE_TOKEN")
                .register(meterRegistry);

        recordsInTotalDeviceByDasUser = Counter.builder("records_in_total_device_by_das_user")
                .description("Total number of DEVICE_BY_DAS_USER input records since process start")
                .tag(INPUT, "DEVICE_BY_DAS_USER")
                .register(meterRegistry);

        recordsInTotalSnsToken = Counter.builder("records_in_total_sns_token")
                .description("Total number of SNS_TOKEN input records since process start")
                .tag(INPUT, "SNS_TOKEN")
                .register(meterRegistry);

        recordsInTotalNotifiableEvents = Counter.builder("records_in_total_notifiable_event")
                .description("Total number of NOTIFIABLE_EVENT input records since process start")
                .tag(INPUT, "NOTIFIABLE_EVENT")
                .register(meterRegistry);

        recordsInTotalUserInfo = Counter.builder("records_in_total_user_info")
                .description("Total number of USER_INFO input records since process start")
                .tag(INPUT, "USER_INFO")
                .register(meterRegistry);

        recordsInTotalAccessCodes = Counter.builder("records_in_total_access_codes")
                .description("Total number of ACCESS_CODES input records since process start")
                .tag(INPUT, "ACCESS_CODES")
                .register(meterRegistry);

        recordsInTotalCredentials = Counter.builder("records_in_total_credentials")
                .description("Total number of CREDENTIALS input records since process start")
                .tag(INPUT, "CREDENTIALS")
                .register(meterRegistry);

        recordsInTotalUsersByDasUser = Counter.builder("records_in_total_users_by_das_user")
                .description("Total number of USERS_BY_DAS_USER input records since process start")
                .tag(INPUT, "USERS_BY_DAS_USER")
                .register(meterRegistry);

        recordsInTotalContracts = Counter.builder("records_in_total_contract")
                .description("Total number of CONTRACT input records since process start")
                .tag(INPUT, "CONTRACT")
                .register(meterRegistry);

        recordsInTotalServices = Counter.builder("records_in_total_service_contracts")
                .description("Total number of SERVICE_CONTRACT input records since process start")
                .tag(INPUT, "SERVICE_CONTRACT")
                .register(meterRegistry);

        recordsInTotalUserPreference = Counter.builder("records_in_total_user_preference")
                .description("Total number of USER_PREFERENCE input records since process start")
                .tag(INPUT, "USER_PREFERENCE")
                .register(meterRegistry);

        recordsInTotalUsersByNumPersona = Counter.builder("records_in_total_users_by_num_persona")
                .description("Total number of USERS_BY_NUM_PERSONA input records since process start")
                .tag(INPUT, "USERS_BY_NUM_PERSONA")
                .register(meterRegistry);

        recordsInTotalEnrichedUsers = Counter.builder("records_in_total_enriched_user")
                .description("Total number of ENRICHED_USER input records since process start")
                .tag(INPUT, "ENRICHED_USER")
                .register(meterRegistry);

        recordsInBytes = Counter.builder("records_in_bytes")
                .description("Total number of input bytes since process start")
                .register(meterRegistry);

        recordsOutTotal = Counter.builder("records_out_total")
                .description("Total number of output records since process start")
                .register(meterRegistry);

        deserializationExceptionTotal = Counter.builder("exception_total")
                .description("Total number of exceptions since process start")
                .tags(TYPE, DESERIALIZATION)
                .register(meterRegistry);

        productionExceptionTotal = Counter.builder("exception_total")
                .description("Total number of exceptions since process start")
                .tags(TYPE, PRODUCTION)
                .register(meterRegistry);

        notificationsTotal = Counter.builder("notifications_total")
                .description("total number of push notifications sent to customers since process start")
                .tags(TYPE, INBOUND_PAYMENT,
                        DELIVERY, DELIVERY_TYPE)
                .register(meterRegistry);

        notificationsFailuresTotal = Counter.builder("notifications_failures_total")
                .description("total number of failed notifications sent to customers since process start")
                .tags(TYPE, INBOUND_PAYMENT,
                        DELIVERY, DELIVERY_TYPE)
                .register(meterRegistry);

        notificationsBytesTotal = Counter.builder("notifications_bytes_total")
                .description("total number of bytes sent to customers since process start")
                .tags(TYPE, INBOUND_PAYMENT,
                        DELIVERY, DELIVERY_TYPE)
                .register(meterRegistry);

        this.usersRegisteredTotalValue = new AtomicLong(0);
        this.usersPushEnabledTotalValue = new AtomicLong(0);
        this.notificationsSentTotalValue = new AtomicLong(0);

        this.usersRegisteredTotal = Gauge.builder("users_registered_total", () -> usersRegisteredTotalValue.get())
                .description("Total number of customers who have used Push Notification(both enabled and disabled)")
                .register(meterRegistry);
        this.usersPushEnabledTotal = Gauge.builder("users_push_enabled_total", () -> usersPushEnabledTotalValue.get())
                .description("Total number of customers who have Push Notifications enabled on their devices")
                .register(meterRegistry);
        this.notificationsSentTotal = Gauge.builder("notifications_sent_total", () -> notificationsSentTotalValue.get())
                .description("Total number of Push Notifications sent to customers")
                .register(meterRegistry);

        this.activeDevicesTotalValue = new AtomicLong(0);
        this.activeDevicesTotal = Gauge.builder("active_devices_total", () -> activeDevicesTotalValue.get())
                .description("Total number of active devices")
                .register(meterRegistry);

        this.activeUsersTotalValue = new AtomicLong(0);
        this.activeUsersTotal = Gauge.builder("active_users_total", () -> activeUsersTotalValue.get())
                .description("Total number of active users")
                .register(meterRegistry);
    }

    public void countMsgIn() {
        recordsInTotal.increment();
    }

    public void countMsgOut() {
        recordsOutTotal.increment();
    }

    public void countNotifications(String notification) {
        notificationsTotal.increment();
        notificationsBytesTotal.increment(notification.getBytes().length);
    }

    public void countFailedNotifications() {
        notificationsFailuresTotal.increment();
    }

    public void countKC03() {
        recordsInTotalKC03.increment();
    }

    public void countDV01() {
        recordsInTotalDV01.increment();
    }

    public void countPE06() {
        recordsInTotalPE06.increment();
    }

    public void countPE16() {
        recordsInTotalPE16.increment();
    }

    public void countDeserializationExceptions() {
        deserializationExceptionTotal.increment();
    }

    public void countProductionExceptions() {
        productionExceptionTotal.increment();
    }

    public void countEmsDeviceTokens() {
        recordsInTotalEmsDeviceToken.increment();
    }

    public void countDeviceByDasUser() {
        recordsInTotalDeviceByDasUser.increment();
    }

    public void countSnsToken() {
        recordsInTotalSnsToken.increment();
    }

    public void countNotifiableEvent() {
        recordsInTotalNotifiableEvents.increment();
    }

    public void countPE11() {
        recordsInTotalPE11.increment();
    }

    public void countUserInfo() {
        recordsInTotalUserInfo.increment();
    }

    public void countAccessCode() {
        recordsInTotalAccessCodes.increment();
    }

    public void countCredentials() {
        recordsInTotalCredentials.increment();
    }

    public void countUsersByDasUser() {
        recordsInTotalUsersByDasUser.increment();
    }

    public void countContract() {
        recordsInTotalContracts.increment();
    }

    public void countServices() {
        recordsInTotalServices.increment();
    }

    public void countUserPreference() {
        recordsInTotalUserPreference.increment();
    }

    public void countUsersByNumPersona() {
        recordsInTotalUsersByNumPersona.increment();
    }

    public void countEnrichedEvent() {
        recordsInTotalEnrichedUsers.increment();
    }

    public void setUsersRegisteredTotal(long currentValue) {
        this.usersRegisteredTotalValue.set(currentValue);
    }

    public void setUsersPushEnabledTotal(long currentValue) {
        this.usersPushEnabledTotalValue.set(currentValue);
    }

    public void setNotificationsSentTotal(long currentValue) {
        this.notificationsSentTotalValue.set(currentValue);
    }

    public void setActiveUsersTotal(long currentValue) {
        this.activeUsersTotalValue.set(currentValue);
    }

    public void setActiveDevicesTotal(long currentValue) {
        this.activeDevicesTotalValue.set(currentValue);
    }
}