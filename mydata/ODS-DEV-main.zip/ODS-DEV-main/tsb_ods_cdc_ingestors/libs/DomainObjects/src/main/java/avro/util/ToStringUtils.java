package avro.util;

import avro.DP01.DP01Products;
import avro.EMSEnricherIBUserInfo.EMSEnricherIBUserInfo;
import avro.EnrichedEventPerUser;

import com.tsb.ods.stream.schema.avro.BS4600.BS46TransactionType;
import com.tsb.ods.stream.schema.avro.DV01.DV01Accounts;
import com.tsb.ods.stream.schema.avro.KC0300.KC03Transactions;
import com.tsb.ods.stream.schema.avro.KC4301.KC43TransactionsHistory;
import com.tsb.ods.stream.schema.avro.PE06.PE06Contracts;

import avro.PE11.PE11Customer;
import avro.PE16.PE16ContractCustomerGroupBy;
import avro.UserPreference;
import avro.cdc.NotifiableEventPerUser;
import avro.ems.*;
import avro.tbbvbsalias.TbbvBsAlias;
import avro.tbbvbsauthdata.TbbvBsAuthDataCredential;
import avro.tbbvbscodigosaccesso.TbbvBsCodigoAccesso;
import avro.tbbvbscontratos.TbbvBsContrato;
import avro.tbbvbsenrollments.DeviceByDASUser;
import avro.tbbvbsservicios.TbbvBsServicio;
import avro.tbbvbsusuarios.TbbvBsUsuario;
import tsb.ems.mb.avro.NotificationRequest;

public class ToStringUtils {
	
	public static String toString(KC43TransactionsHistory kc43) {
		if (kc43 == null) {
			return "null";
		}
		final var sb = new StringBuilder("KC43TransactionsHistory{");
		sb.append("CODENTID='").append(kc43.getCODENTID());//.append('\'')
//		sb.append(", DESCOMOP='").append(bs46.getDESCOMOP()).append('\'');
//		sb.append(", CODCOMUN=").append(bs46.getCODCOMUN());
//		sb.append(", IDIOMA='").append(bs46.getIDIOMA()).append('\'');
//		sb.append(", REDUCIDO=").append(bs46.getREDUCIDO());
		sb.append('}');
		return sb.toString();
	}
	
	public static String toString(BS46TransactionType bs46) {
		if (bs46 == null) {
			return "null";
		}
		final var sb = new StringBuilder("BS46TransactionType{");
		sb.append("CODCOMOP='").append(bs46.getCODCOMOP());//.append('\'')
//		sb.append(", DESCOMOP='").append(bs46.getDESCOMOP()).append('\'');
//		sb.append(", CODCOMUN=").append(bs46.getCODCOMUN());
//		sb.append(", IDIOMA='").append(bs46.getIDIOMA()).append('\'');
//		sb.append(", REDUCIDO=").append(bs46.getREDUCIDO());
		sb.append('}');
		return sb.toString();
	}

    public static String toString(TbbvBsServicio value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("TbbvBsServicio{");
        sb.append("SERVICE='").append(value.getSERVICE()).append('\'');
        sb.append(", DASCONTRACT='").append(value.getDASCONTRACT()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(KC03Transactions kc03) {
        if (kc03 == null) {
            return "null";
        }
        final var sb = new StringBuilder("KC03Transactions{");
        sb.append("CODENTID='").append(kc03.getCODENTID()).append('\'');
        sb.append(", TIPPRODUCT='").append(kc03.getTIPPRODUCT()).append('\'');
        sb.append(", CODCONTRAT=").append(kc03.getCODCONTRAT());
        sb.append(", IMPNETOPER='").append(kc03.getIMPNETOPER()).append('\'');
        sb.append(", CONCPREDUC=").append(kc03.getCONCPREDUC());
        sb.append(", RESTOCONCP='").append(kc03.getRESTOCONCP()).append('\'');
        sb.append(", CODIDIVI='").append(kc03.getCODIDIVI()).append('\'');
        sb.append('}');

        return sb.toString();
    }

    public static String toString(DV01Accounts dv01) {
        if (dv01 == null) {
            return "null";
        }
        final var sb = new StringBuilder("DV01Accounts{");
        sb.append("CODENTID='").append(dv01.getCODENTID()).append('\'');
        sb.append(", TIPPRODUCT='").append(dv01.getTIPPRODUCT()).append('\'');
        sb.append(", CODCONTRAT=").append(dv01.getCODCONTRAT());
        sb.append(", CODPRODO='").append(dv01.getCODPRODO()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(NotifiableEventPerUser event) {
        if (event == null) {
            return "null";
        }
        final var sb = new StringBuilder("NotifiableEventPerUser{");
        sb.append("EVENTID='").append(event.getEVENTID()).append('\'');
        sb.append(", NUMPERSONA='").append(event.getNUMPERSONA()).append('\'');
        sb.append(", EVENTTYPE='").append(event.getEVENTTYPE()).append('\'');
        sb.append(", CODENTID='").append(event.getCODENTID()).append('\'');
        sb.append(", TIPPRODUCT='").append(event.getTIPPRODUCT()).append('\'');
        sb.append(", CODCONTRAT='").append(event.getCODCONTRAT()).append('\'');
        sb.append(", IMPNETOPER='").append(event.getIMPNETOPER()).append('\'');
        sb.append(", CONCPREDUC=").append(event.getCONCPREDUC());
        sb.append(", RESTOCONCP='").append(event.getRESTOCONCP()).append('\'');
        sb.append(", CODIDIVI='").append(event.getCODIDIVI()).append('\'');
        sb.append(", CODPRODO='").append(event.getCODPRODO()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(PE16ContractCustomerGroupBy contractCustomer) {
        if (contractCustomer == null) {
            return "null";
        }
        final var sb = new StringBuilder("PE16ContractCustomerGroupBy{");
        sb.append("CODENTID='").append(contractCustomer.getCODENTID()).append('\'');
        sb.append(", TIPPRODUCT='").append(contractCustomer.getTIPPRODUCT()).append('\'');
        sb.append(", CODCONTRAT=").append(contractCustomer.getCODCONTRAT());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(PE06Contracts pe06) {
        if (pe06 == null) {
            return "null";
        }
        final var sb = new StringBuilder("PE06Contracts{");
        sb.append("CODENTID='").append(pe06.getCODENTID()).append('\'');
        sb.append(", TIPPRODUCT='").append(pe06.getTIPPRODUCT()).append('\'');
        sb.append(", CODCONTRAT=").append(pe06.getCODCONTRAT());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(PE11Customer pe11) {
        if (pe11 == null) {
            return "null";
        }
        final var sb = new StringBuilder("PE11Customer{");
        sb.append("NUMPERSONA=").append(pe11.getNUMPERSONA());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(EMSEnricherIBUserInfo userDetails) {
        if (userDetails == null) {
            return "null";
        }
        final var sb = new StringBuilder("EMSEnricherIBUserInfo{");
        sb.append("NUMPERSONA='").append(userDetails.getNUMPERSONA()).append('\'');
        sb.append(", DASUSER='").append(userDetails.getDASUSER()).append('\'');
        sb.append(", USERID='").append(userDetails.getUSERID()).append('\'');
        sb.append(", PREFERENCES=").append(userDetails.getPREFERENCES());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(EnrichedEventPerUser event) {
        if (event == null) {
            return "null";
        }
        final var sb = new StringBuilder("EnrichedEventPerUser{");
        sb.append("EVENTID='").append(event.getEVENTID()).append('\'');
        sb.append(", NUMPERSONA='").append(event.getNUMPERSONA()).append('\'');
        sb.append(", EVENTTYPE='").append(event.getEVENTTYPE()).append('\'');
        sb.append(", CODENTID='").append(event.getCODENTID()).append('\'');
        sb.append(", TIPPRODUCT='").append(event.getTIPPRODUCT()).append('\'');
        sb.append(", CODCONTRAT='").append(event.getCODCONTRAT()).append('\'');
        sb.append(", IMPNETOPER='").append(event.getIMPNETOPER()).append('\'');
        sb.append(", CONCPREDUC=").append(event.getCONCPREDUC());
        sb.append(", RESTOCONCP='").append(event.getRESTOCONCP()).append('\'');
        sb.append(", CODIDIVI='").append(event.getCODIDIVI()).append('\'');
        sb.append(", CODPRODO='").append(event.getCODPRODO()).append('\'');
        sb.append(", DASUSER='").append(event.getDASUSER()).append('\'');
        sb.append(", USERID='").append(event.getUSERID()).append('\'');
        sb.append(", PREFERENCES=").append(event.getPREFERENCES());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(MessageUnsent msg) {
        if (msg == null) {
            return "null";
        }
        final var sb = new StringBuilder("MessageUnsent{");
        sb.append("notificationId='").append(msg.getNotificationId()).append('\'');
        sb.append(", eventId='").append(msg.getEventId()).append('\'');
        sb.append(", payload='").append(msg.getPayload()).append('\'');
        sb.append(", snsToken='").append(msg.getSnsToken()).append('\'');
        sb.append(", deviceToken='").append(msg.getDeviceToken()).append('\'');
        sb.append(", deviceType='").append(msg.getDeviceType()).append('\'');
        sb.append(", DASUSER='").append(msg.getDASUSER()).append('\'');
        sb.append(", DEVICEID='").append(msg.getDEVICEID()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(EmsObsoleteSnsToken msg) {
        if (msg == null) {
            return "null";
        }
        final var sb = new StringBuilder("EmsObsoleteSnsToken{");
        sb.append("DASUSER='").append(msg.getDASUSER()).append('\'');
        sb.append(", DEVICEID='").append(msg.getDEVICEID()).append('\'');
        sb.append(", snsToken='").append(msg.getSnsToken()).append('\'');
        sb.append('}');
        return sb.toString();

    }

    public static String toString(MessageSent msg) {
        if (msg == null) {
            return "null";
        }
        final var sb = new StringBuilder("MessageSent{");
        sb.append("notificationId='").append(msg.getNotificationId()).append('\'');
        sb.append(", eventId='").append(msg.getEventId()).append('\'');
        sb.append(", messageId='").append(msg.getMessageId()).append('\'');
        sb.append(", deviceId='").append(msg.getDeviceId()).append('\'');
        sb.append(", errorCode='").append(msg.getErrorCode()).append('\'');
        sb.append(", payload='").append(msg.getPayload()).append('\'');
        sb.append(", sentTime=").append(msg.getSentTime());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(EmsSnsToken emsSnsToken) {
        if (emsSnsToken == null) {
            return "null";
        }
        final var sb = new StringBuilder("EmsSnsToken{");
        sb.append("DASUSER='").append(emsSnsToken.getDASUSER()).append('\'');
        sb.append(", DEVICEID='").append(emsSnsToken.getDEVICEID()).append('\'');
        sb.append(", DEVICETOKEN='").append(emsSnsToken.getDEVICETOKEN()).append('\'');
        sb.append(", SNSTOKEN='").append(emsSnsToken.getSNSTOKEN()).append('\'');
        sb.append(", LAST_UPDATE=").append(emsSnsToken.getLASTUPDATE());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(NotificationRequest notificationRequest) {
        if (notificationRequest == null) {
            return "null";
        }
        final var sb = new StringBuilder("NotificationRequest{");
        sb.append("notification_id='").append(notificationRequest.getNotificationId()).append('\'');
        sb.append(", application_code='").append(notificationRequest.getApplicationCode()).append('\'');
        sb.append(", message_type_code='").append(notificationRequest.getMessageTypeCode()).append('\'');
        sb.append(", target='").append(notificationRequest.getTarget()).append('\'');
        sb.append(", created_at='").append(notificationRequest.getCreatedAt()).append('\'');
        sb.append(", correlation_id='").append(notificationRequest.getCorrelationId()).append('\'');
        sb.append(", properties=").append(notificationRequest.getProperties());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(TbbvBsCodigoAccesso codigoAccesso) {
        if (codigoAccesso == null) {
            return "null";
        }
        final var sb = new StringBuilder("TbbvBsCodigoAccesso{");
        sb.append("DASACESS='").append(codigoAccesso.getDASACESS()).append('\'');
        sb.append(", DASUSER='").append(codigoAccesso.getDASACESS()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(TbbvBsAuthDataCredential v) {
        if (v == null) {
            return "null";
        }
        final var sb = new StringBuilder("TbbvBsAuthDataCredential{");
        sb.append("DASACCESS='").append(v.getDASACCESS()).append('\'');
        sb.append(", USERID='").append(v.getUSERID()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(TbbvBsUsuario usuario) {
        if (usuario == null) {
            return "null";
        }
        final var sb = new StringBuilder("TbbvBsUsuario{");
        sb.append("DASUSER='").append(usuario.getDASUSER()).append('\'');
        sb.append(", DASCONTRACT='").append(usuario.getDASCONTRACT()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(TbbvBsContrato tbbvBsContrato) {
        if (tbbvBsContrato == null) {
            return "null";
        }
        final var sb = new StringBuilder("TbbvBsContrato{");
        sb.append("DASCONTRACT='").append(tbbvBsContrato.getDASCONTRACT()).append('\'');
        sb.append(", NUMPERSONA='").append(tbbvBsContrato.getNUMPERSONA()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(DeviceByDASUser deviceByDasUser) {
        if (deviceByDasUser == null) {
            return "null";
        }
        final var sb = new StringBuilder("DeviceByDASUser{");
        sb.append("DASUSER='").append(deviceByDasUser.getDASUSER()).append('\'');
        sb.append(", DEVICEID='").append(deviceByDasUser.getDEVICEID()).append('\'');
        sb.append(", devices=").append(deviceByDasUser.getDevices());
        sb.append('}');
        return sb.toString();

    }

    public static String toString(EmsDeviceToken emsDeviceToken) {
        if (emsDeviceToken == null) {
            return "null";
        }
        final var sb = new StringBuilder("EmsDeviceToken{");
        sb.append("DASUSER='").append(emsDeviceToken.getDASUSER()).append('\'');
        sb.append(", DEVICETYPE='").append(emsDeviceToken.getDEVICETYPE()).append('\'');
        sb.append(", DEVICEID='").append(emsDeviceToken.getDEVICEID()).append('\'');
        sb.append(", DEVICETOKEN='").append(emsDeviceToken.getDEVICETOKEN()).append('\'');
        sb.append(", LAST_UPDATE=").append(emsDeviceToken.getLASTUPDATE());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(EmsDeviceInfo emsDeviceInfo) {
        if (emsDeviceInfo == null) {
            return "null";
        }
        final var sb = new StringBuilder("EmsDeviceInfo{");
        sb.append("DASUSER='").append(emsDeviceInfo.getDASUSER()).append('\'');
        sb.append(", DEVICEID='").append(emsDeviceInfo.getDEVICEID()).append('\'');
        sb.append(", DEVICETYPE='").append(emsDeviceInfo.getDEVICETYPE()).append('\'');
        sb.append(", DASDEVICE=").append(emsDeviceInfo.getDASDEVICE());
        sb.append(", DEVICETOKEN='").append(emsDeviceInfo.getDEVICETOKEN()).append('\'');
        sb.append(", SNSTOKEN='").append(emsDeviceInfo.getSNSTOKEN()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(DP01Products value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("DP01Products{");
        sb.append("CODENTID='").append(value.getCODENTID()).append('\'');
        sb.append(", CODPRODO='").append(value.getCODPRODO()).append('\'');
        sb.append(", DESPRODO='").append(value.getDESPRODO()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(TbbvBsAlias value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("TbbvBsAlias{");
        sb.append("CODENTID='").append(value.getCODENTID()).append('\'');
        sb.append(", TIPPRODUCT='").append(value.getTIPPRODUCT()).append('\'');
        sb.append(", CODCONTRAT='").append(value.getCODCONTRAT()).append('\'');
        sb.append(", DASUSER='").append(value.getDASUSER()).append('\'');
//        sb.append(", ALIASID='").append(value.getALIASID()).append('\'');
//        sb.append(", CODE_ALIAS='").append(value.getCODEALIAS()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(EmsUsersByUserId value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("EmsUsersByUserId{");
        sb.append("USERID='").append(value.getUSERID()).append('\'');
        sb.append(", NUMPERSONA='").append(value.getNUMPERSONA()).append('\'');
        sb.append(", DASUSER='").append(value.getDASUSER()).append('\'');
        sb.append(", DASCONTRACT='").append(value.getDASCONTRACT()).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static String toString(UserPreference value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("UserPreference{");
        sb.append("DASUSER='").append(value.getDASUSER()).append('\'');
        sb.append(", PREFERENCES=").append(value.getPREFERENCES());
        sb.append(", LAST_UPDATE=").append(value.getLASTUPDATE());
        sb.append('}');
        return sb.toString();
    }
}
