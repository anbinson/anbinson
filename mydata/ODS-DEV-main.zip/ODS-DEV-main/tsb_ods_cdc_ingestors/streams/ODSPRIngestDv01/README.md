### Postman Data query

Link: http://10.81.70.109:8082/topics/int_kafka.pushz.sourcedb.dv0000.db2inte.dv0100

{

"key_schema": "{\"type\": \"string\"}",

"value_schema": "{ \"type\": \"record\", \"name\": \"CDCTabledv0100\", \"namespace\": \"uk.co.tsb.cdc.dv0100\", \"fields\": [ { \"name\": \"beforeImage\", \"type\": [ \"null\", { \"type\": \"record\", \"name\": \"DV0100\", \"fields\": [ { \"name\": \"BS0100_CODENTID\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0100_CODENTID\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"PE0600_TIPPRODUCT\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE0600_TIPPRODUCT\", \"length\": 3 }, \"default\": \"\" }, { \"name\": \"PE0600_CODCONTRAT\", \"type\": { \"type\": \"long\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"PE0600_CODCONTRAT\", \"precision\": 15, \"scale\": 0 }, \"default\": 0 }, { \"name\": \"DP0100_CODPRODO\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"DP0100_CODPRODO\", \"length\": 8 }, \"default\": \"\" }, { \"name\": \"DV0100_COLECTIVO\", \"type\": { \"type\": \"int\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_COLECTIVO\", \"precision\": 8, \"scale\": 0 }, \"default\": 0 }, { \"name\": \"DP3800_CODCANAL\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"DP3800_CODCANAL\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"BS1100_CODCNAE\", \"type\": { \"type\": \"int\", \"logicalType\": \"INTEGER\", \"dbColumnName\": \"BS1100_CODCNAE\" }, \"default\": 0 }, { \"name\": \"PE1100_NUMPERSONA\", \"type\": { \"type\": \"int\", \"logicalType\": \"INTEGER\", \"dbColumnName\": \"PE1100_NUMPERSONA\" }, \"default\": 0 }, { \"name\": \"BS1300_CODPERSOLI\", \"type\": { \"type\": \"int\", \"logicalType\": \"SMALLINT\", \"dbColumnName\": \"BS1300_CODPERSOLI\" }, \"default\": 0 }, { \"name\": \"KM0400_INDMARCA\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"KM0400_INDMARCA\", \"length\": 1 }, \"default\": \"\" }, { \"name\": \"KC0100_FECHAAPERT\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"KC0100_FECHAAPERT\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"DV0100_FECCONTRAT\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"DV0100_FECCONTRAT\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"KC0100_FECHAVENCI\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"KC0100_FECHAVENCI\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"KC0100_FEULRENOVA\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"KC0100_FEULRENOVA\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"KC0100_CODPERIODO\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"KC0100_CODPERIODO\", \"length\": 1 }, \"default\": \"\" }, { \"name\": \"KC0100_NUMPERIODO\", \"type\": { \"type\": \"int\", \"logicalType\": \"SMALLINT\", \"dbColumnName\": \"KC0100_NUMPERIODO\" }, \"default\": 0 }, { \"name\": \"TP1100_CODVALSEGM\", \"type\": { \"type\": \"int\", \"logicalType\": \"SMALLINT\", \"dbColumnName\": \"TP1100_CODVALSEGM\" }, \"default\": 0 }, { \"name\": \"TP1100_CODVALSGMN\", \"type\": { \"type\": \"int\", \"logicalType\": \"SMALLINT\", \"dbColumnName\": \"TP1100_CODVALSGMN\" }, \"default\": 0 }, { \"name\": \"KC0100_ACCIVENCIM\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"KC0100_ACCIVENCIM\", \"length\": 1 }, \"default\": \"\" }, { \"name\": \"KC0100_RENONLINE\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"KC0100_RENONLINE\", \"length\": 1 }, \"default\": \"\" }, { \"name\": \"BS0200_CODCENTRO\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0200_CODCENTRO\", \"length\": 6 }, \"default\": \"\" }, { \"name\": \"BS1700_CODSECBESP\", \"type\": { \"type\": \"int\", \"logicalType\": \"SMALLINT\", \"dbColumnName\": \"BS1700_CODSECBESP\" }, \"default\": 0 }, { \"name\": \"TS0900_CODIDIVI\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"TS0900_CODIDIVI\", \"length\": 3 }, \"default\": \"\" }, { \"name\": \"KC0100_FEALTATARI\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"KC0100_FEALTATARI\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"KC0100_FEULTLIQUI\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"KC0100_FEULTLIQUI\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"KC0100_FEPROLIQUI\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"KC0100_FEPROLIQUI\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"KC0100_DIALIQUIDA\", \"type\": { \"type\": \"int\", \"logicalType\": \"SMALLINT\", \"dbColumnName\": \"KC0100_DIALIQUIDA\" }, \"default\": 0 }, { \"name\": \"DV0100_TMSULTMVTO\", \"type\": { \"type\": \"string\", \"logicalType\": \"TIMESTAMP\", \"dbColumnName\": \"DV0100_TMSULTMVTO\", \"length\": 26 }, \"default\": \"\" }, { \"name\": \"KC0100_SALDOULLIQ\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"KC0100_SALDOULLIQ\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0100_SALDMEDIO1\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_SALDMEDIO1\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0100_SALDMEDIO2\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_SALDMEDIO2\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0100_SALDMEDIO3\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_SALDMEDIO3\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0100_SALDMEDIO4\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_SALDMEDIO4\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0100_FECULTSALM\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"DV0100_FECULTSALM\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"KC0100_SDOANPRMOV\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"KC0100_SDOANPRMOV\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"KC0100_TSPRIMMVTO\", \"type\": { \"type\": \"string\", \"logicalType\": \"TIMESTAMP\", \"dbColumnName\": \"KC0100_TSPRIMMVTO\", \"length\": 26 }, \"default\": \"\" }, { \"name\": \"KC0100_SITUACION\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"KC0100_SITUACION\", \"length\": 1 }, \"default\": \"\" }, { \"name\": \"KC0100_TSITUACION\", \"type\": { \"type\": \"string\", \"logicalType\": \"TIMESTAMP\", \"dbColumnName\": \"KC0100_TSITUACION\", \"length\": 26 }, \"default\": \"\" }, { \"name\": \"KC0100_FEINACTIV\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"KC0100_FEINACTIV\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"KC0100_SALDO\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"KC0100_SALDO\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"KC0100_DISPONIBLE\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"KC0100_DISPONIBLE\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0100_LIMITDISPO\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_LIMITDISPO\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0100_LIMITEREM\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_LIMITEREM\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0100_NOVENCIDO\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_NOVENCIDO\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0100_DEVOLCCO\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_DEVOLCCO\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0100_DEVOLCDI\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_DEVOLCDI\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0100_FECRETMOV\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"DV0100_FECRETMOV\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"DV0100_IMPRETENIDO\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_IMPRETENIDO\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"KC0100_INDICATORS\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"KC0100_INDICATORS\", \"length\": 20 }, \"default\": \"\" }, { \"name\": \"DV0100_INDICATOR2\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"DV0100_INDICATOR2\", \"length\": 20 }, \"default\": \"\" }, { \"name\": \"DV0100_INDICATOR3\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"DV0100_INDICATOR3\", \"length\": 20 }, \"default\": \"\" }, { \"name\": \"DV0100_TIPPRODREL\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"DV0100_TIPPRODREL\", \"length\": 3 }, \"default\": \"\" }, { \"name\": \"DV0100_CODCONTREL\", \"type\": { \"type\": \"long\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_CODCONTREL\", \"precision\": 15, \"scale\": 0 }, \"default\": 0 }, { \"name\": \"DP0600_CODENTREL\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"DP0600_CODENTREL\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"BS0000_FECULTACT\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"BS0000_FECULTACT\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"BS0000_HORULTACT\", \"type\": { \"type\": \"string\", \"logicalType\": \"TIME\", \"dbColumnName\": \"BS0000_HORULTACT\", \"length\": 8 }, \"default\": \"\" }, { \"name\": \"BS0000_CODTERMINA\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0000_CODTERMINA\", \"length\": 8 }, \"default\": \"\" }, { \"name\": \"BS0000_CODUSUARIO\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0000_CODUSUARIO\", \"length\": 8 }, \"default\": \"\" }, { \"name\": \"BS0100_CODENTCOM\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0100_CODENTCOM\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"BS0200_CODCTRCOM\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0200_CODCTRCOM\", \"length\": 6 }, \"default\": \"\" }, { \"name\": \"PE1100_INDIDIOMA\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE1100_INDIDIOMA\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"DV0100_CLAVEBAR\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"DV0100_CLAVEBAR\", \"length\": 8 }, \"default\": \"\" }, { \"name\": \"DV0100_NUMEXTRAC\", \"type\": { \"type\": \"int\", \"logicalType\": \"SMALLINT\", \"dbColumnName\": \"DV0100_NUMEXTRAC\" }, \"default\": 0 }, { \"name\": \"DV0100_SDOEXTRAC\", \"type\": { \"type\": \"string\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"DV0100_SDOEXTRAC\", \"precision\": 15, \"scale\": 2 }, \"default\": \"0\" }, { \"name\": \"DV0000_MARCAINFCO\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"DV0000_MARCAINFCO\", \"length\": 4 }, \"default\": \"\" }, { \"name\": \"SYS_START\", \"type\": { \"type\": \"string\", \"logicalType\": \"TIMESTAMP\", \"dbColumnName\": \"SYS_START\", \"length\": 32 }, \"default\": \"\" }, { \"name\": \"SYS_END\", \"type\": { \"type\": \"string\", \"logicalType\": \"TIMESTAMP\", \"dbColumnName\": \"SYS_END\", \"length\": 32 }, \"default\": \"\" }, { \"name\": \"TRANS_ID\", \"type\": [ { \"type\": \"string\", \"logicalType\": \"TIMESTAMP\", \"dbColumnName\": \"TRANS_ID\", \"length\": 32 }, \"null\" ], \"default\": \"\" } ] } ] }, { \"name\": \"afterImage\", \"type\": [ \"null\", \"DV0100\" ] }, { \"name\": \"A_ENTTYP\", \"type\": [ \"null\", \"string\" ] }, { \"name\": \"A_CCID\", \"type\": [ \"null\", \"string\" ] }, { \"name\": \"A_TIMSTAMP\", \"type\": [ \"null\", \"string\" ] } ] }",

"records": [

{

"key":"harpreet1221",

"value": {

    "beforeImage": { "uk.co.tsb.cdc.dv0100.DV0100":  {

        "BS0100_CODENTID": "test5",

        "PE0600_TIPPRODUCT": "test5",

        "PE0600_CODCONTRAT": 56786,

        "DP0100_CODPRODO": "DP0100_CODPRODO",

        "DV0100_COLECTIVO": 76,

        "DP3800_CODCANAL": "DP3800_CODCANAL",

        "BS1100_CODCNAE": 87,

        "PE1100_NUMPERSONA": 23,

        "BS1300_CODPERSOLI": 11,

        "KM0400_INDMARCA": "KM0400_INDMARCA",

        "KC0100_FECHAAPERT": "2020-12-11",

        "DV0100_FECCONTRAT": "2020-12-11",

        "KC0100_FECHAVENCI": "2020-12-11",

        "KC0100_FEULRENOVA": "2020-12-11",

        "KC0100_CODPERIODO": "KC0100_CODPERIODO",

        "KC0100_NUMPERIODO": 23,

        "TP1100_CODVALSEGM": 34,

        "TP1100_CODVALSGMN": 87,

        "KC0100_ACCIVENCIM": "KC0100_ACCIVENCIM",

        "KC0100_RENONLINE": "KC0100_RENONLINE",

        "BS0200_CODCENTRO": "BS0200_CODCENTRO",

        "BS1700_CODSECBESP": 98,

        "TS0900_CODIDIVI": "TS0900_CODIDIVI",

        "KC0100_FEALTATARI": "2020-12-11",

        "KC0100_FEULTLIQUI": "2020-12-11",

        "KC0100_FEPROLIQUI": "2020-12-11",

        "KC0100_DIALIQUIDA": 22,

        "DV0100_TMSULTMVTO": "2020-11-22-13.09.07.678996",

        "KC0100_SALDOULLIQ": "76.08",

        "DV0100_SALDMEDIO1": "4567.98",

        "DV0100_SALDMEDIO2": "2345.87",

        "DV0100_SALDMEDIO3": "646.97",

        "DV0100_SALDMEDIO4": "3632.86",

        "DV0100_FECULTSALM": "2020-12-11",

        "KC0100_SDOANPRMOV": "131.67",

        "KC0100_TSPRIMMVTO": "2020-11-22-13.09.07.678996",

        "KC0100_SITUACION": "KC0100_SITUACION",

        "KC0100_TSITUACION": "2020-11-22-13.09.07.678996",

        "KC0100_FEINACTIV": "2020-12-11",

        "KC0100_SALDO": "76.76",

        "KC0100_DISPONIBLE": "456.98",

        "DV0100_LIMITDISPO": "11.11",

        "DV0100_LIMITEREM": "98.09",

        "DV0100_NOVENCIDO": "67.02",

        "DV0100_DEVOLCCO": "1232.32",

        "DV0100_DEVOLCDI": "82.09",

        "DV0100_FECRETMOV": "2020-12-11",

        "DV0100_IMPRETENIDO": "76.76",

        "KC0100_INDICATORS": "KC0100_INDICATORS",

        "DV0100_INDICATOR2": "DV0100_INDICATOR2",

        "DV0100_INDICATOR3": "DV0100_INDICATOR3",

        "DV0100_TIPPRODREL": "DV0100_TIPPRODREL",

        "DV0100_CODCONTREL": 56789,

        "DP0600_CODENTREL": "DP0600_CODENTREL",

        "BS0000_FECULTACT": "2020-12-11",

        "BS0000_HORULTACT": "13:10:20",

        "BS0000_CODTERMINA": "BS0000_CODTERMINA",

        "BS0000_CODUSUARIO": "BS0000_CODUSUARIO",

        "BS0100_CODENTCOM": "BS0100_CODENTCOM",

        "BS0200_CODCTRCOM": "BS0200_CODCTRCOM",

        "PE1100_INDIDIOMA": "PE1100_INDIDIOMA",

        "DV0100_CLAVEBAR": "DV0100_CLAVEBAR",

        "DV0100_NUMEXTRAC": 87,

        "DV0100_SDOEXTRAC": "765.98",

        "DV0000_MARCAINFCO": "DV0000_MARCAINFCO",

        "SYS_START": "2020-11-22-13.09.07.678996",

        "SYS_END": "2020-11-22-13.09.07.678996",

        "TRANS_ID": {"string": "2020-11-22-13.09.07.678996"}

        } },

    "afterImage": { "uk.co.tsb.cdc.dv0100.DV0100":  {

        "BS0100_CODENTID": "test5",

        "PE0600_TIPPRODUCT": "test5",

        "PE0600_CODCONTRAT": 56786,

        "DP0100_CODPRODO": "DP0100_CODPRODO",

        "DV0100_COLECTIVO": 76,

        "DP3800_CODCANAL": "DP3800_CODCANAL",

        "BS1100_CODCNAE": 87,

        "PE1100_NUMPERSONA": 23,

        "BS1300_CODPERSOLI": 11,

        "KM0400_INDMARCA": "KM0400_INDMARCA",

        "KC0100_FECHAAPERT": "2020-12-11",

        "DV0100_FECCONTRAT": "2020-12-11",

        "KC0100_FECHAVENCI": "2020-12-11",

        "KC0100_FEULRENOVA": "2020-12-11",

        "KC0100_CODPERIODO": "KC0100_CODPERIODO",

        "KC0100_NUMPERIODO": 23,

        "TP1100_CODVALSEGM": 34,

        "TP1100_CODVALSGMN": 87,

        "KC0100_ACCIVENCIM": "KC0100_ACCIVENCIM",

        "KC0100_RENONLINE": "KC0100_RENONLINE",

        "BS0200_CODCENTRO": "BS0200_CODCENTRO",

        "BS1700_CODSECBESP": 98,

        "TS0900_CODIDIVI": "TS0900_CODIDIVI",

        "KC0100_FEALTATARI": "2020-12-11",

        "KC0100_FEULTLIQUI": "2020-12-11",

        "KC0100_FEPROLIQUI": "2020-12-11",

        "KC0100_DIALIQUIDA": 22,

        "DV0100_TMSULTMVTO": "2020-11-22-13.09.07.678996",

        "KC0100_SALDOULLIQ": "76.08",

        "DV0100_SALDMEDIO1": "4567.98",

        "DV0100_SALDMEDIO2": "2345.87",

        "DV0100_SALDMEDIO3": "646.97",

        "DV0100_SALDMEDIO4": "3632.86",

        "DV0100_FECULTSALM": "2020-12-11",

        "KC0100_SDOANPRMOV": "131.67",

        "KC0100_TSPRIMMVTO": "2020-11-22-13.09.07.678996",

        "KC0100_SITUACION": "KC0100_SITUACION",

        "KC0100_TSITUACION": "2020-11-22-13.09.07.678996",

        "KC0100_FEINACTIV": "2020-12-11",

        "KC0100_SALDO": "76.76",

        "KC0100_DISPONIBLE": "456.98",

        "DV0100_LIMITDISPO": "11.11",

        "DV0100_LIMITEREM": "98.09",

        "DV0100_NOVENCIDO": "67.02",

        "DV0100_DEVOLCCO": "1232.32",

        "DV0100_DEVOLCDI": "82.09",

        "DV0100_FECRETMOV": "2020-12-11",

        "DV0100_IMPRETENIDO": "76.76",

        "KC0100_INDICATORS": "KC0100_INDICATORS",

        "DV0100_INDICATOR2": "DV0100_INDICATOR2",

        "DV0100_INDICATOR3": "DV0100_INDICATOR3",

        "DV0100_TIPPRODREL": "DV0100_TIPPRODREL",

        "DV0100_CODCONTREL": 56789,

        "DP0600_CODENTREL": "DP0600_CODENTREL",

        "BS0000_FECULTACT": "2020-12-11",

        "BS0000_HORULTACT": "13:10:20",

        "BS0000_CODTERMINA": "BS0000_CODTERMINA",

        "BS0000_CODUSUARIO": "BS0000_CODUSUARIO",

        "BS0100_CODENTCOM": "BS0100_CODENTCOM",

        "BS0200_CODCTRCOM": "BS0200_CODCTRCOM",

        "PE1100_INDIDIOMA": "PE1100_INDIDIOMA",

        "DV0100_CLAVEBAR": "DV0100_CLAVEBAR",

        "DV0100_NUMEXTRAC": 87,

        "DV0100_SDOEXTRAC": "765.98",

        "DV0000_MARCAINFCO": "DV0000_MARCAINFCO",

        "SYS_START": "2020-11-22-13.09.07.678996",

        "SYS_END": "2020-11-22-13.09.07.678996",

        "TRANS_ID": {"string": "2020-11-22-13.09.07.678996"}

        } },

    "A_ENTTYP": {"string": "A_ENTTYP"},

    "A_CCID": {"string": "A_CCID" },

    "A_TIMSTAMP": {"string": "A_TIMSTAMP" }

}   

}

]

}
