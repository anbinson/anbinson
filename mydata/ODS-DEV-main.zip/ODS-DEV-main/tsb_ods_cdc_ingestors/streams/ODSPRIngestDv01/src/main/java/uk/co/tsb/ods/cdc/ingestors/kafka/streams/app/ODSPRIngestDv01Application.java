package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class}) 
public class ODSPRIngestDv01Application {
    public static void main(String[] args) {
        SpringApplication.run(ODSPRIngestDv01Application.class, args);
    }
}
