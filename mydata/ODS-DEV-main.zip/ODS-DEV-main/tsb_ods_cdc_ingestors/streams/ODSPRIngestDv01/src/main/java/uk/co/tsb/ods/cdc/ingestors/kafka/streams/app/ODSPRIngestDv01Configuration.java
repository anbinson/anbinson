package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;


import org.springframework.core.env.Environment;
import avro.util.ToStringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.handler.annotation.SendTo;
import com.tsb.ods.stream.schema.avro.DV01.DV01Accounts;

import uk.co.tsb.cdc.dv0100.CDCTabledv0100;
import uk.co.tsb.cdc.utils.CdcToStringUtils;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.EnableKafkaStreamsConfiguration;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.IngestProcessor;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.keys.KeyGenerator;
import uk.co.tsb.ods.cdc.ingestors.micrometer.EnableStreamMetricsConfiguration;
import uk.co.tsb.ods.cdc.ingestors.micrometer.StreamCustomMetrics;

import static uk.co.tsb.ods.cdc.ingestors.kafka.streams.util.CharSequenceUtils.safeToString;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import java.util.Objects;

@Slf4j
@Configuration
@EnableBinding(IngestProcessor.class)
@EnableKafkaStreamsConfiguration
@EnableStreamMetricsConfiguration
public class ODSPRIngestDv01Configuration {

	@Autowired
	private KeyGenerator keyGenerator;

	@Autowired
	private StreamCustomMetrics metrics;

	@Autowired
	private Environment environment;

	public static String timestampGenString(LocalDateTime timeStamp) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
        String formatDateTime = timeStamp.format(formatter);
		return formatDateTime;
    }
	public static CharSequence datetime(CharSequence string) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
		LocalDateTime dateTime = LocalDateTime.parse(string, formatter);
		CharSequence dateSequence;
		if(Integer.parseInt(String.valueOf(dateTime.getMonthValue()))<10){
			dateSequence = String.valueOf(dateTime.getYear())+"0"+String.valueOf(dateTime.getMonthValue());
		}
		else {
			dateSequence = String.valueOf(dateTime.getYear())+String.valueOf(dateTime.getMonthValue());
		}
		return dateSequence;
	}

	@StreamListener(IngestProcessor.INPUT)
	@SendTo(IngestProcessor.OUTPUT)
	public KStream<String, DV01Accounts> process(KStream<String, CDCTabledv0100> rawData) {
		
		return rawData
				.peek((key, value) -> {
					metrics.countMsgIn();
					if (log.isDebugEnabled()) {
						log.debug("Consuming {}", CdcToStringUtils.toString(value));
					}
				})
				.map((key, dv01) -> {
					DV01Accounts dv01Accounts= null;
					String newKey= null;
					LocalDateTime timeStamp = LocalDateTime.now();
					if(dv01.getAfterImage()!=null) {
						dv01Accounts = DV01Accounts.newBuilder()
								.setCODENTID(safeToString(dv01.getAfterImage().getBS0100CODENTID()))
								.setTIPPRODUCT(safeToString(dv01.getAfterImage().getPE0600TIPPRODUCT()))
								.setCODCONTRAT(dv01.getAfterImage().getPE0600CODCONTRAT())
								.setCODPRODO(safeToString(dv01.getAfterImage().getDP0100CODPRODO()))
								.setCOLECTIVO(dv01.getAfterImage().getDV0100COLECTIVO())
								.setCODCANAL(safeToString(dv01.getAfterImage().getDP3800CODCANAL()))
								.setCODCNAE(dv01.getAfterImage().getBS1100CODCNAE())
								.setNUMPERSONA(dv01.getAfterImage().getPE1100NUMPERSONA())
								.setCODPERSOLI(dv01.getAfterImage().getBS1300CODPERSOLI())
								.setINDMARCA(safeToString(dv01.getAfterImage().getKM0400INDMARCA()))
								.setFECHAAPERT(safeToString(dv01.getAfterImage().getKC0100FECHAAPERT()))
								.setFECCONTRAT(safeToString(dv01.getAfterImage().getDV0100FECCONTRAT()))
								.setFECHAVENCI(safeToString(dv01.getAfterImage().getKC0100FECHAVENCI()))
								.setFEULRENOVA(safeToString(dv01.getAfterImage().getKC0100FEULRENOVA()))
								.setCODPERIODO(safeToString(dv01.getAfterImage().getKC0100CODPERIODO()))
								.setNUMPERIODO(dv01.getAfterImage().getKC0100NUMPERIODO())
								.setCODVALSEGM(dv01.getAfterImage().getTP1100CODVALSEGM())
								.setCODVALSGMN(dv01.getAfterImage().getTP1100CODVALSGMN())
								.setACCIVENCIM(safeToString(dv01.getAfterImage().getKC0100ACCIVENCIM()))
								.setRENONLINE(safeToString(dv01.getAfterImage().getKC0100RENONLINE()))
								.setCODCENTRO(safeToString(dv01.getAfterImage().getBS0200CODCENTRO()))
								.setCODSECBESP(dv01.getAfterImage().getBS1700CODSECBESP())
								.setCODIDIVI(safeToString(dv01.getAfterImage().getTS0900CODIDIVI()))
								.setFEALTATARI(safeToString(dv01.getAfterImage().getKC0100FEALTATARI()))
								.setFEULTLIQUI(safeToString(dv01.getAfterImage().getKC0100FEULTLIQUI()))
								.setFEPROLIQUI(safeToString(dv01.getAfterImage().getKC0100FEPROLIQUI()))
								.setDIALIQUIDA(dv01.getAfterImage().getKC0100DIALIQUIDA())
								.setTMSULTMVTO(safeToString(dv01.getAfterImage().getDV0100TMSULTMVTO()))
								.setSALDOULLIQ(safeToString(dv01.getAfterImage().getKC0100SALDOULLIQ()))
								.setSALDMEDIO1(safeToString(dv01.getAfterImage().getDV0100SALDMEDIO1()))
								.setSALDMEDIO2(safeToString(dv01.getAfterImage().getDV0100SALDMEDIO2()))
								.setSALDMEDIO3(safeToString(dv01.getAfterImage().getDV0100SALDMEDIO3()))
								.setSALDMEDIO4(safeToString(dv01.getAfterImage().getDV0100SALDMEDIO4()))
								.setFECULTSALM(safeToString(dv01.getAfterImage().getDV0100FECULTSALM()))
								.setSDOANPRMOV(safeToString(dv01.getAfterImage().getKC0100SDOANPRMOV()))
								.setTSPRIMMVTO(safeToString(dv01.getAfterImage().getKC0100TSPRIMMVTO()))
								.setSITUACION(safeToString(dv01.getAfterImage().getKC0100SITUACION()))
								.setTSITUACION(safeToString(dv01.getAfterImage().getKC0100TSITUACION()))
								.setFEINACTIV(safeToString(dv01.getAfterImage().getKC0100FEINACTIV()))
								.setSALDO(safeToString(dv01.getAfterImage().getKC0100SALDO()))
								.setDISPONIBLE(safeToString(dv01.getAfterImage().getKC0100DISPONIBLE()))
								.setLIMITDISPO(safeToString(dv01.getAfterImage().getDV0100LIMITDISPO()))
								.setLIMITEREM(safeToString(dv01.getAfterImage().getDV0100LIMITEREM()))
								.setNOVENCIDO(safeToString(dv01.getAfterImage().getDV0100NOVENCIDO()))                            
								.setDEVOLCCO(safeToString(dv01.getAfterImage().getDV0100DEVOLCCO()))
								.setDEVOLCDI(safeToString(dv01.getAfterImage().getDV0100DEVOLCDI()))                            
								.setFECRETMOV(safeToString(dv01.getAfterImage().getDV0100FECRETMOV()))
								.setIMPRETENIDO(safeToString(dv01.getAfterImage().getDV0100IMPRETENIDO()))
								.setINDICATORS(safeToString(dv01.getAfterImage().getKC0100INDICATORS()))                            
								.setINDICATOR2(safeToString(dv01.getAfterImage().getDV0100INDICATOR2()))
								.setINDICATOR3(safeToString(dv01.getAfterImage().getDV0100INDICATOR3()))                            
								.setTIPPRODREL(safeToString(dv01.getAfterImage().getDV0100TIPPRODREL()))
								.setCODCONTREL(dv01.getAfterImage().getDV0100CODCONTREL())                            
								.setCODENTREL(safeToString(dv01.getAfterImage().getDP0600CODENTREL()))          
								.setFECULTACT(safeToString(dv01.getAfterImage().getBS0000FECULTACT()))   
								.setHORULTACT(safeToString(dv01.getAfterImage().getBS0000HORULTACT())) 
								.setCODTERMINA(safeToString(dv01.getAfterImage().getBS0000CODTERMINA())) 
								.setCODUSUARIO(safeToString(dv01.getAfterImage().getBS0000CODUSUARIO())) 
								.setCODENTCOM(safeToString(dv01.getAfterImage().getBS0100CODENTCOM()))                             
								.setCODCTRCOM(safeToString(dv01.getAfterImage().getBS0200CODCTRCOM())) 
								.setINDIDIOMA(safeToString(dv01.getAfterImage().getPE1100INDIDIOMA()))                             
								.setCLAVEBAR(safeToString(dv01.getAfterImage().getDV0100CLAVEBAR()))                            
								.setNUMEXTRAC(dv01.getAfterImage().getDV0100NUMEXTRAC()) 
								.setSDOEXTRAC(safeToString(dv01.getAfterImage().getDV0100SDOEXTRAC()))                            
								.setMARCAINFCO(safeToString(dv01.getAfterImage().getDV0000MARCAINFCO()))
								.setCONPEL(safeToString("78.98"))
								.setSYSSTART(timestampGenString(timeStamp))
								.setSYSEND(timestampGenString(timeStamp))
								.setTRANSID(timestampGenString(timeStamp))
								.setATCREATIONTIME(timestampGenString(timeStamp))
								.setATCREATIONUSER(safeToString(environment.getProperty("ATCREATIONUSER")))	
								.setATLASTMODIFIEDUSER(safeToString(environment.getProperty("ATCREATIONUSER")))
								.setATLASTMODIFIEDTIME(timestampGenString(timeStamp))
								.setXXCHECKSUM(safeToString(String.valueOf(dv01.getAfterImage().hashCode())))
								.setEXECTYPE("UPSERT")
								.build();
						newKey = keyGenerator.getPrivateTopicKey(dv01Accounts.getCODENTID(), dv01Accounts.getTIPPRODUCT(), dv01Accounts.getCODCONTRAT());
					}
					if(dv01.getAfterImage()==null) {
						dv01Accounts = DV01Accounts.newBuilder()
								.setCODENTID(safeToString(dv01.getAfterImage().getBS0100CODENTID()))
								.setTIPPRODUCT(safeToString(dv01.getAfterImage().getPE0600TIPPRODUCT()))
								.setCODCONTRAT(dv01.getAfterImage().getPE0600CODCONTRAT())                                
								.setEXECTYPE("DELETE")
								.build();
						newKey = keyGenerator.getPrivateTopicKey(dv01Accounts.getCODENTID(), dv01Accounts.getTIPPRODUCT(), dv01Accounts.getCODCONTRAT());
					}
					return new KeyValue<>(newKey, dv01Accounts);
				})
				.peek((key, value) -> {
					metrics.countMsgOut();
					if (log.isInfoEnabled()) {
						log.info("Producing {}", ToStringUtils.toString(value));
					}
				});
	}

}
