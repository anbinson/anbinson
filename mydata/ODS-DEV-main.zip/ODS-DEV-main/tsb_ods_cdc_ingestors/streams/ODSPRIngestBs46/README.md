### Postman Data query

Link: http://10.81.70.109:8082/topics/int_kafka.pushz.sourcedb.bs0000.db2inte.bs4600

{

"key_schema": "{\"type\": \"string\"}",

"value_schema": "{ \"type\": \"record\", \"name\": \"CDCTablebs4600\", \"namespace\": \"uk.co.tsb.cdc.bs4600\", \"fields\": [ { \"name\": \"beforeImage\", \"type\": [ \"null\", { \"type\": \"record\", \"name\": \"BS4600\", \"fields\": [ { \"name\": \"BS4600_CODCOMOP\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS4600_CODCOMOP\", \"length\": 8 }, \"default\": \"\" }, { \"name\": \"BS4600_DESCOMOP\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS4600_DESCOMOP\", \"length\": 31 }, \"default\": \"\" }, { \"name\": \"BS4600_CODCOMUN\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS4600_CODCOMUN\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"BS4600_IDIOMA\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS4600_IDIOMA\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"BS4600_REDUCIDO\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS4600_REDUCIDO\", \"length\": 12 }, \"default\": \"\" } ] } ] }, { \"name\": \"afterImage\", \"type\": [ \"null\", \"BS4600\" ] }, { \"name\": \"A_ENTTYP\", \"type\": [ \"null\", \"string\" ] }, { \"name\": \"A_CCID\", \"type\": [ \"null\", \"string\" ] }, { \"name\": \"A_TIMSTAMP\", \"type\": [ \"null\", \"string\" ] } ] }",

"records": [

{

"key":"harpreet1221",

"value": {

    "beforeImage": { "uk.co.tsb.cdc.bs4600.BS4600":  {

        "BS4600_CODCOMOP": "test4",

        "BS4600_DESCOMOP": "test4",

        "BS4600_CODCOMUN": "BS4600_CODCOMUN",

        "BS4600_IDIOMA": "BS4600_IDIOMA",

        "BS4600_REDUCIDO": "BS4600_REDUCIDO"

        } },

    "afterImage": { "uk.co.tsb.cdc.bs4600.BS4600":  {

        "BS4600_CODCOMOP": "test4",

        "BS4600_DESCOMOP": "test4",

        "BS4600_CODCOMUN": "BS4600_CODCOMUN",

        "BS4600_IDIOMA": "BS4600_IDIOMA",

        "BS4600_REDUCIDO": "BS4600_REDUCIDO"

        } },

    "A_ENTTYP": {"string": "A_ENTTYP"},

    "A_CCID": {"string": "A_CCID" },

    "A_TIMSTAMP": {"string": "A_TIMSTAMP" }

}   

}

]

}
