package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class}) 
public class ODSPRIngestBs46Application {
    public static void main(String[] args) {
        SpringApplication.run(ODSPRIngestBs46Application.class, args);
    }
}
