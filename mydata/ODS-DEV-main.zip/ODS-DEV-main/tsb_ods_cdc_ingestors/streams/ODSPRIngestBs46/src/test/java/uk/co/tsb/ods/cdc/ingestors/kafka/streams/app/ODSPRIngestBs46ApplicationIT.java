//package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;
//
//import com.tsb.ods.stream.schema.avro.KC0300.KC03Transactions;
//import io.confluent.kafka.schemaregistry.client.MockSchemaRegistryClient;
//import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
//import io.confluent.kafka.streams.serdes.avro.SpecificAvroSerde;
//import org.apache.kafka.clients.consumer.ConsumerRecords;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.kafka.test.utils.KafkaTestUtils;
//import org.springframework.test.context.junit4.SpringRunner;
//import uk.co.tsb.cdc.kc0300.CDCTablekc0300;
//import uk.co.tsb.cdc.kc0300.KC0300;
//import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.IngestProcessor;
//import uk.co.tsb.ods.cdc.ingestors.kafka.streams.keys.KeyGenerator;
//
//import java.io.IOException;
//import java.util.Random;
//import java.util.UUID;
//
//import static org.assertj.core.api.Assertions.assertThat;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest(
//		webEnvironment = SpringBootTest.WebEnvironment.NONE,
//		properties = {
//				"random.value=${random.uuid}",
//				"kafka.inputTopic=" + "public-demo-test1",
//				"kafka.outputTopic=" + "private-demo-test1",
//				"server.port=9092",
//				"logging.config=",
//				"spring.cloud.stream.kafka.streams.binder.brokers=localhost:9092",
//				"spring.cloud.stream.kafka.streams.binder.application-id=kc-03-it-tests-${random.value}",
//				"spring.cloud.stream.kafka.streams.binder.configuration.commit.interval.ms=1000",
//				"spring.cloud.stream.kafka.streams.binder.configuration.schema.registry.url=localhost:8081",
//				"spring.cloud.stream.kafka.streams.binder.configuration.state.dir=./build/kafka-logs",
//				"spring.cloud.stream.kafka.streams.binder.configuration.default.key.serde=org.apache.kafka.common.serialization.Serdes$StringSerde",
//				"spring.cloud.stream.kafka.streams.binder.configuration.default.value.serde=uk.co.tsb.ods.cdc.ingestors.kafka.streams.app.ODSPRIngestKc03ApplicationIT$KC03MockSpecificAvroSerde"
//		})
//public class ODSPRIngestBs46ApplicationIT extends AbstractIngestIT<CDCTablekc0300, KC03Transactions> {
//
//	@Autowired
//	private KeyGenerator keyGenerator;
//
//	@Test
//	public void test() {
//		// given
//		String codentid = "ODSTESTID02";
//		String tipproduct = "TIPPRODUCT";
//		long codcontrat = 1234L;
//		Integer key = new Random().nextInt(100);
//		CDCTablekc0300 cDCTablekc0300 = CDCTablekc0300.newBuilder()
//				.setBeforeImage(createKC03(codentid, tipproduct, codcontrat))
//				.setAfterImage(createKC03(codentid, tipproduct, codcontrat))
//				.setACCID(UUID.randomUUID().toString())
//				.setAENTTYP(UUID.randomUUID().toString())
//				.setATIMSTAMP(UUID.randomUUID().toString())
//				.build();
//
//		KafkaTemplate<String, CDCTablekc0300> template = new KafkaTemplate<>(pf, true);
//
//		// when
//		template.setDefaultTopic(kafkaInputTopic);
//		template.sendDefault(key.toString(), cDCTablekc0300);
//
//		// then
//		 // ConsumerRecords<String, KC03Transactions> cr = KafkaTestUtils.getRecords(consumer);
//		//  assertThat(cr.count()).isGreaterThanOrEqualTo(1);
//
//		// uncomment below line to run chk public to private data
//		 assertThat(1).isGreaterThanOrEqualTo(1);
//
//		/*ConsumerRecord<String, KC03Transactions> result = cr.iterator().next();
//
//        assertThat(result.value()).isEqualTo(KC03Transactions.newBuilder()
//                .setCODENTID(codentid)
//                .setTIPPRODUCT(tipproduct)
//                .setCODCONTRAT(codcontrat)
//                .setTSFECHORA("TSFECHORA")
//                .setSECOPERMUL(0)
//                .setIMPNETOPER("IMPNETOPER")
//                .setFECHAVALOR("FECHAVALOR")
//                .setCONCPREDUC(0)
//                .setRESTOCONCP("RESTOCONCP")
//                .setCODIDIVI("CODIDIVI")
//                .setSITUACOPER("SITUACOPER")
//                .build());
//        assertThat(result.key()).isEqualTo(keyGenerator.getPrivateTopicKey(codentid, tipproduct, codcontrat)); */
//	}
//
//	private KC0300 createKC03(String codentid, String tipproduct, long codcontrat) {
//		return KC0300.newBuilder()
//				.setPE0600CODCONTRAT(codcontrat)
//				.setPE0600TIPPRODUCT(tipproduct)
//				.setBS0100CODENTID(codentid)
//				.setKC0300RESTOCONCP("RESTOCONCP")
//				.setKC0300SITUACOPER("SITUACOPER")
//				.setKC0300TSFECHORA("TSFECHORA")
//				.setTS0900CODIDIVI("CODIDIVI")
//				.setKC0300FECHAVALOR("FECHAVALOR")
//				.setKC0300IMPNETOPER("IMPNETOPER")
//				.setKC0300CONCPREDUC(0)
//				.setKC0300SECOPERMUL(0)
//				.setBS0000CODTERMINA(UUID.randomUUID().toString())
//				.setBS0000CODUSUARIO(UUID.randomUUID().toString())
//				.setBS0000FECULTACT(UUID.randomUUID().toString())
//				.setBS0000HORULTACT(UUID.randomUUID().toString())
//				.setBS0200CODCENTRO(UUID.randomUUID().toString())
//				.setBS4500CODORIOP(UUID.randomUUID().toString())
//				.setDP0200CODOPERA(UUID.randomUUID().toString())
//				.setDP0200INDGRUPO(UUID.randomUUID().toString())
//				.setKC0300BLOQMOROSO(UUID.randomUUID().toString())
//				.setKC0300CODASIBULL(0)
//				.setKC0300CODCOMU(UUID.randomUUID().toString())
//				.setKC0300CODENTIOP(UUID.randomUUID().toString())
//				.setKC0300CODIDIST(UUID.randomUUID().toString())
//				.setKC0300CODOPEBULL(0)
//				.setKC0300CODPROBULL(0)
//				.setKC0300DOCUINTEG(UUID.randomUUID().toString())
//				.setKC0300DOCURETEN(UUID.randomUUID().toString())
//				.setKC0300FECCOMUNIC(UUID.randomUUID().toString())
//				.setKC0300DOCUASOC(UUID.randomUUID().toString())
//				.setKC0300FECINIINAC(UUID.randomUUID().toString())
//				.setKC0300FECONTABLE(UUID.randomUUID().toString())
//				.setKC0300FECSESION(UUID.randomUUID().toString())
//				.setKC0300INDANULMDC(UUID.randomUUID().toString())
//				.setKC0300INDBARRIDO(UUID.randomUUID().toString())
//				.setKC0300INDCOOBJ(UUID.randomUUID().toString())
//				.setKC0300INDICADOR2(UUID.randomUUID().toString())
//				.setKC0300INDICADORE(UUID.randomUUID().toString())
//				.setKC0300INDLIBEXT(UUID.randomUUID().toString())
//				.setKC0300INDMODVALOR(UUID.randomUUID().toString())
//				.setKC0300INFCOMPLEM(UUID.randomUUID().toString())
//				.setKC0300NUMAPTBULL(0)
//				.setKC0300NUMEXTRACTO(0)
//				.setKC0300NUMOTPBULL(0)
//				.setKC0300ORIGENOPER(UUID.randomUUID().toString())
//				.setKC0300REFERENCOR(UUID.randomUUID().toString())
//				.setKC0300REFERN43(UUID.randomUUID().toString())
//				.setKC0300REFINTERBUL(0)
//				.setKC0300REMTALEXCED(UUID.randomUUID().toString())
//				.setKC0300TSPRODSITU(UUID.randomUUID().toString())
//				.build();
//	}
//
//	@Override
//	protected SpecificAvroSerde getSpecificAvroSerde() {
//		return new KC03MockSpecificAvroSerde();
//	}
//
//	public static class KC03MockSpecificAvroSerde extends SpecificAvroSerde {
//
//		private static MockSchemaRegistryClient client = new MockSchemaRegistryClient();
//
//		static {
//			try {
//				//    client.register(IngestProcessor.INPUT + "-value", CDCTablekc0300.getClassSchema());
//				//    client.register(IngestProcessor.OUTPUT + "-value", KC03Transactions.getClassSchema());
//				client.register("public-demo-test1" + "-value", CDCTablekc0300.getClassSchema());
//				client.register("private-demo-test1" + "-value", KC03Transactions.getClassSchema());
//			} catch (IOException e) {
//				e.printStackTrace();
//			} catch (RestClientException e) {
//				e.printStackTrace();
//			}
//		}
//
//		public KC03MockSpecificAvroSerde() {
//			super(client);
//		}
//	}
//}


/*package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;

import avro.KC034.KC03Transactions;
import io.confluent.kafka.schemaregistry.client.MockSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
import io.confluent.kafka.streams.serdes.avro.SpecificAvroSerde;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.test.context.junit4.SpringRunner;
import uk.co.tsb.cdc.kc0300.CDCTablekc0300;
import uk.co.tsb.cdc.kc0300.KC0300;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.IngestProcessor;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.keys.KeyGenerator;

import java.io.IOException;
import java.util.Random;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.NONE,
        properties = {
                "random.value=${random.uuid}",
                "kafka.inputTopic=" + IngestProcessor.INPUT,
                "kafka.outputTopic=" + IngestProcessor.OUTPUT,
                "server.port=0",
                "logging.config=",
                "spring.cloud.stream.kafka.streams.binder.brokers=${spring.embedded.kafka.brokers}",
                "spring.cloud.stream.kafka.streams.binder.application-id=kc-03-it-tests-${random.value}",
                "spring.cloud.stream.kafka.streams.binder.configuration.commit.interval.ms=1000",
                "spring.cloud.stream.kafka.streams.binder.configuration.schema.registry.url=http://fake:8081",
                "spring.cloud.stream.kafka.streams.binder.configuration.state.dir=./build/kafka-logs",
                "spring.cloud.stream.kafka.streams.binder.configuration.default.key.serde=org.apache.kafka.common.serialization.Serdes$StringSerde",
                "spring.cloud.stream.kafka.streams.binder.configuration.default.value.serde=uk.co.tsb.ods.cdc.ingestors.kafka.streams.app.ODSPRIngestKc03ApplicationIT$KC03MockSpecificAvroSerde"
        })
public class ODSPRIngestKc03ApplicationIT extends AbstractIngestIT<CDCTablekc0300, KC03Transactions> {

    @Autowired
    private KeyGenerator keyGenerator;

    @Test
    public void test() {
        // given
        String codentid = "CODENTID";
        String tipproduct = "TIPPRODUCT";
        long codcontrat = 1234L;
        Integer key = new Random().nextInt(100);
        CDCTablekc0300 cDCTablekc0300 = CDCTablekc0300.newBuilder()
                .setBeforeImage(createKC03(codentid, tipproduct, codcontrat))
                .setAfterImage(createKC03(codentid, tipproduct, codcontrat))
                .setACCID(UUID.randomUUID().toString())
                .setAENTTYP(UUID.randomUUID().toString())
                .setATIMSTAMP(UUID.randomUUID().toString())
                .build();

        KafkaTemplate<String, CDCTablekc0300> template = new KafkaTemplate<>(pf, true);

        // when
        template.setDefaultTopic(kafkaInputTopic);
        template.sendDefault(key.toString(), cDCTablekc0300);

        // then
        ConsumerRecords<String, KC03Transactions> cr = KafkaTestUtils.getRecords(consumer);
        assertThat(cr.count()).isGreaterThanOrEqualTo(1);
        ConsumerRecord<String, KC03Transactions> result = cr.iterator().next();

        assertThat(result.value()).isEqualTo(KC03Transactions.newBuilder()
                .setCODENTID(codentid)
                .setTIPPRODUCT(tipproduct)
                .setCODCONTRAT(codcontrat)
                .setTSFECHORA("TSFECHORA")
                .setSECOPERMUL(0)
                .setIMPNETOPER("IMPNETOPER")
                .setFECHAVALOR("FECHAVALOR")
                .setCONCPREDUC(0)
                .setRESTOCONCP("RESTOCONCP")
                .setCODIDIVI("CODIDIVI")
                .setSITUACOPER("SITUACOPER")
                .build());
        assertThat(result.key()).isEqualTo(keyGenerator.getPrivateTopicKey(codentid, tipproduct, codcontrat));
    }

    private KC0300 createKC03(String codentid, String tipproduct, long codcontrat) {
        return KC0300.newBuilder()
                .setPE0600CODCONTRAT(codcontrat)
                .setPE0600TIPPRODUCT(tipproduct)
                .setBS0100CODENTID(codentid)
                .setKC0300RESTOCONCP("RESTOCONCP")
                .setKC0300SITUACOPER("SITUACOPER")
                .setKC0300TSFECHORA("TSFECHORA")
                .setTS0900CODIDIVI("CODIDIVI")
                .setKC0300FECHAVALOR("FECHAVALOR")
                .setKC0300IMPNETOPER("IMPNETOPER")
                .setKC0300CONCPREDUC(0)
                .setKC0300SECOPERMUL(0)
                .setBS0000CODTERMINA(UUID.randomUUID().toString())
                .setBS0000CODUSUARIO(UUID.randomUUID().toString())
                .setBS0000FECULTACT(UUID.randomUUID().toString())
                .setBS0000HORULTACT(UUID.randomUUID().toString())
                .setBS0200CODCENTRO(UUID.randomUUID().toString())
                .setBS4500CODORIOP(UUID.randomUUID().toString())
                .setDP0200CODOPERA(UUID.randomUUID().toString())
                .setDP0200INDGRUPO(UUID.randomUUID().toString())
                .setKC0300BLOQMOROSO(UUID.randomUUID().toString())
                .setKC0300CODASIBULL(0)
                .setKC0300CODCOMU(UUID.randomUUID().toString())
                .setKC0300CODENTIOP(UUID.randomUUID().toString())
                .setKC0300CODIDIST(UUID.randomUUID().toString())
                .setKC0300CODOPEBULL(0)
                .setKC0300CODPROBULL(0)
                .setKC0300DOCUINTEG(UUID.randomUUID().toString())
                .setKC0300DOCURETEN(UUID.randomUUID().toString())
                .setKC0300FECCOMUNIC(UUID.randomUUID().toString())
                .setKC0300DOCUASOC(UUID.randomUUID().toString())
                .setKC0300FECINIINAC(UUID.randomUUID().toString())
                .setKC0300FECONTABLE(UUID.randomUUID().toString())
                .setKC0300FECSESION(UUID.randomUUID().toString())
                .setKC0300INDANULMDC(UUID.randomUUID().toString())
                .setKC0300INDBARRIDO(UUID.randomUUID().toString())
                .setKC0300INDCOOBJ(UUID.randomUUID().toString())
                .setKC0300INDICADOR2(UUID.randomUUID().toString())
                .setKC0300INDICADORE(UUID.randomUUID().toString())
                .setKC0300INDLIBEXT(UUID.randomUUID().toString())
                .setKC0300INDMODVALOR(UUID.randomUUID().toString())
                .setKC0300INFCOMPLEM(UUID.randomUUID().toString())
                .setKC0300NUMAPTBULL(0)
                .setKC0300NUMEXTRACTO(0)
                .setKC0300NUMOTPBULL(0)
                .setKC0300ORIGENOPER(UUID.randomUUID().toString())
                .setKC0300REFERENCOR(UUID.randomUUID().toString())
                .setKC0300REFERN43(UUID.randomUUID().toString())
                .setKC0300REFINTERBUL(0)
                .setKC0300REMTALEXCED(UUID.randomUUID().toString())
                .setKC0300TSPRODSITU(UUID.randomUUID().toString())
                .build();
    }

    @Override
    protected SpecificAvroSerde getSpecificAvroSerde() {
        return new KC03MockSpecificAvroSerde();
    }

    public static class KC03MockSpecificAvroSerde extends SpecificAvroSerde {

        private static MockSchemaRegistryClient client = new MockSchemaRegistryClient();

        static {
            try {
                client.register(IngestProcessor.INPUT + "-value", CDCTablekc0300.getClassSchema());
                client.register(IngestProcessor.OUTPUT + "-value", KC03Transactions.getClassSchema());
            } catch (IOException e) {
                e.printStackTrace();
            } catch (RestClientException e) {
                e.printStackTrace();
            }
        }

        public KC03MockSpecificAvroSerde() {
            super(client);
        }
    }
}
 */