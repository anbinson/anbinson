package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;

import com.tsb.ods.stream.schema.avro.KC4301.KC43TransactionsHistory;

import avro.util.ToStringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.handler.annotation.SendTo;
import uk.co.tsb.cdc.kc4301.CDCTablekc4301;
import uk.co.tsb.cdc.utils.CdcToStringUtils;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.EnableKafkaStreamsConfiguration;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.IngestProcessor;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.keys.KeyGenerator;
import uk.co.tsb.ods.cdc.ingestors.micrometer.EnableStreamMetricsConfiguration;
import uk.co.tsb.ods.cdc.ingestors.micrometer.StreamCustomMetrics;

import static uk.co.tsb.ods.cdc.ingestors.kafka.streams.util.CharSequenceUtils.safeToString;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Slf4j
@Configuration
@EnableBinding(IngestProcessor.class)
@EnableKafkaStreamsConfiguration
@EnableStreamMetricsConfiguration
public class ODSPRIngestKc43Configuration {

    @Autowired
    private KeyGenerator keyGenerator;

    @Autowired
    private StreamCustomMetrics metrics;
    
    public static String timestampGenString(LocalDateTime timeStamp) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
        String formatDateTime = timeStamp.format(formatter);
		return formatDateTime;
    }
    public static CharSequence datetime(CharSequence string) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
        LocalDateTime dateTime = LocalDateTime.parse(string, formatter);
        CharSequence dateSequence;
        if(Integer.parseInt(String.valueOf(dateTime.getMonthValue()))<10){
            dateSequence = String.valueOf(dateTime.getYear())+"0"+String.valueOf(dateTime.getMonthValue());
        }
        else {
            dateSequence = String.valueOf(dateTime.getYear())+String.valueOf(dateTime.getMonthValue());
        }
        return dateSequence;
    }
    
    @StreamListener(IngestProcessor.INPUT)
    @SendTo(IngestProcessor.OUTPUT)
    public KStream<String, KC43TransactionsHistory> process(KStream<String, CDCTablekc4301> rawData) {
    	
        return rawData.peek((key, value) -> {
                    metrics.countMsgIn();
                    if (log.isDebugEnabled()) {
                        log.debug("Consuming {}",CdcToStringUtils.toString(value));
                    }
                })
                .map((key, kc43) -> {
                    KC43TransactionsHistory KC43TransactionsHistory= null;
                    String newKey= null;
                    LocalDateTime timeStamp = LocalDateTime.now();
                    if(kc43.getAfterImage()!=null) {
                        KC43TransactionsHistory = KC43TransactionsHistory.newBuilder()
                        		.setCODENTID(safeToString(kc43.getAfterImage().getBS0100CODENTID()))
                        		.setTIPPRODUCT(safeToString(kc43.getAfterImage().getPE0600TIPPRODUCT()))
                        		.setCODCONTRAT((kc43.getAfterImage().getPE0600CODCONTRAT()))
                        		.setTSFECHORA(safeToString(kc43.getAfterImage().getKC4301TSFECHORA()))
                        		.setSECOPERMUL((kc43.getAfterImage().getKC4301SECOPERMUL()))
                        		.setSITUACOPER(safeToString(kc43.getAfterImage().getKC4301SITUACOPER()))
                        		.setTSPRODSITU(safeToString(kc43.getAfterImage().getKC4301TSPRODSITU()))
                        		.setCODORIOP(safeToString(kc43.getAfterImage().getBS4500CODORIOP()))
                        		.setORIGENOPER(safeToString(kc43.getAfterImage().getKC4301ORIGENOPER()))
                        		.setINDCOOBJ(safeToString(kc43.getAfterImage().getKC4301INDCOOBJ()))
                        		.setINDGRUPO(safeToString(kc43.getAfterImage().getDP0200INDGRUPO()))
                        		.setCODOPERA(safeToString(kc43.getAfterImage().getDP0200CODOPERA()))
                        		.setCODIDIST(safeToString(kc43.getAfterImage().getKC4301CODIDIST()))
                        		.setINDICADORE(safeToString(kc43.getAfterImage().getKC4301INDICADORE()))
                        		.setCODIDIVI(safeToString(kc43.getAfterImage().getTS0900CODIDIVI()))
                        		.setIMPNETOPER(safeToString(kc43.getAfterImage().getKC4301IMPNETOPER()))
                        		.setFECHAVALOR(safeToString(kc43.getAfterImage().getKC4301FECHAVALOR()))
                        		.setFECONTABLE(safeToString(kc43.getAfterImage().getKC4301FECONTABLE()))
                        		.setSALDODESP(safeToString(kc43.getAfterImage().getKC4301SALDODESP()))
                        		.setCONCPREDUC((kc43.getAfterImage().getKC4301CONCPREDUC()))
                        		.setCODENTIOP(safeToString(kc43.getAfterImage().getKC4301CODENTIOP()))
                        		.setCODCENTRO(safeToString(kc43.getAfterImage().getBS0200CODCENTRO()))
                        		.setFECULTACT(safeToString(kc43.getAfterImage().getBS0000FECULTACT()))
                        		.setHORULTACT(safeToString(kc43.getAfterImage().getBS0000HORULTACT()))
                        		.setCODTERMINA(safeToString(kc43.getAfterImage().getBS0000CODTERMINA()))
                        		.setCODUSUARIO(safeToString(kc43.getAfterImage().getBS0000CODUSUARIO()))
                        		.setINDICADOR2(safeToString(kc43.getAfterImage().getKC4301INDICADOR2()))
                        		.setFECSESION(safeToString(kc43.getAfterImage().getKC4301FECSESION()))
                        		.setNUMAPTBULL((kc43.getAfterImage().getKC4301NUMAPTBULL()))
                        		.setFECCOMUNIC(safeToString(kc43.getAfterImage().getKC4301FECCOMUNIC()))
                        		.setNUMEXTRACTO((kc43.getAfterImage().getKC4301NUMEXTRACTO()))
                        		.setNUMOTPBULL((kc43.getAfterImage().getKC4301NUMOTPBULL()))
                        		.setINDLIBEXT(safeToString(kc43.getAfterImage().getKC4301INDLIBEXT()))
                        		.setDOCUASOC(safeToString(kc43.getAfterImage().getKC4301DOCUASOC()))
                        		.setDOCUINTEG(safeToString(kc43.getAfterImage().getKC4301DOCUINTEG()))
                        		.setDOCURETEN(safeToString(kc43.getAfterImage().getKC4301DOCURETEN()))
                        		.setREMTALEXCED(safeToString(kc43.getAfterImage().getKC4301REMTALEXCED()))
                        		.setBLOQMOROSO(safeToString(kc43.getAfterImage().getKC4301BLOQMOROSO()))
                        		.setREFERN43(safeToString(kc43.getAfterImage().getKC4301REFERN43()))
                        		.setINFCOMPLEM(safeToString(kc43.getAfterImage().getKC4301INFCOMPLEM()))
                        		.setINDBARRIDO(safeToString(kc43.getAfterImage().getKC4301INDBARRIDO()))
                        		.setINDMODVALOR(safeToString(kc43.getAfterImage().getKC4301INDMODVALOR()))
                        		.setINDANULMDC(safeToString(kc43.getAfterImage().getKC4301INDANULMDC()))
                        		.setCODOPEBULL((kc43.getAfterImage().getKC4301CODOPEBULL()))
                        		.setCODPROBULL((kc43.getAfterImage().getKC4301CODPROBULL()))
                        		.setCODASIBULL((kc43.getAfterImage().getKC4301CODASIBULL()))
                        		.setREFINTERBUL((kc43.getAfterImage().getKC4301REFINTERBUL()))
                        		.setRESTOCONCP(safeToString(kc43.getAfterImage().getKC4301RESTOCONCP()))
                        		.setREFERENCOR(safeToString(kc43.getAfterImage().getKC4301REFERENCOR()))
                        		.setCODCOMU(safeToString(kc43.getAfterImage().getKC4301CODCOMU()))
                        		.setATCREATIONTIME(timestampGenString(timeStamp))
                        		.setATCREATIONUSER(safeToString("ODS_ETL_User"))
                        		.setXXCHECKSUM(safeToString(String.valueOf(kc43.getAfterImage().hashCode())))
                        		.setXXYYYYMM(safeToString(datetime(kc43.getAfterImage().getKC4301TSFECHORA())))
                        		.setEXECTYPE("UPSERT")
                                .build();
              
                        newKey = keyGenerator.getPrivateTopicKey(KC43TransactionsHistory.getCODENTID(), KC43TransactionsHistory.getTIPPRODUCT(), KC43TransactionsHistory.getCODCONTRAT());
                    }
                    if(kc43.getAfterImage()==null) {
                        KC43TransactionsHistory = KC43TransactionsHistory.newBuilder()
                                .setCODENTID(safeToString(kc43.getBeforeImage().getBS0100CODENTID()))
                                .setTIPPRODUCT(safeToString(kc43.getBeforeImage().getPE0600TIPPRODUCT()))
                                .setCODCONTRAT(kc43.getBeforeImage().getPE0600CODCONTRAT())
                        		.setEXECTYPE("DELETE")
                                .build();
                        newKey = keyGenerator.getPrivateTopicKey(KC43TransactionsHistory.getCODENTID(), KC43TransactionsHistory.getTIPPRODUCT(), KC43TransactionsHistory.getCODCONTRAT());
                    }
                    return new KeyValue<>(newKey, KC43TransactionsHistory);
                })
                .peek((key, value) -> {
                    metrics.countMsgOut();
                    if (log.isInfoEnabled()) {
                        log.info("Producing {}", ToStringUtils.toString(value));
                    }
                });
    }

}