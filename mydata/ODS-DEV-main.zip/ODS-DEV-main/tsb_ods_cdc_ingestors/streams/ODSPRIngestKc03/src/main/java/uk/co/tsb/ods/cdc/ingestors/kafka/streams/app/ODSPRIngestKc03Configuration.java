package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;

import com.tsb.ods.stream.schema.avro.KC0300.KC03Transactions;
import avro.util.ToStringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.handler.annotation.SendTo;
import uk.co.tsb.cdc.kc0300.CDCTablekc0300;
import uk.co.tsb.cdc.utils.CdcToStringUtils;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.EnableKafkaStreamsConfiguration;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.IngestProcessor;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.keys.KeyGenerator;
import uk.co.tsb.ods.cdc.ingestors.micrometer.EnableStreamMetricsConfiguration;
import uk.co.tsb.ods.cdc.ingestors.micrometer.StreamCustomMetrics;

import static uk.co.tsb.ods.cdc.ingestors.kafka.streams.util.CharSequenceUtils.safeToString;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Slf4j
@Configuration
@EnableBinding(IngestProcessor.class)
@EnableKafkaStreamsConfiguration
@EnableStreamMetricsConfiguration
public class ODSPRIngestKc03Configuration {

    @Autowired
    private KeyGenerator keyGenerator;

    @Autowired
    private StreamCustomMetrics metrics;
    
    public static String timestampGenString(LocalDateTime timeStamp) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
        String formatDateTime = timeStamp.format(formatter);
		return formatDateTime;
    }
    public static CharSequence datetime(CharSequence string) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
        LocalDateTime dateTime = LocalDateTime.parse(string, formatter);
        CharSequence dateSequence;
        if(Integer.parseInt(String.valueOf(dateTime.getMonthValue()))<10){
            dateSequence = String.valueOf(dateTime.getYear())+"0"+String.valueOf(dateTime.getMonthValue());
        }
        else {
            dateSequence = String.valueOf(dateTime.getYear())+String.valueOf(dateTime.getMonthValue());
        }
        return dateSequence;
    }
    
    @StreamListener(IngestProcessor.INPUT)
    @SendTo(IngestProcessor.OUTPUT)
    public KStream<String, KC03Transactions> process(KStream<String, CDCTablekc0300> rawData) {
        return rawData.peek((key, value) -> {
                    metrics.countMsgIn();
                    if (log.isDebugEnabled()) {
                        log.debug("Consuming {}",CdcToStringUtils.toString(value));
                    }
                })
                .map((key, kc03) -> {
                    KC03Transactions kc03Transactions= null;
                    String newKey= null;
                    LocalDateTime timeStamp = LocalDateTime.now();
                    if(kc03.getAfterImage()!=null) {
                        kc03Transactions = KC03Transactions.newBuilder()
                        		.setCODENTID(safeToString(kc03.getAfterImage().getBS0100CODENTID()))
                        		.setTIPPRODUCT(safeToString(kc03.getAfterImage().getPE0600TIPPRODUCT()))
                        		.setCODCONTRAT((kc03.getAfterImage().getPE0600CODCONTRAT()))
                        		.setTSFECHORA(safeToString(kc03.getAfterImage().getKC0300TSFECHORA()))
                        		.setSECOPERMUL((kc03.getAfterImage().getKC0300SECOPERMUL()))
                        		.setSITUACOPER(safeToString(kc03.getAfterImage().getKC0300SITUACOPER()))
                        		.setTSPRODSITU(safeToString(kc03.getAfterImage().getKC0300TSPRODSITU()))
                        		.setCODORIOP(safeToString(kc03.getAfterImage().getBS4500CODORIOP()))
                        		.setORIGENOPER(safeToString(kc03.getAfterImage().getKC0300ORIGENOPER()))
                        		.setINDCOOBJ(safeToString(kc03.getAfterImage().getKC0300INDCOOBJ()))
                        		.setINDGRUPO(safeToString(kc03.getAfterImage().getDP0200INDGRUPO()))
                        		.setCODOPERA(safeToString(kc03.getAfterImage().getDP0200CODOPERA()))
                        		.setCODIDIST(safeToString(kc03.getAfterImage().getKC0300CODIDIST()))
                        		.setINDICADORE(safeToString(kc03.getAfterImage().getKC0300INDICADORE()))
                        		.setCODIDIVI(safeToString(kc03.getAfterImage().getTS0900CODIDIVI()))
                        		.setIMPNETOPER(safeToString(kc03.getAfterImage().getKC0300IMPNETOPER()))
                        		.setFECHAVALOR(safeToString(kc03.getAfterImage().getKC0300FECHAVALOR()))
                        		.setFECONTABLE(safeToString(kc03.getAfterImage().getKC0300FECONTABLE()))
                        		.setFECINIINAC(safeToString(kc03.getAfterImage().getKC0300FECINIINAC()))
                        		.setCONCPREDUC((kc03.getAfterImage().getKC0300CONCPREDUC()))
                        		.setCODENTIOP(safeToString(kc03.getAfterImage().getKC0300CODENTIOP()))
                        		.setCODCENTRO(safeToString(kc03.getAfterImage().getBS0200CODCENTRO()))
                        		.setFECULTACT(safeToString(kc03.getAfterImage().getBS0000FECULTACT()))
                        		.setHORULTACT(safeToString(kc03.getAfterImage().getBS0000HORULTACT()))
                        		.setCODTERMINA(safeToString(kc03.getAfterImage().getBS0000CODTERMINA()))
                        		.setCODUSUARIO(safeToString(kc03.getAfterImage().getBS0000CODUSUARIO()))
                        		.setINDICADOR2(safeToString(kc03.getAfterImage().getKC0300INDICADOR2()))
                        		.setFECSESION(safeToString(kc03.getAfterImage().getKC0300FECSESION()))
                        		.setNUMAPTBULL((kc03.getAfterImage().getKC0300NUMAPTBULL()))
                        		.setFECCOMUNIC(safeToString(kc03.getAfterImage().getKC0300FECCOMUNIC()))
                        		.setNUMEXTRACTO((kc03.getAfterImage().getKC0300NUMEXTRACTO()))
                        		.setNUMOTPBULL((kc03.getAfterImage().getKC0300NUMOTPBULL()))
                        		.setINDLIBEXT(safeToString(kc03.getAfterImage().getKC0300INDLIBEXT()))
                        		.setDOCUASOC(safeToString(kc03.getAfterImage().getKC0300DOCUASOC()))
                        		.setDOCUINTEG(safeToString(kc03.getAfterImage().getKC0300DOCUINTEG()))
                        		.setDOCURETEN(safeToString(kc03.getAfterImage().getKC0300DOCURETEN()))
                        		.setREMTALEXCED(safeToString(kc03.getAfterImage().getKC0300REMTALEXCED()))
                        		.setBLOQMOROSO(safeToString(kc03.getAfterImage().getKC0300BLOQMOROSO()))
                        		.setREFERN43(safeToString(kc03.getAfterImage().getKC0300REFERN43()))
                        		.setINFCOMPLEM(safeToString(kc03.getAfterImage().getKC0300INFCOMPLEM()))
                        		.setINDBARRIDO(safeToString(kc03.getAfterImage().getKC0300INDBARRIDO()))
                        		.setINDMODVALOR(safeToString(kc03.getAfterImage().getKC0300INDMODVALOR()))
                        		.setINDANULMDC(safeToString(kc03.getAfterImage().getKC0300INDANULMDC()))
                        		.setCODOPEBULL((kc03.getAfterImage().getKC0300CODOPEBULL()))
                        		.setCODPROBULL((kc03.getAfterImage().getKC0300CODPROBULL()))
                        		.setCODASIBULL((kc03.getAfterImage().getKC0300CODASIBULL()))
                        		.setREFINTERBUL((kc03.getAfterImage().getKC0300REFINTERBUL()))
                        		.setRESTOCONCP(safeToString(kc03.getAfterImage().getKC0300RESTOCONCP()))
                        		.setREFERENCOR(safeToString(kc03.getAfterImage().getKC0300REFERENCOR()))
                        		.setCODCOMU(safeToString(kc03.getAfterImage().getKC0300CODCOMU()))
                        		.setATCREATIONTIME(timestampGenString(timeStamp))
                        		.setATCREATIONUSER(safeToString("ODS_ETL_User"))
                        		.setXXCHECKSUM(safeToString(String.valueOf(kc03.getAfterImage().hashCode())))
                        		.setXXYYYYMM(safeToString(datetime(kc03.getAfterImage().getKC0300TSFECHORA())))
                        		.setAENTTYP(safeToString(kc03.getAENTTYP()))
                        		.setACCID(safeToString(kc03.getACCID()))
                        		.setATIMSTAMP(safeToString(kc03.getATIMSTAMP()))
                        		.setEXECTYPE("UPSERT")
                                .build();
              
                        newKey = keyGenerator.getPrivateTopicKey(kc03Transactions.getCODENTID(), kc03Transactions.getTIPPRODUCT(), kc03Transactions.getCODCONTRAT());
                    }
                    if(kc03.getAfterImage()==null) {
                        kc03Transactions = KC03Transactions.newBuilder()
                                .setCODENTID(safeToString(kc03.getBeforeImage().getBS0100CODENTID()))
                                .setTIPPRODUCT(safeToString(kc03.getBeforeImage().getPE0600TIPPRODUCT()))
                                .setCODCONTRAT(kc03.getBeforeImage().getPE0600CODCONTRAT())
                                .setAENTTYP(safeToString(kc03.getAENTTYP()))
                        		.setACCID(safeToString(kc03.getACCID()))
                        		.setATIMSTAMP(safeToString(kc03.getATIMSTAMP()))
                        		.setEXECTYPE("DELETE")
                                .build();
                        newKey = keyGenerator.getPrivateTopicKey(kc03Transactions.getCODENTID(), kc03Transactions.getTIPPRODUCT(), kc03Transactions.getCODCONTRAT());
                    }
                    return new KeyValue<>(newKey, kc03Transactions);
                })
                .peek((key, value) -> {
                    metrics.countMsgOut();
                    if (log.isInfoEnabled()) {
                        log.info("Producing {}", ToStringUtils.toString(value));
                    }
                });
    }

}
