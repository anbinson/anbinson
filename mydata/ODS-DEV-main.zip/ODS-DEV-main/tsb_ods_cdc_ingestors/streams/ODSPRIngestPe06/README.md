### Postman Data query

Link: http://10.81.70.109:8082/topics/int_kafka.pushz.sourcedb.pe0000.db2inte.pe0600

{

"key_schema": "{\"type\": \"string\"}",

"value_schema": "{ \"type\": \"record\", \"name\": \"CDCTablepe0600\", \"namespace\": \"uk.co.tsb.cdc.pe0600\", \"fields\": [ { \"name\": \"beforeImage\", \"type\": [ \"null\", { \"type\": \"record\", \"name\": \"PE0600\", \"fields\": [ { \"name\": \"PE0600_TIPPRODUCT\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE0600_TIPPRODUCT\", \"length\": 3 }, \"default\": \"\" }, { \"name\": \"TP0100_CODPRODUCT\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"TP0100_CODPRODUCT\", \"length\": 7 }, \"default\": \"\" }, { \"name\": \"PE0600_CODCONTRAT\", \"type\": { \"type\": \"long\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"PE0600_CODCONTRAT\", \"precision\": 15, \"scale\": 0 }, \"default\": 0 }, { \"name\": \"PE0600_DIGCONTRAT\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE0600_DIGCONTRAT\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"PE0600_INDSITCONT\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE0600_INDSITCONT\", \"length\": 1 }, \"default\": \"\" }, { \"name\": \"PE0600_INDNIVCONF\", \"type\": { \"type\": \"int\", \"logicalType\": \"INTEGER\", \"dbColumnName\": \"PE0600_INDNIVCONF\" }, \"default\": 0 }, { \"name\": \"PE0600_INDNIVCONB\", \"type\": { \"type\": \"int\", \"logicalType\": \"INTEGER\", \"dbColumnName\": \"PE0600_INDNIVCONB\" }, \"default\": 0 }, { \"name\": \"BS1700_CODSECBESP\", \"type\": { \"type\": \"int\", \"logicalType\": \"SMALLINT\", \"dbColumnName\": \"BS1700_CODSECBESP\" }, \"default\": 0 }, { \"name\": \"PE0600_INDTIPCONT\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE0600_INDTIPCONT\", \"length\": 1 }, \"default\": \"\" }, { \"name\": \"PE0600_FECALTA\", \"type\": [ { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"PE0600_FECALTA\", \"length\": 10 }, \"null\" ], \"default\": \"\" }, { \"name\": \"PE0600_FECBAJA\", \"type\": [ { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"PE0600_FECBAJA\", \"length\": 10 }, \"null\" ], \"default\": \"\" }, { \"name\": \"BS0000_CODTERMINA\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0000_CODTERMINA\", \"length\": 8 }, \"default\": \"\" }, { \"name\": \"BS0000_CODUSUARIO\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0000_CODUSUARIO\", \"length\": 8 }, \"default\": \"\" }, { \"name\": \"BS0000_FECULTACT\", \"type\": [ { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"BS0000_FECULTACT\", \"length\": 10 }, \"null\" ], \"default\": \"\" }, { \"name\": \"BS0000_HORULTACT\", \"type\": { \"type\": \"string\", \"logicalType\": \"TIME\", \"dbColumnName\": \"BS0000_HORULTACT\", \"length\": 8 }, \"default\": \"\" }, { \"name\": \"BS0100_CODENTID\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0100_CODENTID\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"BS0200_CODCENTRO\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0200_CODCENTRO\", \"length\": 6 }, \"default\": \"\" }, { \"name\": \"DP0100_CODPRODO\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"DP0100_CODPRODO\", \"length\": 8 }, \"default\": \"\" }, { \"name\": \"TS0900_CODIDIVI\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"TS0900_CODIDIVI\", \"length\": 3 }, \"default\": \"\" }, { \"name\": \"BS0100_CODENTCOM\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0100_CODENTCOM\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"BS0200_CODCTRCOM\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"BS0200_CODCTRCOM\", \"length\": 6 }, \"default\": \"\" }, { \"name\": \"PE1100_INDIDIOMA\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE1100_INDIDIOMA\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"PE0600_INDINCOR\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE0600_INDINCOR\", \"length\": 1 }, \"default\": \"\" }, { \"name\": \"PE0600_INDRIESG\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE0600_INDRIESG\", \"length\": 1 }, \"default\": \"\" }, { \"name\": \"IA0000_MARCA\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"IA0000_MARCA\", \"length\": 6 }, \"default\": \"\" }, { \"name\": \"PE0600_COLECTIVO\", \"type\": [ { \"type\": \"int\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"PE0600_COLECTIVO\", \"precision\": 8, \"scale\": 0 }, \"null\" ], \"default\": 0 }, { \"name\": \"PE0600_FECSOLIT\", \"type\": { \"type\": \"string\", \"logicalType\": \"DATE\", \"dbColumnName\": \"PE0600_FECSOLIT\", \"length\": 10 }, \"default\": \"\" }, { \"name\": \"PE0600_CODUSUSOLI\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE0600_CODUSUSOLI\", \"length\": 8 }, \"default\": \"\" }, { \"name\": \"PE0600_CANALE\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE0600_CANALE\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"PE0600_PROCEDENE\", \"type\": { \"type\": \"string\", \"logicalType\": \"CHARACTER\", \"dbColumnName\": \"PE0600_PROCEDENE\", \"length\": 2 }, \"default\": \"\" }, { \"name\": \"PE1100_CODSECECO\", \"type\": { \"type\": \"int\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"PE1100_CODSECECO\", \"precision\": 4, \"scale\": 0 }, \"default\": 0 }, { \"name\": \"PE1100_CODEBA\", \"type\": { \"type\": \"int\", \"logicalType\": \"DECIMAL\", \"dbColumnName\": \"PE1100_CODEBA\", \"precision\": 4, \"scale\": 0 }, \"default\": 0 } ] } ] }, { \"name\": \"afterImage\", \"type\": [ \"null\", \"PE0600\" ] }, { \"name\": \"A_ENTTYP\", \"type\": [ \"null\", \"string\" ] }, { \"name\": \"A_CCID\", \"type\": [ \"null\", \"string\" ] }, { \"name\": \"A_TIMSTAMP\", \"type\": [ \"null\", \"string\" ] } ] }",

"records": [

{

"key":"pe0600",

"value": {

    "beforeImage": { "uk.co.tsb.cdc.pe0600.PE0600":  {

        "BS0100_CODENTID": "test1",
        "PE0600_TIPPRODUCT": "test1",
        "TP0100_CODPRODUCT": "pe0601",
        "PE0600_CODCONTRAT": 1234567,
        "PE0600_DIGCONTRAT": "CONTROL DIGIT",
        "PE0600_INDSITCONT": "PE0600_INDSITCONT",
        "PE0600_INDNIVCONF": 1234,
        "PE0600_INDNIVCONB": 1234,
        "BS1700_CODSECBESP": 1234,
        "PE0600_INDTIPCONT": "PE0600_INDTIPCONT",
        "PE0600_FECALTA": {"string": "2020-10-20"},
        "PE0600_FECBAJA": {"string": "2020-10-20"},
        "BS0000_CODTERMINA": "BS0000_CODTERMINA",
        "BS0000_CODUSUARIO": "BS0000_CODUSUARIO",
        "BS0000_FECULTACT": {"string": "2020-10-20"},
        "BS0000_HORULTACT": "13:10:20",
        "BS0200_CODCENTRO": "BS0200_CODCENTRO",
        "DP0100_CODPRODO": "DP0100_CODPRODO",
        "TS0900_CODIDIVI": "TS0900_CODIDIVI",
        "BS0100_CODENTCOM": "BS0100_CODENTCOM",
        "BS0200_CODCTRCOM": "BS0200_CODCTRCOM",
        "PE1100_INDIDIOMA": "PE1100_INDIDIOMA",
        "PE0600_INDINCOR": "PE0600_INDINCOR",
        "PE0600_INDRIESG": "chking test",
        "IA0000_MARCA": "IA0000_MARCA",
        "PE0600_COLECTIVO": {"int": 4589},
        "PE0600_FECSOLIT": "2020-10-20",
        "PE0600_CODUSUSOLI": "PE0600_CODUSUSOLI", 
        "PE0600_CANALE": "PE0600_CANALE",
        "PE0600_PROCEDENE": "PE0600_PROCEDENE",
        "PE1100_CODSECECO": 3456,
        "PE1100_CODEBA": 3456
        
        } },

    "afterImage": { "uk.co.tsb.cdc.pe0600.PE0600":  {

        "BS0100_CODENTID": "test1",
        "PE0600_TIPPRODUCT": "test1",
        "TP0100_CODPRODUCT": "pe0601",
        "PE0600_CODCONTRAT": 1234567,
        "PE0600_DIGCONTRAT": "CONTROL DIGIT",
        "PE0600_INDSITCONT": "PE0600_INDSITCONT",
        "PE0600_INDNIVCONF": 1234,
        "PE0600_INDNIVCONB": 1234,
        "BS1700_CODSECBESP": 1234,
        "PE0600_INDTIPCONT": "PE0600_INDTIPCONT",
        "PE0600_FECALTA": {"string": "2020-10-20"},
        "PE0600_FECBAJA": {"string": "2020-10-20"},
        "BS0000_CODTERMINA": "BS0000_CODTERMINA",
        "BS0000_CODUSUARIO": "BS0000_CODUSUARIO",
        "BS0000_FECULTACT": {"string": "2020-10-20"},
        "BS0000_HORULTACT": "13:10:20",
        "BS0200_CODCENTRO": "BS0200_CODCENTRO",
        "DP0100_CODPRODO": "DP0100_CODPRODO",
        "TS0900_CODIDIVI": "TS0900_CODIDIVI",
        "BS0100_CODENTCOM": "BS0100_CODENTCOM",
        "BS0200_CODCTRCOM": "BS0200_CODCTRCOM",
        "PE1100_INDIDIOMA": "PE1100_INDIDIOMA",
        "PE0600_INDINCOR": "PE0600_INDINCOR",
        "PE0600_INDRIESG": "chking test",
        "IA0000_MARCA": "IA0000_MARCA",
        "PE0600_COLECTIVO": {"int": 4589},
        "PE0600_FECSOLIT": "2020-10-20",
        "PE0600_CODUSUSOLI": "PE0600_CODUSUSOLI", 
        "PE0600_CANALE": "PE0600_CANALE",
        "PE0600_PROCEDENE": "PE0600_PROCEDENE",
        "PE1100_CODSECECO": 3456,
        "PE1100_CODEBA": 3456
        } },

    "A_ENTTYP": {"string": "A_ENTTYP"},

    "A_CCID": {"string": "A_CCID" },

    "A_TIMSTAMP": {"string": "A_TIMSTAMP" }

}   

}

]

}
