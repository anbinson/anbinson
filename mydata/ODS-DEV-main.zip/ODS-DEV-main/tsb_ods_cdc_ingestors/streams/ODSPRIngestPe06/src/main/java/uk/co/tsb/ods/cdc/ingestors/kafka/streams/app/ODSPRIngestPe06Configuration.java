package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;


import avro.util.ToStringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.messaging.handler.annotation.SendTo;

import com.tsb.ods.stream.schema.avro.PE06.PE06Contracts;

import uk.co.tsb.cdc.pe0600.CDCTablepe0600;
import uk.co.tsb.cdc.utils.CdcToStringUtils;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.EnableKafkaStreamsConfiguration;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.IngestProcessor;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.keys.KeyGenerator;
import uk.co.tsb.ods.cdc.ingestors.micrometer.EnableStreamMetricsConfiguration;
import uk.co.tsb.ods.cdc.ingestors.micrometer.StreamCustomMetrics;

import static uk.co.tsb.ods.cdc.ingestors.kafka.streams.util.CharSequenceUtils.safeToString;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;


@Slf4j
@Configuration
@EnableBinding(IngestProcessor.class)
@EnableKafkaStreamsConfiguration
@EnableStreamMetricsConfiguration
@PropertySource(value = {"classpath:application.yml"})
public class ODSPRIngestPe06Configuration {

	@Autowired
	private KeyGenerator keyGenerator;

	@Autowired
	private StreamCustomMetrics metrics;

	@Autowired
	private Environment environment;

	public static String timestampGenString(LocalDateTime timeStamp) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
		String formatDateTime = timeStamp.format(formatter);
		return formatDateTime;
	}
	public static CharSequence datetime(CharSequence string) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
		LocalDateTime dateTime = LocalDateTime.parse(string, formatter);
		CharSequence dateSequence;
		if(Integer.parseInt(String.valueOf(dateTime.getMonthValue()))<10){
			dateSequence = String.valueOf(dateTime.getYear())+"0"+String.valueOf(dateTime.getMonthValue());
		}
		else {
			dateSequence = String.valueOf(dateTime.getYear())+String.valueOf(dateTime.getMonthValue());
		}
		return dateSequence;
	}

	@StreamListener(IngestProcessor.INPUT)
	@SendTo(IngestProcessor.OUTPUT)
	public KStream<String, PE06Contracts> process(KStream<String, CDCTablepe0600> rawData) {

		return rawData
				.peek((key, value) -> {
					metrics.countMsgIn();
					if (log.isDebugEnabled()) {
						log.debug("Consuming {}", CdcToStringUtils.toString(value));
					}
				})
				.map((key, pe06) -> {
					PE06Contracts pe06Contracts= null;
					String newKey= null;
					LocalDateTime timeStamp = LocalDateTime.now();
					if(pe06.getAfterImage()!=null) {
						pe06Contracts = PE06Contracts.newBuilder()
								.setCODENTID(safeToString(pe06.getAfterImage().getBS0100CODENTID()))
								.setTIPPRODUCT(safeToString(pe06.getAfterImage().getPE0600TIPPRODUCT()))
								.setCODPRODUCT(safeToString(pe06.getAfterImage().getTP0100CODPRODUCT()))
								.setCODCONTRAT(pe06.getAfterImage().getPE0600CODCONTRAT())
								.setDIGCONTRAT(safeToString(pe06.getAfterImage().getPE0600DIGCONTRAT()))
								.setINDSITCONT(safeToString(pe06.getAfterImage().getPE0600INDSITCONT()))
								.setINDNIVCONF(pe06.getAfterImage().getPE0600INDNIVCONF())
								.setINDNIVCONB(pe06.getAfterImage().getPE0600INDNIVCONB())
								.setCODSECBESP(pe06.getAfterImage().getBS1700CODSECBESP())
								.setINDTIPCONT(safeToString(pe06.getAfterImage().getPE0600INDTIPCONT()))
								.setFECALTA(safeToString(pe06.getAfterImage().getPE0600FECALTA()))
								.setFECBAJA(safeToString(pe06.getAfterImage().getPE0600FECBAJA()))
								.setCODTERMINA(safeToString(pe06.getAfterImage().getBS0000CODTERMINA()))
								.setCODUSUARIO(safeToString(pe06.getAfterImage().getBS0000CODUSUARIO()))
								.setFECULTACT(safeToString(pe06.getAfterImage().getBS0000FECULTACT()))
								.setHORULTACT(safeToString(pe06.getAfterImage().getBS0000HORULTACT()))
								.setCODCENTRO(safeToString(pe06.getAfterImage().getBS0200CODCENTRO()))
								.setCODPRODO(safeToString(pe06.getAfterImage().getDP0100CODPRODO()))								
								.setCODIDIVI(safeToString(pe06.getAfterImage().getTS0900CODIDIVI()))
								.setCODENTCOM(safeToString(pe06.getAfterImage().getBS0100CODENTCOM()))
								.setCODCTRCOM(safeToString(pe06.getAfterImage().getBS0200CODCTRCOM()))
								.setINDIDIOMA(safeToString(pe06.getAfterImage().getPE1100INDIDIOMA()))
								.setINDINCOR(safeToString(pe06.getAfterImage().getPE0600INDINCOR()))
								.setINDRIESG(safeToString(pe06.getAfterImage().getPE0600INDRIESG()))
								.setMARCA(safeToString(pe06.getAfterImage().getIA0000MARCA()))								
								.setCOLECTIVO(pe06.getAfterImage().getPE0600COLECTIVO())
								.setFECSOLIT(safeToString(pe06.getAfterImage().getPE0600FECSOLIT()))
								.setCODUSUSOLI(safeToString(pe06.getAfterImage().getPE0600CODUSUSOLI()))
								.setCANALE(safeToString(pe06.getAfterImage().getPE0600CANALE()))
								.setPROCEDENE(safeToString(pe06.getAfterImage().getPE0600PROCEDENE()))
								.setCODSECECO(pe06.getAfterImage().getPE1100CODSECECO())
								.setCODEBA(pe06.getAfterImage().getPE1100CODEBA())
								.setATCREATIONTIME(timestampGenString(timeStamp))
								.setATCREATIONUSER(safeToString(environment.getProperty("ATCREATIONUSER")))	
								.setATLASTMODIFIEDUSER(safeToString(environment.getProperty("ATCREATIONUSER")))
								.setATLASTMODIFIEDTIME(timestampGenString(timeStamp))
								.setXXCHECKSUM(safeToString(String.valueOf(pe06.getAfterImage().hashCode())))
								.setEXECTYPE("UPSERT")
								.build();
						newKey = keyGenerator.getPrivateTopicKey(pe06Contracts.getCODENTID(), pe06Contracts.getTIPPRODUCT(), pe06Contracts.getCODCONTRAT());
					}
					if(pe06.getAfterImage()==null) {
						pe06Contracts = PE06Contracts.newBuilder()
								.setCODENTID(safeToString(pe06.getAfterImage().getBS0100CODENTID()))
								.setTIPPRODUCT(safeToString(pe06.getAfterImage().getPE0600TIPPRODUCT()))
								.setCODCONTRAT(pe06.getAfterImage().getPE0600CODCONTRAT())                                
								.setEXECTYPE("DELETE")
								.build();
						newKey = keyGenerator.getPrivateTopicKey(pe06Contracts.getCODENTID(), pe06Contracts.getTIPPRODUCT(), pe06Contracts.getCODCONTRAT());
					}
					return new KeyValue<>(newKey, pe06Contracts);
				})
				.peek((key, value) -> {
					metrics.countMsgOut();
					if (log.isInfoEnabled()) {
						log.info("Producing {}", ToStringUtils.toString(value));
					}
				});
	}


}
