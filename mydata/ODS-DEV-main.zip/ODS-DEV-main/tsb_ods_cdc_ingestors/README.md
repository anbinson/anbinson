This is place where ods cdc ingestors should be placed:
tsb-ods-cdc-ods-pr-ingest-kc-03
tsb-ods-cdc-ods-pr-ingest-bs-46
tsb-ods-cdc-ods-pr-ingest-kc-43


Appilcation status-
tsb-ods-cdc-ods-pr-ingest-kc-03 is the latest code created up untill 25th Nov 2020
tsb-ods-cdc-ods-pr-ingest-bs-46 is yet to be created
tsb-ods-cdc-ods-pr-ingest-kc-43 is yet to be created


Running Instructions-
1. Download Consul from "https://www.consul.io/downloads" and paste it anywhere in your system, extract the contents
and go inside the extracted folder of consul, start cmd there and run command "consul agent -dev -data-dir=/tmp/consul".
This will start Consul in default configuration, let it run, to verify if consul is up and running, open 
"http://localhost:8500/".

2. Launch Confluent Kafka setup from Docker.

3. Browse to ODSPRIngestKc03 main application class inside "tsb_ods_cdc_ingestors\streams\ODSPRIngestKc03\src\main\java\uk\co\tsb\ods\cdc\ingestors\kafka\streams\app\ODSPRIngestKc03Application.java",
right click on the file, go to run as -> run configurations -> double click on Spring Boot App -> Uncheck Enable JMX and run the application.

4. Application will be now running and will create public and private topics in control center of confluent Kafka.

5. Use Postman collection to send data to the public topic.

Postman collection import url: https://www.getpostman.com/collections/1d45c9c7c17244d1af12