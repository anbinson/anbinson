# Conversational Banking - CDC Customer Data Write Topology
## Description
CDC Customer Data Topology reads CDC public / private topics and creates a custom Customer table (numpersona, userid, deviceid, etc.) in ScyllaDB as well as a kstream containing the customer data.

## Technology
* Java 11
* Spring Boot
* ScyllaDB
* Kafka

## Build
`mvn clean install`

## Monitoring
Ensure Prometheus has access to /actuator/prometheus.

## Database
Run the CQL queries for each environment (under /resources/cql).
### DEV
```
CREATE KEYSPACE IF NOT EXISTS tsbcb WITH replication = {'class':'SimpleStrategy', 'replication_factor' : 3};
CREATE TABLE IF NOT EXISTS tsbcb.user(user_id text, das_user text, numpersona text, hmac text, hmac_created_at text, hmac_device_id text, PRIMARY KEY (user_id));
CREATE TABLE IF NOT EXISTS tsbcb.device(das_user text, device_id text, PRIMARY KEY (das_user));
CREATE TABLE IF NOT EXISTS tsbcb.profile(numpersona text, first_name text, last_name text,  PRIMARY KEY (numpersona));
CREATE TABLE IF NOT EXISTS tsbcb.hmac(hmac text, user_id text, device_id text, hmac_created_at text, PRIMARY KEY (hmac));
```
### SIT
```
CREATE KEYSPACE IF NOT EXISTS tsbcb WITH replication = {'class':'SimpleStrategy', 'replication_factor' : 3};
CREATE TABLE IF NOT EXISTS tsbcb.user(user_id text, das_user text, numpersona text, hmac text, hmac_created_at text, hmac_device_id text, PRIMARY KEY (user_id));
CREATE TABLE IF NOT EXISTS tsbcb.device(das_user text, device_id text, PRIMARY KEY (das_user));
CREATE TABLE IF NOT EXISTS tsbcb.profile(numpersona text, first_name text, last_name text,  PRIMARY KEY (numpersona));
CREATE TABLE IF NOT EXISTS tsbcb.hmac(hmac text, user_id text, device_id text, hmac_created_at text, PRIMARY KEY (hmac));
```
## Topics
### DEV
* com.tsb.private.ems.users_by_user_id
* com.tsb.private.cdc.tbbv_bs_enrollments
* com.tsb.cb.customer.write.hmac.public.request
* com.tsb.private.cdc.pe11.customers

### SIT
* com.tsb.private.cb.users_by_user_id.0
* com.tsb.private.cb.tbbv_bs_enrollments.0
* com.tsb.cb.customer.write.hmac.public.request.0
* com.tsb.private.cb.pe11.customers.0


### DDL

drop table tsbods.MNF_PRT_DV01_ACCOUNT;
Create table tsbods.MNF_PRT_DV01_ACCOUNT
(CODENTID	TEXT,                      --	Bank Code
TIPPRODUCT	TEXT,                      --	Basic Product Code
CODCONTRAT	DECIMAL,                   --	Contract Number 
CODPRODO	TEXT,                      --	Product Code 
COLECTIVO	DECIMAL,                   --	Collective/Guild /Tecnocredit/Franchise
CODCANAL	TEXT,                      --	Contracting channel 
CODCNAE	        INT,                       --	CNAE
NUMPERSONA	INT,                       --	Number of people
CODPERSOLI	SMALLINT,                  --	Personality 
INDMARCA	TEXT,                      --	Brand
FECHAAPERT	DATE,                      --	Opening Date 
FECCONTRAT	DATE,                      --	Hiring date. In the case of product change is the date of the change to the new product.
FECHAVENCI	DATE,                      --	Experiration date/ cancellation or transfer of last credit policy (KT)
FEULRENOVA	DATE,                      --	Last renewal date
CODPERIODO	TEXT,                      --	Type of period (A: years, M: :month, D: days)
NUMPERIODO	SMALLINT,                  --	Number of contract periods 
CODVALSEGM	SMALLINT,                  --	Segment
CODVALSGMN	SMALLINT,                  --	Subsegment
ACCIVENCIM	TEXT,                      --	Expiration action
RENONLINE	TEXT,                      --	Hiring channel ‘3’ bsonline
CODCENTRO	TEXT,                      --	Branch code
CODSECBESP	SMALLINT,                  --	Bank of Spain sector code
CODIDIVI	TEXT,                      --	Currency Code
FEALTATARI	DATE,                      --	Rate register date   
FEULTLIQUI	DATE,                      --	Last settlement date
FEPROLIQUI	DATE,                      --	Next settlement date
DIALIQUIDA	SMALLINT,                  --	Settlement day
TMSULTMVTO	TIMESTAMP,                 --	Last movement time settled
SALDOULLIQ	DECIMAL,                   --	Balance last settlement
SALDMEDIO1	DECIMAL,                   --	Average balance 1
SALDMEDIO2	DECIMAL,                   --	Average balance 2
SALDMEDIO3	DECIMAL,                   --	Average balance 3
SALDMEDIO4	DECIMAL,                   --	Average balance 4
FECULTSALM	DATE,                      --	Last average balance date
SDOANPRMOV	DECIMAL,                   --	Balance before first transaction
TSPRIMMVTO	TIMESTAMP,                 --	First Transaction Date
SITUACION	TEXT,                      --	Account status
TSITUACION	TIMESTAMP,                 --	Account Status Date
FEINACTIV	DATE,                      --	Inactivity Start Date
SALDO	        DECIMAL,                   --	Balance
DISPONIBLE	DECIMAL,                   --	Available
LIMITDISPO	DECIMAL,                   --	Available limit (KT)
LIMITEREM	DECIMAL,                   --	Authorized limit for payment of remittances
NOVENCIDO	DECIMAL,                   --	Total balance not due
DEVOLCCO	DECIMAL,                   --	Total possible returns charges compensation
DEVOLCDI	DECIMAL,                   --	Total possible returns various charges
FECRETMOV	DATE,                      --	Start date retention movements
IMPRETENIDO	DECIMAL,                   --	Retained amount
INDICATORS	TEXT,                      --	Indicators 
INDICATOR2	TEXT,                      --	Indicators 
INDICATOR3	TEXT,                      --	Indicators 
TIPPRODREL	TEXT,                      --	Product code of the related account (KT)
CODCONTREL	DECIMAL,                   --	Related contract (KT)
CODENTREL	TEXT,                      --	Entity that owns the related contract (KT)
FECULTACT	DATE,                      --	Last update date
HORULTACT	TIME,                      --	Last update time
CODTERMINA	TEXT,                      --	Terminal code
CODUSUARIO	TEXT,                      --	User code
CODENTCOM	TEXT,                      --	Marketing entity code
CODCTRCOM	TEXT,                      --	Marketing Center Code
INDIDIOMA	TEXT,                      --	Communication language
CLAVEBAR	TEXT,                      --	Key group sweeps
NUMEXTRAC	INT,                       --	Statement number 
SDOEXTRAC	DECIMAL,                   --	Previous balance statement
MARCAINFCO	TEXT,                      --	Supplementary Information Indicator
CONPEL	DECIMAL,                           --	Danger conditions
AT_CREATION_TIME	TIMESTAMP,         --	ETL/BI Audit column
AT_CREATION_USER	TEXT,             --	ETL/BI Audit column
AT_LAST_MODIFIED_TIME	TIMESTAMP,        --	ETL/BI Audit column
AT_LAST_MODIFIED_USER	TEXT,             --	ETL/BI Audit column
XX_CHECKSUM	TEXT,                     --	ETL/BI Audit column
PRIMARY KEY (CODENTID,TIPPRODUCT,CODCONTRAT)
);

select * from tsbods.MNF_PRT_DV01_ACCOUNT;