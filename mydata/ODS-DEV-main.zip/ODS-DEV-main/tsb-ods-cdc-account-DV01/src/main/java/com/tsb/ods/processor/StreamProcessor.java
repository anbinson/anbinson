package com.tsb.ods.processor;
import java.util.function.Consumer;

import javax.annotation.PostConstruct;

import org.apache.kafka.streams.kstream.KTable;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tsb.ods.converter.Converter;
import com.tsb.ods.model.DV01Entity;
import com.tsb.ods.repository.AccountsRepository;
import com.tsb.ods.stream.schema.avro.DV01.DV01Accounts;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class StreamProcessor {

    private final AccountsRepository accountsRepository;
    private final MeterRegistry meterRegistry;
    
    private Counter accountTypeInCounter; 
    private Counter accountTypeOutCounter;
    
    @PostConstruct
    public void init() {
    	log.info("Create and register metric counters with Meter registry");
    	accountTypeInCounter = Counter.builder("tsb_ods_in_accounts_in_total")
    								.description("Total number of accounts since process start")
    								.register(meterRegistry);
    	accountTypeOutCounter = Counter.builder("tsb_ods_out_accounts_in_total")
									.description("Total number of accounts processed")
									.register(meterRegistry);
    	
    }
    

    /**
     * Consume transactonTypes stream (from ods) and store it in scylladb
     * 
     */
    @Bean
    public Consumer<KTable<String, DV01Accounts>> processAccountsStream() {
    	
        return input -> input
                .toStream()
                .foreach((k, account) -> {
                	accountTypeInCounter.increment();                	
                	DV01Entity dv01 = DV01Entity.builder()
                			.codentid(account.getCODENTID())
                			.tipproduct(account.getTIPPRODUCT())
                			.codcontrat(Converter.decimalConverter(account.getCODCONTRAT()))
                			.codprodo(account.getCODPRODO())
                			.colectivo(Converter.decimalConverter(String.valueOf(account.getCOLECTIVO())))
                			.codcanal(account.getCODCANAL())
                			.codcnae(account.getCODCNAE())
                			.numpersona(account.getNUMPERSONA())
                			.codpersoli(account.getCODPERSOLI())
                			.indmarca(account.getINDMARCA())
                			.fechaapert(Converter.dateConverter(account.getFECHAAPERT()))
                			.feccontrat(Converter.dateConverter(account.getFECCONTRAT()))
                			.fechavenci(Converter.dateConverter(account.getFECHAVENCI()))
                			.feulrenova(Converter.dateConverter(account.getFEULRENOVA()))
                			.codperiodo(account.getCODPERIODO())
                			.numperiodo(account.getNUMPERIODO())
                			.codvalsegm(account.getCODVALSEGM())
                			.codvalsgmn(account.getCODVALSGMN())
                			.accivencim(account.getACCIVENCIM())
                			.renonline(account.getRENONLINE())
                			.codcentro(account.getCODCENTRO())
                			.codsecbesp(account.getCODSECBESP())
                			.codidivi(account.getCODIDIVI())
                			.fealtatari(Converter.dateConverter(account.getFEALTATARI()))
                			.feultliqui(Converter.dateConverter(account.getFEULTLIQUI()))
                			.feproliqui(Converter.dateConverter(account.getFEPROLIQUI()))
                			.dialiquida(account.getDIALIQUIDA())
                			.tmsultmvto(Converter.timestampConverter(account.getTMSULTMVTO()))
                			.saldoulliq(Converter.decimalConverter(account.getSALDOULLIQ()))
                			.saldmedio1(Converter.decimalConverter(account.getSALDMEDIO1()))
                			.saldmedio2(Converter.decimalConverter(account.getSALDMEDIO2()))
                			.saldmedio3(Converter.decimalConverter(account.getSALDMEDIO3()))
                			.saldmedio4(Converter.decimalConverter(account.getSALDMEDIO4()))
                			.fecultsalm(Converter.dateConverter(account.getFECULTSALM()))
                			.sdoanprmov(Converter.decimalConverter(account.getSDOANPRMOV()))
                			.tsprimmvto(Converter.timestampConverter(account.getTSPRIMMVTO()))
                			.situacion(account.getSITUACION())
                			.tsituacion(Converter.timestampConverter(account.getTSITUACION()))
                			.feinactiv(Converter.dateConverter(account.getFEINACTIV()))
                			.saldo(Converter.decimalConverter(account.getSALDO()))
                			.disponible(Converter.decimalConverter(account.getDISPONIBLE()))
                			.limitdispo(Converter.decimalConverter(account.getLIMITDISPO()))
                			.limiterem(Converter.decimalConverter(account.getLIMITEREM()))
                			.novencido(Converter.decimalConverter(account.getNOVENCIDO()))
                			.devolcco(Converter.decimalConverter(account.getDEVOLCCO()))
                			.devolcdi(Converter.decimalConverter(account.getDEVOLCDI()))
                			.fecretmov(Converter.dateConverter(account.getFECRETMOV()))
                			.impretenido(Converter.decimalConverter(account.getIMPRETENIDO()))
                			.indicators(account.getINDICATORS())
                			.indicator2(account.getINDICATOR2())
                			.indicator3(account.getINDICATOR3())
                			.tipprodrel(account.getTIPPRODREL())
                			.codcontrel(Converter.decimalConverter(account.getCODCONTREL()))
                			.codentrel(account.getCODENTREL())
                			.fecultact(Converter.dateConverter(account.getFECULTACT()))
                			.horultact(Converter.timeConverter(account.getHORULTACT()))
                			.codtermina(account.getCODTERMINA())
                			.codusuario(account.getCODUSUARIO())
                			.codentcom(account.getCODENTCOM())
                			.codctrcom(account.getCODCTRCOM())
                			.indidioma(account.getINDIDIOMA())
                			.clavebar(account.getCLAVEBAR())
                			.numextrac(account.getNUMEXTRAC())
                			.sdoextrac(Converter.decimalConverter(account.getSDOEXTRAC()))
                			.marcainfco(account.getMARCAINFCO())
                			.conpel(Converter.decimalConverter(account.getCONPEL()))
                			.at_creation_time(Converter.timestampConverter(account.getATCREATIONTIME()))
                			.at_creation_user(account.getATCREATIONUSER())
                			.at_last_modified_time(Converter.timestampConverter(account.getATLASTMODIFIEDTIME()))
                			.at_last_modified_user(account.getATLASTMODIFIEDUSER())
                			.xx_checksum(account.getXXCHECKSUM())
							.build();				
	                	
                	try {
						ObjectMapper objecmapper =new ObjectMapper();
						String str = objecmapper.writeValueAsString(dv01);
						log.info("Account: "+ str);
						if ("DELETE".equals(account.getEXECTYPE())) {
							accountsRepository.deleteById(dv01.getCodentid());
							log.info("Account deleted in Scylladb:"+ dv01.getCodentid());
						}
						else {                
							accountsRepository.save(dv01);

							log.info("Account stored in Scylladb:"+ dv01.getCodentid());
						}
					} catch (Exception e) { 
						e.printStackTrace();
					}
//	                	if ("DELETE".equals(account.getEXECTYPE())) {
//	                		accountsRepository.deleteById(dv01.getCodentid());
//	                		log.info("Account deleted in Scylladb"+ dv01.getCodentid());
//	                	}
//	                	else {				
//	                		accountsRepository.save(dv01);
//		                	log.info("Account stored in Scylladb"+ dv01.getCodentid());
//	                	}
                	
					accountTypeOutCounter.increment();
					
                });
    }
}