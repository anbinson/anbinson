package com.tsb.ods.model;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.Builder;
import lombok.Data;

@Table(value = "MNF_PRT_DV01_ACCOUNT")
@Data
@Builder
public class DV01Entity {

	@PrimaryKey("codentid")
	private String codentid;
	
	@Column("tipproduct")            
	private String tipproduct;
	
	@Column("codcontrat")            
	private Double codcontrat;
	
	@Column("codprodo")             
	private String codprodo;
	
	@Column("colectivo")            
	private Double colectivo;
	
	@Column("codcanal")            
	private String codcanal;
	
	@Column("codcnae")            
	private int codcnae;
	
	@Column("numpersona")              
	private int numpersona;
	
	@Column("codpersoli")            
	private int codpersoli;
	
	@Column("indmarca")              
	private String indmarca;
	
	@Column("fechaapert")              
	private LocalDate fechaapert;
	
	@Column("feccontrat")              
	private LocalDate feccontrat;
	
	@Column("fechavenci")              
	private LocalDate fechavenci;
	
	@Column("feulrenova")            
	private LocalDate feulrenova;
	
	@Column("codperiodo")              
	private String codperiodo;
	
	@Column("numperiodo")            
	private int numperiodo;
	
	@Column("codvalsegm")            
	private int codvalsegm;
	
	@Column("codvalsgmn")            
	private int codvalsgmn;
	
	@Column("accivencim")            
	private String accivencim;	
	
	@Column("renonline")            
	private String renonline;
	
	@Column("codcentro")             
	private String codcentro;
	
	@Column("codsecbesp")             
	private int codsecbesp;
	
	@Column("codidivi")             
	private String codidivi;
	
	@Column("fealtatari")             
	private LocalDate fealtatari;
	
	@Column("feultliqui")            
	private LocalDate feultliqui;
	
	@Column("feproliqui")            
	private LocalDate feproliqui;
	
	@Column("dialiquida")            
	private int dialiquida;
	
	@Column("tmsultmvto")             
	private Timestamp tmsultmvto;
	
	@Column("saldoulliq")            
	private Double saldoulliq;
	
	@Column("saldmedio1")            
	private Double saldmedio1;
	
	@Column("saldmedio2")           
	private Double saldmedio2;
	
	@Column("saldmedio3")            
	private Double saldmedio3;
	
	@Column("saldmedio4")             
	private Double saldmedio4;
	
	@Column("fecultsalm")              
	private LocalDate fecultsalm;
	
	@Column("sdoanprmov")             
	private Double sdoanprmov;
	
	@Column("tsprimmvto")             
	private Timestamp tsprimmvto;
	
	@Column("situacion")           
	private String situacion;
	
	@Column("tsituacion")            
	private Timestamp tsituacion;
	
	@Column("feinactiv")              
	private LocalDate feinactiv;
	
	@Column("saldo")            
	private Double saldo;
	
	@Column("disponible")            
	private Double disponible;
	
	@Column("limitdispo")           
	private Double limitdispo;
	
	@Column("limiterem")            
	private Double limiterem;
	
	@Column("novencido")            
	private Double novencido;
	
	@Column("devolcco")            
	private Double devolcco;
	
	@Column("devolcdi")            
	private Double devolcdi;
	
	@Column("fecretmov")           
	private LocalDate fecretmov;
	
	@Column("impretenido")            
	private Double impretenido;
	
	@Column("indicators")            
	private String indicators;
	
	@Column("indicator2")               
	private String indicator2;
	
	@Column("indicator3")               
	private String indicator3;                       
	
	@Column("tipprodrel")               
	private String tipprodrel;                      
	
	@Column("codcontrel")               
	private Double codcontrel;                   

	@Column("codentrel")               
	private String codentrel;                      

	@Column("fecultact")               
	private LocalDate fecultact;                      

	@Column("horultact")               
	private LocalTime horultact;                      

	@Column("codtermina")               
	private String codtermina;                      

	@Column("codusuario")               
	private String codusuario;                      

	@Column("codentcom")               
	private String codentcom;                      

	@Column("codctrcom")               
	private String codctrcom;                      

	@Column("indidioma")               
	private String indidioma;                      

	@Column("clavebar")               
	private String clavebar;                      

	@Column("numextrac")               
	private int numextrac;                        

	@Column("sdoextrac")               
	private Double sdoextrac;                   

	@Column("marcainfco")               
	private String marcainfco;                      

	@Column("conpel")               
	private Double conpel;
	
	@Column("at_creation_time")              
	private Timestamp at_creation_time;
	
	@Column("at_creation_user")                
	private String at_creation_user;
	
	@Column("at_last_modified_time")              
	private Timestamp at_last_modified_time;
	
	@Column("at_last_modified_user")                
	private String at_last_modified_user;
	
	@Column("xx_checksum")            
	private String xx_checksum;

}