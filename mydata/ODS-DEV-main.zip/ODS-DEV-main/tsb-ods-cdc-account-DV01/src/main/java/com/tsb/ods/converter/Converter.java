package com.tsb.ods.converter;


import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Converter {
	
	public static Timestamp timestampConverter(String input) {
		if(input.isEmpty()) {
			return null;
		}
		else {
			String subInput = input.substring(0, input.length()-3);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSS");
	        LocalDateTime dateTime = LocalDateTime.parse(subInput, formatter);
			return Timestamp.valueOf(dateTime);
		}
	}
	
	public static Double decimalConverter(Object input) {
		Double output = 0.00d;
		if(input instanceof Long) {
			output = Double.valueOf(String.valueOf(input));
		}
		else if(input instanceof String) {
			output = Double.valueOf((String) input);
		}
		return output;
	}

	public static LocalDate dateConverter(String input) {
		return LocalDate.parse(input);
	}
	
	public static LocalTime timeConverter(String input) {
		return LocalTime.parse(input);
	}
}
/*Formatting for Date / Time /Timetamp for scylla DB persist from private topic:
Timestamp format - yyyy-MM-dd-HH.mm.ss.SSS
topic data timestamp format - yyyy-MM-dd-HH.mm.ss.SSSSSS
Date format - "YYYY-MM-DD"
Time format - "hh:mm:ss"
*/