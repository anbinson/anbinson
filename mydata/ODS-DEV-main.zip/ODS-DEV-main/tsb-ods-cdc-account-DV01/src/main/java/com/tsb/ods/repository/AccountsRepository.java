package com.tsb.ods.repository;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

import com.tsb.ods.model.DV01Entity;


@Repository
public interface AccountsRepository extends CassandraRepository<DV01Entity, String> {		
	@Query("delete from tsbods.MNF_PRT_DV01_ACCOUNT where codentid=?0")
	void deleteTransaction(String codentid);
}