package com.tsb.ods.model;

import lombok.Builder;
import lombok.Data;

import java.sql.Timestamp;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(value = "MNF_PRT_BS46_TRANSACTION_TYPE")
@Data
@Builder
public class BS46Entity {

    @PrimaryKey("codcomop")
	private String codcomop;
	
	@Column("descomop")            
	private String descomop;
	
	@Column("codcomun")            
	private String codcomun;
	
	@Column("idioma")             
	private String idioma;
	
	@Column("reducido")            
	private String reducido;
	
	@Column("at_creation_time")            
	private Timestamp at_creation_time;
	
	@Column("at_creation_user")            
	private String at_creation_user;
	
	@Column("at_last_modified_time")              
	private Timestamp at_last_modified_time;
	
	@Column("at_last_modified_user")            
	private String at_last_modified_user;
	
	@Column("xx_checksum")
	private String xx_checksum;
}
 
