package com.tsb.ods.processor;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tsb.ods.converter.Converter;
import com.tsb.ods.model.BS46Entity;
import com.tsb.ods.repository.TransactionTypeRepository;
import com.tsb.ods.stream.schema.avro.BS4600.BS46TransactionType;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class StreamProcessor {

	private final TransactionTypeRepository transactonTypeRepository;
	private final MeterRegistry meterRegistry;
	@Autowired
	private KafkaTemplate<String, BS46TransactionType> kafkaTemplate;

	@Value("${topic.dlqname}")
	private String dlqTopic;

	private Counter transactonTypeInCounter; 
	private Counter transactonTypeOutCounter;

	@PostConstruct
	public void init() {
		log.info("Create and register metric counters with Meter registry");
		transactonTypeInCounter = Counter.builder("tsb_ods_in_transactonTypes_in_total")
				.description("Total number of transactonTypes since process start")
				.register(meterRegistry);
		transactonTypeOutCounter = Counter.builder("tsb_ods_out_transactonTypes_in_total")
				.description("Total number of transactonTypes processed")
				.register(meterRegistry);

	}

	@KafkaListener(topics = "${topic.name}", groupId = "${topic.name}")
	public void consume(ConsumerRecord<String, BS46TransactionType> record, Acknowledgment acknowledgment){
		log.info(String.format("Consumed message -> %s", record.value()));
		BS46TransactionType bsobj = record.value();
		log.info(String.format("Kafka message offset value -> %s", record.offset()));
		transactonTypeInCounter.increment();   
		BS46Entity bs46 = BS46Entity.builder()
				.codcomop(bsobj.getCODCOMOP())
				.descomop(bsobj.getDESCOMOP())
				.codcomun(bsobj.getCODCOMUN())
				.idioma(bsobj.getIDIOMA())
				.reducido(bsobj.getREDUCIDO())
				.at_creation_time(Converter.timestampConverter(bsobj.getATCREATIONTIME()))
				.at_creation_user(bsobj.getATCREATIONUSER())
				.at_last_modified_time(Converter.timestampConverter(bsobj.getATLASTMODIFIEDTIME()))
				.at_last_modified_user(bsobj.getATLASTMODIFIEDUSER())
				.xx_checksum(bsobj.getXXCHECKSUM())
				.build();
		try {
			ObjectMapper objecmapper =new ObjectMapper();
			String str;

			str = objecmapper.writeValueAsString(bs46);

			log.info("transaction type: "+ str);
			if ("DELETE".equals(bsobj.getEXECTYPE())) {
				transactonTypeRepository.deleteById(bs46.getCodcomop());
				log.info("Transacton type deleted in Scylladb:"+ bs46.getCodcomop());
			}
			else if("UPDATE".equals(bsobj.getEXECTYPE())) {
				transactonTypeRepository.updateTransaction(bs46.getCodcomop(), bs46.getDescomop(), bs46.getCodcomun(),
						bs46.getIdioma(), bs46.getReducido(), bs46.getAt_last_modified_time(), 
						bs46.getAt_last_modified_user(), bs46.getXx_checksum());
				log.info("Transacton type updated in Scylladb:"+ bs46.getCodcomop());
			}
			else {                
				transactonTypeRepository.save(bs46);
				log.info("Transacton Type stored in Scylladb:"+ bs46.getCodcomop());
			}

		} catch (Exception e) {
			ProducerRecord<String, BS46TransactionType> dlqrecord = new ProducerRecord<>(dlqTopic, record.key(), record.value());
			kafkaTemplate.send(dlqrecord);
		} finally {
			if (acknowledgment != null) {
				System.out.println("Acknowledgment provided");
				acknowledgment.acknowledge();
			}
		}
		transactonTypeOutCounter.increment();
	}
}
