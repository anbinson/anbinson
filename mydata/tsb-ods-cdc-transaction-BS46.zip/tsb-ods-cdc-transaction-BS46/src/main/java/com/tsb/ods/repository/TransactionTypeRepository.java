package com.tsb.ods.repository;

import java.sql.Timestamp;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

import com.tsb.ods.model.BS46Entity;


@Repository
public interface TransactionTypeRepository extends CassandraRepository<BS46Entity, String> {		
	@Query("delete from tsbods.MNF_PRT_BS46_TRANSACTION_TYPE where codcomop=?0")
	void deleteTransaction(String codcomop);
	

	@Query("update tsbods.MNF_PRT_BS46_TRANSACTION_TYPE SET descomop=?1, codcomun=?2 , idioma=?3, reducido=?4,"
			+ "at_last_modified_time=?5, at_last_modified_user=?6, xx_checksum=?7 "
			+ "where codcomop=?0")
	void updateTransaction(String codcomop, String descomop, String codcomun, String idioma, String reducido,
			Timestamp at_last_modified_time, String at_last_modified_user, String xx_checksum);
}
