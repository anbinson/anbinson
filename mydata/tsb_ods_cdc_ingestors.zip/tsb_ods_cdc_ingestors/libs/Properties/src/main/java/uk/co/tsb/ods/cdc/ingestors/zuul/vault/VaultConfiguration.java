package uk.co.tsb.ods.cdc.ingestors.zuul.vault;

import org.springframework.cloud.vault.config.SecretBackendConfigurer;
import org.springframework.cloud.vault.config.VaultConfigurer;

public class VaultConfiguration implements VaultConfigurer {

    @Override
    public void addSecretBackends(SecretBackendConfigurer configurer) {
        configurer.add("secret/tsb-push/zuul-keystore-password");
        configurer.add("secret/tsb-push/tsb-push-jwt-token-key");
        configurer.add("secret/tsb-push/cassandra-keystore-password");
        configurer.add("secret/tsb-push/cassandra-password");
        configurer.add("secret/tsb-push/cassandra-username");
        configurer.add("secret/tsb-push/kafka-jaas-config");
        configurer.add("secret/tsb-push/rest-api-keystore-password");
    }
}