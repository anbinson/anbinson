java -jar avro-tools-1.9.1.jar  compile schema src/main/avro/* ./src/main/java
