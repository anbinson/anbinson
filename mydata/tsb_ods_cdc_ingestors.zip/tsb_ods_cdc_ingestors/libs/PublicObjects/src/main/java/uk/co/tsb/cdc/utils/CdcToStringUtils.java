package uk.co.tsb.cdc.utils;

import uk.co.tsb.cdc.bs4600.BS4600;
import uk.co.tsb.cdc.bs4600.CDCTablebs4600;
import uk.co.tsb.cdc.dp0100.CDCTabledp0100;
import uk.co.tsb.cdc.dp0100.DP0100;
import uk.co.tsb.cdc.dv0100.CDCTabledv0100;
import uk.co.tsb.cdc.dv0100.DV0100;
import uk.co.tsb.cdc.kc0300.CDCTablekc0300;
import uk.co.tsb.cdc.kc0300.KC0300;
import uk.co.tsb.cdc.pe0600.CDCTablepe0600;
import uk.co.tsb.cdc.pe0600.PE0600;
import uk.co.tsb.cdc.pe1100.CDCTablepe1100;
import uk.co.tsb.cdc.pe1100.PE1100;
import uk.co.tsb.cdc.pe1600.CDCTablepe1600;
import uk.co.tsb.cdc.pe1600.PE1600;
import uk.co.tsb.cdc.tbbv_bs_alias.CDCTabletbbv_bs_alias;
import uk.co.tsb.cdc.tbbv_bs_alias.TBBV_BS_ALIAS;
import uk.co.tsb.cdc.tbbv_bs_auth_data.CDCTabletbbv_bs_auth_data;
import uk.co.tsb.cdc.tbbv_bs_auth_data.TBBV_BS_AUTH_DATA;
import uk.co.tsb.cdc.tbbv_bs_codigos_acceso.CDCTabletbbv_bs_codigos_acceso;
import uk.co.tsb.cdc.tbbv_bs_codigos_acceso.TBBV_BS_CODIGOS_ACCESO;
import uk.co.tsb.cdc.tbbv_bs_contratos.CDCTabletbbv_bs_contratos;
import uk.co.tsb.cdc.tbbv_bs_contratos.TBBV_BS_CONTRATOS;
import uk.co.tsb.cdc.tbbv_bs_enrollments.CDCTabletbbv_bs_enrollments;
import uk.co.tsb.cdc.tbbv_bs_enrollments.TBBV_BS_ENROLLMENTS;
import uk.co.tsb.cdc.tbbv_bs_servicios_contrato.CDCTabletbbv_bs_servicios_contrato;
import uk.co.tsb.cdc.tbbv_bs_servicios_contrato.TBBV_BS_SERVICIOS_CONTRATO;
import uk.co.tsb.cdc.tbbv_bs_usuarios.CDCTabletbbv_bs_usuarios;
import uk.co.tsb.cdc.tbbv_bs_usuarios.TBBV_BS_USUARIOS;

public final class CdcToStringUtils {
    private CdcToStringUtils() {
    }
    
    public static String toString(CDCTablebs4600 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTablebs4600{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }
    
    private static String toString(BS4600 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("BS4600{");
        sb.append("BS4600_CODCOMOP=").append(value.getBS4600CODCOMOP());
//        sb.append(", BS4600_DESCOMOP=").append(value.getBS4600DESCOMOP());
//        sb.append(", BS4600_CODCOMUN=").append(value.getBS4600CODCOMUN());
//        sb.append(", BS4600_IDIOMA=").append(value.getBS4600IDIOMA());
//        sb.append(", BS4600_REDUCIDO=").append(value.getBS4600REDUCIDO());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTabledp0100 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTabledp0100{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTabletbbv_bs_servicios_contrato value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTabletbbv_bs_servicios_contrato{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(TBBV_BS_SERVICIOS_CONTRATO value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("TBBV_BS_SERVICIOS_CONTRATO{");
        sb.append("PK_CODIGO=").append(value.getPKCODIGO());
        sb.append(", FK_CODIGO_CONTRATO=").append(value.getFKCODIGOCONTRATO());
        sb.append(", FK_CODIGO_SERVICIO=").append(value.getFKCODIGOSERVICIO());
        sb.append(", COID_ESTADO=").append(value.getCOIDESTADO());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(DP0100 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("DP0100{");
        sb.append("BS0100_CODENTID=").append(value.getBS0100CODENTID());
        sb.append(", DP0100_CODPRODO=").append(value.getDP0100CODPRODO());
//        sb.append(", DP0100_VERSPROD=").append(value.getDP0100VERSPROD());
        sb.append(", DP0100_DESPRODO=").append(value.getDP0100DESPRODO());
//        sb.append(", DP0100_ESTADO=").append(value.getDP0100ESTADO());
//        sb.append(", DP0100_INDPRODB=").append(value.getDP0100INDPRODB());
//        sb.append(", DP0100_INDDOSVE=").append(value.getDP0100INDDOSVE());
//        sb.append(", DP0100_CODPRODB=").append(value.getDP0100CODPRODB());
//        sb.append(", DP0100_VERSPRBA=").append(value.getDP0100VERSPRBA());
//        sb.append(", TP0100_CODPRODUCT=").append(value.getTP0100CODPRODUCT());
//        sb.append(", BS3400_CLAAPLIC=").append(value.getBS3400CLAAPLIC());
//        sb.append(", DP0100_INDNATUR=").append(value.getDP0100INDNATUR());
//        sb.append(", DP0100_INDLIQU1=").append(value.getDP0100INDLIQU1());
//        sb.append(", DP0100_INDLIQU2=").append(value.getDP0100INDLIQU2());
//        sb.append(", DP0100_INDLIQU3=").append(value.getDP0100INDLIQU3());
//        sb.append(", DP0100_INDLIQU4=").append(value.getDP0100INDLIQU4());
//        sb.append(", DP0100_INDDIVAD=").append(value.getDP0100INDDIVAD());
//        sb.append(", TS0900_CODIDIVI=").append(value.getTS0900CODIDIVI());
//        sb.append(", BS0200_CODCENTRO=").append(value.getBS0200CODCENTRO());
//        sb.append(", DP0100_INDOFERT=").append(value.getDP0100INDOFERT());
//        sb.append(", DP0100_INDRETR1=").append(value.getDP0100INDRETR1());
//        sb.append(", DP0100_INDRETR2=").append(value.getDP0100INDRETR2());
//        sb.append(", DP0100_INDRETR3=").append(value.getDP0100INDRETR3());
//        sb.append(", DP0100_INDRETE1=").append(value.getDP0100INDRETE1());
//        sb.append(", DP0100_INDRETE2=").append(value.getDP0100INDRETE2());
//        sb.append(", DP0100_INDRETE3=").append(value.getDP0100INDRETE3());
//        sb.append(", DP0100_INDTRAF1=").append(value.getDP0100INDTRAF1());
//        sb.append(", DP0100_INDTRAF2=").append(value.getDP0100INDTRAF2());
//        sb.append(", DP0100_INDTRAF3=").append(value.getDP0100INDTRAF3());
//        sb.append(", DP0100_INDCOMPU=").append(value.getDP0100INDCOMPU());
//        sb.append(", DP0100_INDSALCO=").append(value.getDP0100INDSALCO());
//        sb.append(", DP0100_INDTICU1=").append(value.getDP0100INDTICU1());
//        sb.append(", DP0100_INDTICU2=").append(value.getDP0100INDTICU2());
//        sb.append(", DP0100_INDTICU3=").append(value.getDP0100INDTICU3());
//        sb.append(", DP0100_CEROCIER=").append(value.getDP0100CEROCIER());
//        sb.append(", DP0100_INDRENO1=").append(value.getDP0100INDRENO1());
//        sb.append(", DP0100_INDRENO2=").append(value.getDP0100INDRENO2());
//        sb.append(", DP0100_INDRENO3=").append(value.getDP0100INDRENO3());
//        sb.append(", DP0100_INDUNCU1=").append(value.getDP0100INDUNCU1());
//        sb.append(", DP0100_INDUNCU2=").append(value.getDP0100INDUNCU2());
//        sb.append(", DP0100_INDUNCU3=").append(value.getDP0100INDUNCU3());
//        sb.append(", DP0100_INDPLAC1=").append(value.getDP0100INDPLAC1());
//        sb.append(", DP0100_INDPLAC2=").append(value.getDP0100INDPLAC2());
//        sb.append(", DP0100_INDPLAC3=").append(value.getDP0100INDPLAC3());
//        sb.append(", DP0100_INDEXCED=").append(value.getDP0100INDEXCED());
//        sb.append(", DP0100_ENTEDOMI=").append(value.getDP0100ENTEDOMI());
//        sb.append(", BS4000_CODCONVE=").append(value.getBS4000CODCONVE());
//        sb.append(", DP0100_INDSINDI=").append(value.getDP0100INDSINDI());
//        sb.append(", DP0100_INDDISPU=").append(value.getDP0100INDDISPU());
//        sb.append(", DP0100_IMPMAXL1=").append(value.getDP0100IMPMAXL1());
//        sb.append(", DP0100_IMPMAXL2=").append(value.getDP0100IMPMAXL2());
//        sb.append(", DP0100_IMPMAXL3=").append(value.getDP0100IMPMAXL3());
//        sb.append(", DP0100_UNIMMAX1=").append(value.getDP0100UNIMMAX1());
//        sb.append(", DP0100_UNIMMAX2=").append(value.getDP0100UNIMMAX2());
//        sb.append(", DP0100_UNIMMAX3=").append(value.getDP0100UNIMMAX3());
//        sb.append(", DP0100_IMPMINL1=").append(value.getDP0100IMPMINL1());
//        sb.append(", DP0100_IMPMINL2=").append(value.getDP0100IMPMINL2());
//        sb.append(", DP0100_IMPMINL3=").append(value.getDP0100IMPMINL3());
//        sb.append(", DP0100_UNIMMIN1=").append(value.getDP0100UNIMMIN1());
//        sb.append(", DP0100_UNIMMIN2=").append(value.getDP0100UNIMMIN2());
//        sb.append(", DP0100_UNIMMIN3=").append(value.getDP0100UNIMMIN3());
//        sb.append(", DP0100_INDSCOMP=").append(value.getDP0100INDSCOMP());
//        sb.append(", DP0100_INDSCONT=").append(value.getDP0100INDSCONT());
//        sb.append(", DP0100_INDSEXCE=").append(value.getDP0100INDSEXCE());
//        sb.append(", DP0100_INDSDOMI=").append(value.getDP0100INDSDOMI());
//        sb.append(", DP0100_INDMOVAC=").append(value.getDP0100INDMOVAC());
//        sb.append(", DP0100_INDRELIQ=").append(value.getDP0100INDRELIQ());
//        sb.append(", DP0100_FECALTPR=").append(value.getDP0100FECALTPR());
//        sb.append(", DP0100_FECBAJPR=").append(value.getDP0100FECBAJPR());
//        sb.append(", DP0100_FECACTPR=").append(value.getDP0100FECACTPR());
//        sb.append(", DP0100_FECDESPR=").append(value.getDP0100FECDESPR());
//        sb.append(", DP0100_PLAMINCO=").append(value.getDP0100PLAMINCO());
//        sb.append(", DP0100_PLAMAXCO=").append(value.getDP0100PLAMAXCO());
//        sb.append(", DP0100_UNPLAMIN=").append(value.getDP0100UNPLAMIN());
//        sb.append(", DP0100_UNPLAMAX=").append(value.getDP0100UNPLAMAX());
//        sb.append(", DP0100_CTROPROP=").append(value.getDP0100CTROPROP());
//        sb.append(", DP0100_CODENTRES=").append(value.getDP0100CODENTRES());
//        sb.append(", DP0100_INDCARPA=").append(value.getDP0100INDCARPA());
//        sb.append(", DP0100_IMPMAXEX=").append(value.getDP0100IMPMAXEX());
//        sb.append(", DP0100_MONIMPMA=").append(value.getDP0100MONIMPMA());
//        sb.append(", DP0100_PORIMPCA=").append(value.getDP0100PORIMPCA());
//        sb.append(", DP0100_INDAPREM=").append(value.getDP0100INDAPREM());
//        sb.append(", DP0100_INDRECAL=").append(value.getDP0100INDRECAL());
//        sb.append(", DP0100_INDSRECA=").append(value.getDP0100INDSRECA());
//        sb.append(", DP0100_PRECONTR=").append(value.getDP0100PRECONTR());
//        sb.append(", BS0000_FECULTACT=").append(value.getBS0000FECULTACT());
//        sb.append(", BS0000_HORULTACT=").append(value.getBS0000HORULTACT());
//        sb.append(", BS0000_CODTERMINA=").append(value.getBS0000CODTERMINA());
//        sb.append(", BS0000_CODUSUARIO=").append(value.getBS0000CODUSUARIO());
//        sb.append(", DP0100_DESPROCAT=").append(value.getDP0100DESPROCAT());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTabledv0100 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTabledv0100{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    private static String toString(DV0100 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("DV0100{");
        sb.append("BS0100_CODENTID=").append(value.getBS0100CODENTID());
        sb.append(", PE0600_TIPPRODUCT=").append(value.getPE0600TIPPRODUCT());
        sb.append(", PE0600_CODCONTRAT=").append(value.getPE0600CODCONTRAT());
        sb.append(", DP0100_CODPRODO=").append(value.getDP0100CODPRODO());
//        sb.append(", DV0100_COLECTIVO=").append(value.getDV0100COLECTIVO());
//        sb.append(", DP3800_CODCANAL=").append(value.getDP3800CODCANAL());
//        sb.append(", BS1100_CODCNAE=").append(value.getBS1100CODCNAE());
        sb.append(", PE1100_NUMPERSONA=").append(value.getPE1100NUMPERSONA());
//        sb.append(", BS1300_CODPERSOLI=").append(value.getBS1300CODPERSOLI());
//        sb.append(", KM0400_INDMARCA=").append(value.getKM0400INDMARCA());
//        sb.append(", KC0100_FECHAAPERT=").append(value.getKC0100FECHAAPERT());
//        sb.append(", DV0100_FECCONTRAT=").append(value.getDV0100FECCONTRAT());
//        sb.append(", KC0100_FECHAVENCI=").append(value.getKC0100FECHAVENCI());
//        sb.append(", KC0100_FEULRENOVA=").append(value.getKC0100FEULRENOVA());
//        sb.append(", KC0100_CODPERIODO=").append(value.getKC0100CODPERIODO());
//        sb.append(", KC0100_NUMPERIODO=").append(value.getKC0100NUMPERIODO());
//        sb.append(", TP1100_CODVALSEGM=").append(value.getTP1100CODVALSEGM());
//        sb.append(", TP1100_CODVALSGMN=").append(value.getTP1100CODVALSGMN());
//        sb.append(", KC0100_ACCIVENCIM=").append(value.getKC0100ACCIVENCIM());
//        sb.append(", KC0100_RENONLINE=").append(value.getKC0100RENONLINE());
//        sb.append(", BS0200_CODCENTRO=").append(value.getBS0200CODCENTRO());
//        sb.append(", BS1700_CODSECBESP=").append(value.getBS1700CODSECBESP());
//        sb.append(", TS0900_CODIDIVI=").append(value.getTS0900CODIDIVI());
//        sb.append(", KC0100_FEALTATARI=").append(value.getKC0100FEALTATARI());
//        sb.append(", KC0100_FEULTLIQUI=").append(value.getKC0100FEULTLIQUI());
//        sb.append(", KC0100_FEPROLIQUI=").append(value.getKC0100FEPROLIQUI());
//        sb.append(", KC0100_DIALIQUIDA=").append(value.getKC0100DIALIQUIDA());
//        sb.append(", DV0100_TMSULTMVTO=").append(value.getDV0100TMSULTMVTO());
//        sb.append(", KC0100_SALDOULLIQ=").append(value.getKC0100SALDOULLIQ());
//        sb.append(", DV0100_SALDMEDIO1=").append(value.getDV0100SALDMEDIO1());
//        sb.append(", DV0100_SALDMEDIO2=").append(value.getDV0100SALDMEDIO2());
//        sb.append(", DV0100_SALDMEDIO3=").append(value.getDV0100SALDMEDIO3());
//        sb.append(", DV0100_SALDMEDIO4=").append(value.getDV0100SALDMEDIO4());
//        sb.append(", DV0100_FECULTSALM=").append(value.getDV0100FECULTSALM());
//        sb.append(", KC0100_SDOANPRMOV=").append(value.getKC0100SDOANPRMOV());
//        sb.append(", KC0100_TSPRIMMVTO=").append(value.getKC0100TSPRIMMVTO());
//        sb.append(", KC0100_SITUACION=").append(value.getKC0100SITUACION());
//        sb.append(", KC0100_TSITUACION=").append(value.getKC0100TSITUACION());
//        sb.append(", KC0100_FEINACTIV=").append(value.getKC0100FEINACTIV());
//        sb.append(", KC0100_SALDO=").append(value.getKC0100SALDO());
//        sb.append(", KC0100_DISPONIBLE=").append(value.getKC0100DISPONIBLE());
//        sb.append(", DV0100_LIMITDISPO=").append(value.getDV0100LIMITDISPO());
//        sb.append(", DV0100_LIMITEREM=").append(value.getDV0100LIMITEREM());
//        sb.append(", DV0100_NOVENCIDO=").append(value.getDV0100NOVENCIDO());
//        sb.append(", DV0100_DEVOLCCO=").append(value.getDV0100DEVOLCCO());
//        sb.append(", DV0100_DEVOLCDI=").append(value.getDV0100DEVOLCDI());
//        sb.append(", DV0100_FECRETMOV=").append(value.getDV0100FECRETMOV());
//        sb.append(", DV0100_IMPRETENIDO=").append(value.getDV0100IMPRETENIDO());
//        sb.append(", KC0100_INDICATORS=").append(value.getKC0100INDICATORS());
//        sb.append(", DV0100_INDICATOR2=").append(value.getDV0100INDICATOR2());
//        sb.append(", DV0100_INDICATOR3=").append(value.getDV0100INDICATOR3());
//        sb.append(", DV0100_TIPPRODREL=").append(value.getDV0100TIPPRODREL());
//        sb.append(", DV0100_CODCONTREL=").append(value.getDV0100CODCONTREL());
//        sb.append(", DP0600_CODENTREL=").append(value.getDP0600CODENTREL());
//        sb.append(", BS0000_FECULTACT=").append(value.getBS0000FECULTACT());
//        sb.append(", BS0000_HORULTACT=").append(value.getBS0000HORULTACT());
//        sb.append(", BS0000_CODTERMINA=").append(value.getBS0000CODTERMINA());
//        sb.append(", BS0000_CODUSUARIO=").append(value.getBS0000CODUSUARIO());
//        sb.append(", BS0100_CODENTCOM=").append(value.getBS0100CODENTCOM());
//        sb.append(", BS0200_CODCTRCOM=").append(value.getBS0200CODCTRCOM());
//        sb.append(", PE1100_INDIDIOMA=").append(value.getPE1100INDIDIOMA());
//        sb.append(", DV0100_CLAVEBAR=").append(value.getDV0100CLAVEBAR());
//        sb.append(", DV0100_NUMEXTRAC=").append(value.getDV0100NUMEXTRAC());
//        sb.append(", DV0100_SDOEXTRAC=").append(value.getDV0100SDOEXTRAC());
//        sb.append(", DV0000_MARCAINFCO=").append(value.getDV0000MARCAINFCO());
//        sb.append(", SYS_START=").append(value.getSYSSTART());
//        sb.append(", SYS_END=").append(value.getSYSEND());
//        sb.append(", TRANS_ID=").append(value.getTRANSID());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTablekc0300 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTablekc0300{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    private static String toString(KC0300 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("KC0300{");
        sb.append("BS0100_CODENTID=").append(value.getBS0100CODENTID());
        sb.append(", PE0600_TIPPRODUCT=").append(value.getPE0600TIPPRODUCT());
        sb.append(", PE0600_CODCONTRAT=").append(value.getPE0600CODCONTRAT());
//        sb.append(", KC0300_TSFECHORA=").append(value.getKC0300TSFECHORA());
//        sb.append(", KC0300_SECOPERMUL=").append(value.getKC0300SECOPERMUL());
//        sb.append(", KC0300_SITUACOPER=").append(value.getKC0300SITUACOPER());
//        sb.append(", KC0300_TSPRODSITU=").append(value.getKC0300TSPRODSITU());
//        sb.append(", BS4500_CODORIOP=").append(value.getBS4500CODORIOP());
//        sb.append(", KC0300_ORIGENOPER=").append(value.getKC0300ORIGENOPER());
//        sb.append(", KC0300_INDCOOBJ=").append(value.getKC0300INDCOOBJ());
//        sb.append(", DP0200_INDGRUPO=").append(value.getDP0200INDGRUPO());
//        sb.append(", DP0200_CODOPERA=").append(value.getDP0200CODOPERA());
//        sb.append(", KC0300_CODIDIST=").append(value.getKC0300CODIDIST());
//        sb.append(", KC0300_INDICADORE=").append(value.getKC0300INDICADORE());
        sb.append(", TS0900_CODIDIVI=").append(value.getTS0900CODIDIVI());
        sb.append(", KC0300_IMPNETOPER=").append(value.getKC0300IMPNETOPER());
//        sb.append(", KC0300_FECHAVALOR=").append(value.getKC0300FECHAVALOR());
//        sb.append(", KC0300_FECONTABLE=").append(value.getKC0300FECONTABLE());
//        sb.append(", KC0300_FECINIINAC=").append(value.getKC0300FECINIINAC());
        sb.append(", KC0300_CONCPREDUC=").append(value.getKC0300CONCPREDUC());
//        sb.append(", KC0300_CODENTIOP=").append(value.getKC0300CODENTIOP());
//        sb.append(", BS0200_CODCENTRO=").append(value.getBS0200CODCENTRO());
//        sb.append(", BS0000_FECULTACT=").append(value.getBS0000FECULTACT());
//        sb.append(", BS0000_HORULTACT=").append(value.getBS0000HORULTACT());
//        sb.append(", BS0000_CODTERMINA=").append(value.getBS0000CODTERMINA());
//        sb.append(", BS0000_CODUSUARIO=").append(value.getBS0000CODUSUARIO());
//        sb.append(", KC0300_INDICADOR2=").append(value.getKC0300INDICADOR2());
//        sb.append(", KC0300_FECSESION=").append(value.getKC0300FECSESION());
//        sb.append(", KC0300_NUMAPTBULL=").append(value.getKC0300NUMAPTBULL());
//        sb.append(", KC0300_FECCOMUNIC=").append(value.getKC0300FECCOMUNIC());
//        sb.append(", KC0300_NUMEXTRACTO=").append(value.getKC0300NUMEXTRACTO());
//        sb.append(", KC0300_NUMOTPBULL=").append(value.getKC0300NUMOTPBULL());
//        sb.append(", KC0300_INDLIBEXT=").append(value.getKC0300INDLIBEXT());
//        sb.append(", KC0300_DOCUASOC=").append(value.getKC0300DOCUASOC());
//        sb.append(", KC0300_DOCUINTEG=").append(value.getKC0300DOCUINTEG());
//        sb.append(", KC0300_DOCURETEN=").append(value.getKC0300DOCURETEN());
//        sb.append(", KC0300_REMTALEXCED=").append(value.getKC0300REMTALEXCED());
//        sb.append(", KC0300_BLOQMOROSO=").append(value.getKC0300BLOQMOROSO());
//        sb.append(", KC0300_REFERN43=").append(value.getKC0300REFERN43());
//        sb.append(", KC0300_INFCOMPLEM=").append(value.getKC0300INFCOMPLEM());
//        sb.append(", KC0300_INDBARRIDO=").append(value.getKC0300INDBARRIDO());
//        sb.append(", KC0300_INDMODVALOR=").append(value.getKC0300INDMODVALOR());
//        sb.append(", KC0300_INDANULMDC=").append(value.getKC0300INDANULMDC());
//        sb.append(", KC0300_CODOPEBULL=").append(value.getKC0300CODOPEBULL());
//        sb.append(", KC0300_CODPROBULL=").append(value.getKC0300CODPROBULL());
//        sb.append(", KC0300_CODASIBULL=").append(value.getKC0300CODASIBULL());
//        sb.append(", KC0300_REFINTERBUL=").append(value.getKC0300REFINTERBUL());
//        sb.append(", KC0300_RESTOCONCP=").append(value.getKC0300RESTOCONCP());
//        sb.append(", KC0300_REFERENCOR=").append(value.getKC0300REFERENCOR());
//        sb.append(", KC0300_CODCOMU=").append(value.getKC0300CODCOMU());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTablepe0600 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTablepe0600{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    private static String toString(PE0600 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("PE0600{");
        sb.append("PE0600_TIPPRODUCT=").append(value.getPE0600TIPPRODUCT());
//        sb.append(", TP0100_CODPRODUCT=").append(value.getTP0100CODPRODUCT());
        sb.append(", PE0600_CODCONTRAT=").append(value.getPE0600CODCONTRAT());
//        sb.append(", PE0600_DIGCONTRAT=").append(value.getPE0600DIGCONTRAT());
//        sb.append(", PE0600_INDSITCONT=").append(value.getPE0600INDSITCONT());
//        sb.append(", PE0600_INDNIVCONF=").append(value.getPE0600INDNIVCONF());
//        sb.append(", PE0600_INDNIVCONB=").append(value.getPE0600INDNIVCONB());
//        sb.append(", BS1700_CODSECBESP=").append(value.getBS1700CODSECBESP());
//        sb.append(", PE0600_INDTIPCONT=").append(value.getPE0600INDTIPCONT());
//        sb.append(", PE0600_FECALTA=").append(value.getPE0600FECALTA());
//        sb.append(", PE0600_FECBAJA=").append(value.getPE0600FECBAJA());
//        sb.append(", BS0000_CODTERMINA=").append(value.getBS0000CODTERMINA());
//        sb.append(", BS0000_CODUSUARIO=").append(value.getBS0000CODUSUARIO());
//        sb.append(", BS0000_FECULTACT=").append(value.getBS0000FECULTACT());
//        sb.append(", BS0000_HORULTACT=").append(value.getBS0000HORULTACT());
        sb.append(", BS0100_CODENTID=").append(value.getBS0100CODENTID());
//        sb.append(", BS0200_CODCENTRO=").append(value.getBS0200CODCENTRO());
//        sb.append(", DP0100_CODPRODO=").append(value.getDP0100CODPRODO());
//        sb.append(", TS0900_CODIDIVI=").append(value.getTS0900CODIDIVI());
//        sb.append(", BS0100_CODENTCOM=").append(value.getBS0100CODENTCOM());
//        sb.append(", BS0200_CODCTRCOM=").append(value.getBS0200CODCTRCOM());
//        sb.append(", PE1100_INDIDIOMA=").append(value.getPE1100INDIDIOMA());
//        sb.append(", PE0600_INDINCOR=").append(value.getPE0600INDINCOR());
//        sb.append(", PE0600_INDRIESG=").append(value.getPE0600INDRIESG());
//        sb.append(", IA0000_MARCA=").append(value.getIA0000MARCA());
//        sb.append(", PE0600_COLECTIVO=").append(value.getPE0600COLECTIVO());
//        sb.append(", PE0600_FECSOLIT=").append(value.getPE0600FECSOLIT());
//        sb.append(", PE0600_CODUSUSOLI=").append(value.getPE0600CODUSUSOLI());
//        sb.append(", PE0600_CANALE=").append(value.getPE0600CANALE());
//        sb.append(", PE0600_PROCEDENE=").append(value.getPE0600PROCEDENE());
//        sb.append(", PE1100_CODSECECO=").append(value.getPE1100CODSECECO());
//        sb.append(", PE1100_CODEBA=").append(value.getPE1100CODEBA());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTablepe1100 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTablepe1100{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    private static String toString(PE1100 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("PE1100{");
        sb.append("PE1100_NUMPERSONA=").append(value.getPE1100NUMPERSONA());
//        sb.append(", PE1100_DIGPERSONA=").append(value.getPE1100DIGPERSONA());
//        sb.append(", PE1100_INDTIPPERS=").append(value.getPE1100INDTIPPERS());
//        sb.append(", PE1100_ALFPRIAPEL=").append(value.getPE1100ALFPRIAPEL());
//        sb.append(", PE1100_ALFSEGAPEL=").append(value.getPE1100ALFSEGAPEL());
//        sb.append(", PE1100_ALFNOMBRE=").append(value.getPE1100ALFNOMBRE());
//        sb.append(", BS1400_CODORIALTA=").append(value.getBS1400CODORIALTA());
//        sb.append(", BS1100_CODCNAE=").append(value.getBS1100CODCNAE());
//        sb.append(", PE1100_NUMFAX=").append(value.getPE1100NUMFAX());
//        sb.append(", PE1100_FECALTA=").append(value.getPE1100FECALTA());
//        sb.append(", PE1100_FECDEFUNCI=").append(value.getPE1100FECDEFUNCI());
//        sb.append(", PE1100_FECNACIMIE=").append(value.getPE1100FECNACIMIE());
//        sb.append(", PE1100_CODESTCIVI=").append(value.getPE1100CODESTCIVI());
//        sb.append(", PE1100_FECESTCIVI=").append(value.getPE1100FECESTCIVI());
//        sb.append(", PE1100_INDSEXO=").append(value.getPE1100INDSEXO());
//        sb.append(", BS1200_CODCNO=").append(value.getBS1200CODCNO());
//        sb.append(", PE1100_INDTIPIDEF=").append(value.getPE1100INDTIPIDEF());
//        sb.append(", PE1100_NUMIDEFISC=").append(value.getPE1100NUMIDEFISC());
//        sb.append(", PE1100_NUMIDEPAIS=").append(value.getPE1100NUMIDEPAIS());
//        sb.append(", PE1100_INDIDIOMA=").append(value.getPE1100INDIDIOMA());
//        sb.append(", PE1100_INDESTCONT=").append(value.getPE1100INDESTCONT());
//        sb.append(", PE1100_INESCONANT=").append(value.getPE1100INESCONANT());
//        sb.append(", PE1100_FECAMBIO=").append(value.getPE1100FECAMBIO());
//        sb.append(", BS0900_CODPAIS=").append(value.getBS0900CODPAIS());
//        sb.append(", PE1100_INDNIVCONF=").append(value.getPE1100INDNIVCONF());
//        sb.append(", PE1100_INDNIVCONB=").append(value.getPE1100INDNIVCONB());
//        sb.append(", PE1100_DESPRIAPEL=").append(value.getPE1100DESPRIAPEL());
//        sb.append(", PE1100_DESSEGAPEL=").append(value.getPE1100DESSEGAPEL());
//        sb.append(", PE1100_DESNOMBRE=").append(value.getPE1100DESNOMBRE());
//        sb.append(", PE1100_INDCONTBOR=").append(value.getPE1100INDCONTBOR());
//        sb.append(", PE1100_INDSITECON=").append(value.getPE1100INDSITECON());
//        sb.append(", PE1100_FECSITECON=").append(value.getPE1100FECSITECON());
//        sb.append(", PE1100_INDINCAPAC=").append(value.getPE1100INDINCAPAC());
//        sb.append(", PE0900_NUMDIRECCI=").append(value.getPE0900NUMDIRECCI());
//        sb.append(", PE1100_INDOTRDIRE=").append(value.getPE1100INDOTRDIRE());
//        sb.append(", PE1100_INDNIVAVIM=").append(value.getPE1100INDNIVAVIM());
//        sb.append(", BS2600_CODSEGINST=").append(value.getBS2600CODSEGINST());
//        sb.append(", PE1100_TIPACTSGMI=").append(value.getPE1100TIPACTSGMI());
//        sb.append(", BS0000_CODTERMINA=").append(value.getBS0000CODTERMINA());
//        sb.append(", BS0000_CODUSUARIO=").append(value.getBS0000CODUSUARIO());
//        sb.append(", BS0000_FECULTACT=").append(value.getBS0000FECULTACT());
//        sb.append(", BS0000_HORULTACT=").append(value.getBS0000HORULTACT());
//        sb.append(", PE1100_INDENVCORR=").append(value.getPE1100INDENVCORR());
//        sb.append(", TP1100_CODVALSEGM=").append(value.getTP1100CODVALSEGM());
//        sb.append(", TP1100_CODVALSGMN=").append(value.getTP1100CODVALSGMN());
//        sb.append(", PE1100_FECBAJMAN=").append(value.getPE1100FECBAJMAN());
//        sb.append(", PE1100_FEACSGMN=").append(value.getPE1100FEACSGMN());
//        sb.append(", PE1100_CODNACIONA=").append(value.getPE1100CODNACIONA());
//        sb.append(", BS1300_CODSEBE=").append(value.getBS1300CODSEBE());
//        sb.append(", PE1100_IDIOMADO=").append(value.getPE1100IDIOMADO());
//        sb.append(", PE1100_CODSEGINI=").append(value.getPE1100CODSEGINI());
//        sb.append(", PE1100_CODSUBINI=").append(value.getPE1100CODSUBINI());
//        sb.append(", PE1100_SEPAPELL=").append(value.getPE1100SEPAPELL());
//        sb.append(", PE1100_CENVCAMP=").append(value.getPE1100CENVCAMP());
//        sb.append(", PE1100_NIVRENTA=").append(value.getPE1100NIVRENTA());
//        sb.append(", PE1100_FECACTRE=").append(value.getPE1100FECACTRE());
//        sb.append(", PE1100_PROCRENT=").append(value.getPE1100PROCRENT());
//        sb.append(", PE1100_NIVFACTU=").append(value.getPE1100NIVFACTU());
//        sb.append(", PE1100_FECACTFA=").append(value.getPE1100FECACTFA());
//        sb.append(", PE1100_PROCFACT=").append(value.getPE1100PROCFACT());
//        sb.append(", PE0000_ENTIDNPER=").append(value.getPE0000ENTIDNPER());
//        sb.append(", PE1100_INITIALFST=").append(value.getPE1100INITIALFST());
//        sb.append(", PE1100_INITIALSCD=").append(value.getPE1100INITIALSCD());
//        sb.append(", PE1100_INITIALTRD=").append(value.getPE1100INITIALTRD());
//        sb.append(", PE1100_INITIALFOR=").append(value.getPE1100INITIALFOR());
//        sb.append(", PE1100_INITIALFIF=").append(value.getPE1100INITIALFIF());
//        sb.append(", PE1100_ALFNAMESCD=").append(value.getPE1100ALFNAMESCD());
//        sb.append(", PE1100_ALFNAMETHD=").append(value.getPE1100ALFNAMETHD());
//        sb.append(", PE1100_DESNAMESCD=").append(value.getPE1100DESNAMESCD());
//        sb.append(", PE1100_DESNAMETHD=").append(value.getPE1100DESNAMETHD());
//        sb.append(", PE1100_PARTYTITLE=").append(value.getPE1100PARTYTITLE());
//        sb.append(", PE1100_NAMESUFFIX=").append(value.getPE1100NAMESUFFIX());
//        sb.append(", PE1100_PARTYGENER=").append(value.getPE1100PARTYGENER());
//        sb.append(", PE1100_PARTITLEPRV=").append(value.getPE1100PARTITLEPRV());
//        sb.append(", PE1100_ALFNAMFPRV=").append(value.getPE1100ALFNAMFPRV());
//        sb.append(", PE1100_ALFSUNAPRV=").append(value.getPE1100ALFSUNAPRV());
//        sb.append(", PE1100_NAMEFSTPRV=").append(value.getPE1100NAMEFSTPRV());
//        sb.append(", PE1100_NAMESCDPRV=").append(value.getPE1100NAMESCDPRV());
//        sb.append(", PE1100_NAMETHDPRV=").append(value.getPE1100NAMETHDPRV());
//        sb.append(", PE1100_SURNAMEPRV=").append(value.getPE1100SURNAMEPRV());
//        sb.append(", PE1100_NAMESUFPRV=").append(value.getPE1100NAMESUFPRV());
//        sb.append(", PE1100_PARTGENPRV=").append(value.getPE1100PARTGENPRV());
//        sb.append(", PE1100_FECNAMECHG=").append(value.getPE1100FECNAMECHG());
//        sb.append(", PE1100_BRAILLE=").append(value.getPE1100BRAILLE());
//        sb.append(", PE1100_INDPEP=").append(value.getPE1100INDPEP());
//        sb.append(", PE1100_VULNERABLE=").append(value.getPE1100VULNERABLE());
//        sb.append(", PE1100_FECDEATHNOT=").append(value.getPE1100FECDEATHNOT());
//        sb.append(", PE1100_INDICADORES=").append(value.getPE1100INDICADORES());
//        sb.append(", PE1100_ACCOPLAN=").append(value.getPE1100ACCOPLAN());
//        sb.append(", PE1100_INDICATOR2=").append(value.getPE1100INDICATOR2());
//        sb.append(", PE1100_INDSAFECUST=").append(value.getPE1100INDSAFECUST());
//        sb.append(", PE1100_CODTYPBUSS=").append(value.getPE1100CODTYPBUSS());
//        sb.append(", PE1300_CODEMPLSTA=").append(value.getPE1300CODEMPLSTA());
//        sb.append(", PE1300_CODOCCUPAT=").append(value.getPE1300CODOCCUPAT());
//        sb.append(", PE1300_CODJOBROL=").append(value.getPE1300CODJOBROL());
//        sb.append(", PE1100_INDCONAS=").append(value.getPE1100INDCONAS());
//        sb.append(", PE1100_INDALTRD=").append(value.getPE1100INDALTRD());
//        sb.append(", PE1100_INDAQCU=").append(value.getPE1100INDAQCU());
//        sb.append(", PE1100_FECMERGE=").append(value.getPE1100FECMERGE());
//        sb.append(", PE1100_CODSECECO=").append(value.getPE1100CODSECECO());
//        sb.append(", PE1100_CODEBA=").append(value.getPE1100CODEBA());
//        sb.append(", PE1100_FECACQU=").append(value.getPE1100FECACQU());
//        sb.append(", PE1100_INDCONMOR=").append(value.getPE1100INDCONMOR());
//        sb.append(", PE1100_INDRESID=").append(value.getPE1100INDRESID());
//        sb.append(", PE1100_OFICALTA=").append(value.getPE1100OFICALTA());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTablepe1600 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTablepe1600{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    private static String toString(PE1600 value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("PE1600{");
        sb.append("PE1100_NUMPERSONA=").append(value.getPE1100NUMPERSONA());
        sb.append(", PE0600_TIPPRODUCT=").append(value.getPE0600TIPPRODUCT());
        sb.append(", PE0600_CODCONTRAT=").append(value.getPE0600CODCONTRAT());
//        sb.append(", PE1600_DIGCONTRAT=").append(value.getPE1600DIGCONTRAT());
//        sb.append(", BS2100_CODRELPECO=").append(value.getBS2100CODRELPECO());
//        sb.append(", PE1600_INDTIPCONT=").append(value.getPE1600INDTIPCONT());
//        sb.append(", TP0100_CODPRODUCT=").append(value.getTP0100CODPRODUCT());
//        sb.append(", PE1600_NUMORDCORR=").append(value.getPE1600NUMORDCORR());
//        sb.append(", PE1600_INDTITGEST=").append(value.getPE1600INDTITGEST());
//        sb.append(", PE1600_FECALTA=").append(value.getPE1600FECALTA());
//        sb.append(", PE1600_FECBAJA=").append(value.getPE1600FECBAJA());
//        sb.append(", PE0900_NUMDIRECCI=").append(value.getPE0900NUMDIRECCI());
//        sb.append(", PE1600_NUMFIRMAS=").append(value.getPE1600NUMFIRMAS());
//        sb.append(", PE1600_INDFIRPEND=").append(value.getPE1600INDFIRPEND());
//        sb.append(", PE1600_INDAUTTOTP=").append(value.getPE1600INDAUTTOTP());
//        sb.append(", PE1600_INDDISINDI=").append(value.getPE1600INDDISINDI());
//        sb.append(", PE1600_INDDISMANC=").append(value.getPE1600INDDISMANC());
//        sb.append(", PE1600_INDDISESPE=").append(value.getPE1600INDDISESPE());
//        sb.append(", PE1600_IMPDISINDI=").append(value.getPE1600IMPDISINDI());
//        sb.append(", PE1600_PCTDISINDI=").append(value.getPE1600PCTDISINDI());
//        sb.append(", PE1600_IMPDISMANC=").append(value.getPE1600IMPDISMANC());
//        sb.append(", PE1600_PCTDISMANC=").append(value.getPE1600PCTDISMANC());
//        sb.append(", PE1600_PCTPROCUEN=").append(value.getPE1600PCTPROCUEN());
//        sb.append(", PE0600_INDSITCONT=").append(value.getPE0600INDSITCONT());
//        sb.append(", BS0000_CODTERMINA=").append(value.getBS0000CODTERMINA());
//        sb.append(", BS0000_CODUSUARIO=").append(value.getBS0000CODUSUARIO());
//        sb.append(", BS0000_FECULTACT=").append(value.getBS0000FECULTACT());
//        sb.append(", BS0000_HORULTACT=").append(value.getBS0000HORULTACT());
//        sb.append(", PE1600_INDCONFCON=").append(value.getPE1600INDCONFCON());
//        sb.append(", PE1600_FECCADUCI=").append(value.getPE1600FECCADUCI());
//        sb.append(", PE1600_INDGARANT=").append(value.getPE1600INDGARANT());
//        sb.append(", PE1600_PCTGARMAN=").append(value.getPE1600PCTGARMAN());
//        sb.append(", PE1600_IMPGARMAN=").append(value.getPE1600IMPGARMAN());
//        sb.append(", PE1600_INDOBSERVA=").append(value.getPE1600INDOBSERVA());
        sb.append(", BS0100_CODENTID=").append(value.getBS0100CODENTID());
//        sb.append(", BS0100_CODENTCOM=").append(value.getBS0100CODENTCOM());
//        sb.append(", PE1600_INDPERSIG=").append(value.getPE1600INDPERSIG());
//        sb.append(", PE1600_ORDENTIT=").append(value.getPE1600ORDENTIT());
//        sb.append(", PE1100_ALFPRIAPEL=").append(value.getPE1100ALFPRIAPEL());
//        sb.append(", PE1100_ALFSEGAPEL=").append(value.getPE1100ALFSEGAPEL());
//        sb.append(", PE1100_ALFNOMBRE=").append(value.getPE1100ALFNOMBRE());
//        sb.append(", BS0200_CODCENTRO=").append(value.getBS0200CODCENTRO());
//        sb.append(", BS0200_CODCTRCOM=").append(value.getBS0200CODCTRCOM());
//        sb.append(", PE1100_INDSEXO=").append(value.getPE1100INDSEXO());
//        sb.append(", PE1100_FECNACIMIE=").append(value.getPE1100FECNACIMIE());
//        sb.append(", PE1100_INDTIPIDEF=").append(value.getPE1100INDTIPIDEF());
//        sb.append(", PE0000_ENTIDNPER=").append(value.getPE0000ENTIDNPER());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTabletbbv_bs_codigos_acceso value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTablepe1600{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    private static String toString(TBBV_BS_CODIGOS_ACCESO value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("TBBV_BS_CODIGOS_ACCESO{");
        sb.append("PK_CODIGO=").append(value.getPKCODIGO());
        sb.append(", FK_CODIGO_USUARIO=").append(value.getFKCODIGOUSUARIO());
//        sb.append(", FK_CODIGO_TIPO_CNX=").append(value.getFKCODIGOTIPOCNX());
//        sb.append(", FK_MANDATE=").append(value.getFKMANDATE());
//        sb.append(", COID_ESTADO=").append(value.getCOIDESTADO());
//        sb.append(", COFC_PRIMERA_CNX=").append(value.getCOFCPRIMERACNX());
//        sb.append(", COFC_ULTIMA_CNX=").append(value.getCOFCULTIMACNX());
//        sb.append(", CODE_CNL_PRIMERA_CNX=").append(value.getCODECNLPRIMERACNX());
//        sb.append(", CODE_CNL_ULTIMA_CNX=").append(value.getCODECNLULTIMACNX());
//        sb.append(", COID_PRIMER_USO=").append(value.getCOIDPRIMERUSO());
//        sb.append(", COID_STATE_REASON=").append(value.getCOIDSTATEREASON());
//        sb.append(", CODE_OBSERVATIONS=").append(value.getCODEOBSERVATIONS());
//        sb.append(", COFC_FECHA_ALTA=").append(value.getCOFCFECHAALTA());
//        sb.append(", COID_USUARIO_ALTA=").append(value.getCOIDUSUARIOALTA());
//        sb.append(", COFC_FECHA_MODIF=").append(value.getCOFCFECHAMODIF());
//        sb.append(", COID_USUARIO_MODIF=").append(value.getCOIDUSUARIOMODIF());
//        sb.append(", COFC_FECHA_BAJA=").append(value.getCOFCFECHABAJA());
//        sb.append(", COID_USUARIO_BAJA=").append(value.getCOIDUSUARIOBAJA());
//        sb.append(", COID_CHANNEL_MOD=").append(value.getCOIDCHANNELMOD());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTabletbbv_bs_alias value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTabletbbv_bs_alias{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    private static String toString(TBBV_BS_ALIAS value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("TBBV_BS_ALIAS{");
//        sb.append("PK_CODIGO=").append(value.getPKCODIGO());
        sb.append(", FK_CODIGO_USUARIO=").append(value.getFKCODIGOUSUARIO());
//        sb.append(", CODE_ALIAS=").append(value.getCODEALIAS());
        sb.append(", COTP_TIPO=").append(value.getCOTPTIPO());
        sb.append(", COUN_CUENTA=").append(value.getCOUNCUENTA());
//        sb.append(", COTP_TIPO_CUENTA=").append(value.getCOTPTIPOCUENTA());
//        sb.append(", COFC_FECHA_ALTA=").append(value.getCOFCFECHAALTA());
//        sb.append(", COID_USUARIO_ALTA=").append(value.getCOIDUSUARIOALTA());
//        sb.append(", COFC_FECHA_MODIF=").append(value.getCOFCFECHAMODIF());
//        sb.append(", COID_USUARIO_MODIF=").append(value.getCOIDUSUARIOMODIF());
//        sb.append(", COFC_FECHA_BAJA=").append(value.getCOFCFECHABAJA());
//        sb.append(", COID_USUARIO_BAJA=").append(value.getCOIDUSUARIOBAJA());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTabletbbv_bs_contratos value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTabletbbv_bs_contratos{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    private static String toString(TBBV_BS_CONTRATOS value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("TBBV_BS_CONTRATOS{");
        sb.append("PK_CODIGO=").append(value.getPKCODIGO());
//        sb.append(", FK_CODIGO_ENT=").append(value.getFKCODIGOENT());
//        sb.append(", FK_CANAL_CONTRATACION=").append(value.getFKCANALCONTRATACION());
//        sb.append(", FK_CANAL_MODIF=").append(value.getFKCANALMODIF());
//        sb.append(", FK_CANAL_CANCELA=").append(value.getFKCANALCANCELA());
//        sb.append(", FK_TIPO_CONT=").append(value.getFKTIPOCONT());
//        sb.append(", FK_CODIGO_ESTADO=").append(value.getFKCODIGOESTADO());
//        sb.append(", CODE_CODIGO_BV=").append(value.getCODECODIGOBV());
        sb.append(", COUN_NUMPER=").append(value.getCOUNNUMPER());
//        sb.append(", COID_MOTIVO_ESTADO=").append(value.getCOIDMOTIVOESTADO());
//        sb.append(", COFC_FECHA_CONTRATACION=").append(value.getCOFCFECHACONTRATACION());
//        sb.append(", COFC_FECHA_ACTIVA=").append(value.getCOFCFECHAACTIVA());
//        sb.append(", COFC_FECHA_CANCELA=").append(value.getCOFCFECHACANCELA());
//        sb.append(", CODE_CUENTA_VISTA=").append(value.getCODECUENTAVISTA());
//        sb.append(", CODE_OFICINA=").append(value.getCODEOFICINA());
//        sb.append(", COFC_FECHA_IMP=").append(value.getCOFCFECHAIMP());
//        sb.append(", COFC_FECHA_ALTA=").append(value.getCOFCFECHAALTA());
//        sb.append(", COID_USUARIO_ALTA=").append(value.getCOIDUSUARIOALTA());
//        sb.append(", COFC_FECHA_MODIF=").append(value.getCOFCFECHAMODIF());
//        sb.append(", COID_USUARIO_MODIF=").append(value.getCOIDUSUARIOMODIF());
//        sb.append(", COFC_FECHA_BAJA=").append(value.getCOFCFECHABAJA());
//        sb.append(", COID_USUARIO_BAJA=").append(value.getCOIDUSUARIOBAJA());
//        sb.append(", CODE_SALT=").append(value.getCODESALT());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTabletbbv_bs_auth_data value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTabletbbv_bs_auth_data{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    private static String toString(TBBV_BS_AUTH_DATA value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("TBBV_BS_AUTH_DATA{");
        sb.append("FK_AUTHENTICATION=").append(value.getFKAUTHENTICATION());
        sb.append(", CODE_LOGIN=").append(value.getCODELOGIN());
//        sb.append(", COIN_AUTOGENERATED=").append(value.getCOINAUTOGENERATED());
//        sb.append(", CODE_PASSWORD_IVR=").append(value.getCODEPASSWORDIVR());
//        sb.append(", CODE_SECURITY_NUMBER=").append(value.getCODESECURITYNUMBER());
//        sb.append(", COUN_ATTEMPS=").append(value.getCOUNATTEMPS());
//        sb.append(", COUN_REQUESTED=").append(value.getCOUNREQUESTED());
//        sb.append(", COID_REGIST_USER=").append(value.getCOIDREGISTUSER());
//        sb.append(", COFC_REGIST_DATE=").append(value.getCOFCREGISTDATE());
//        sb.append(", COID_MODIF_USER=").append(value.getCOIDMODIFUSER());
//        sb.append(", COFC_MODIF_DATE=").append(value.getCOFCMODIFDATE());
//        sb.append(", COID_DEREGIST_USER=").append(value.getCOIDDEREGISTUSER());
//        sb.append(", COFC_DEREGIST_DATE=").append(value.getCOFCDEREGISTDATE());
//        sb.append(", CODE_MEMO_POSITIONS=").append(value.getCODEMEMOPOSITIONS());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTabletbbv_bs_enrollments value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTabletbbv_bs_enrollments{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    private static String toString(TBBV_BS_ENROLLMENTS value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("TBBV_BS_ENROLLMENTS{");
        sb.append("PK_CODIGO=").append(value.getPKCODIGO());
        sb.append(", CODE_DEVICE=").append(value.getCODEDEVICE());
//        sb.append(", CODE_TOKEN=").append(value.getCODETOKEN());
        sb.append(", FK_USER=").append(value.getFKUSER());
        sb.append(", COID_STATUS=").append(value.getCOIDSTATUS());
//        sb.append(", COFC_ENROLLED_DATE=").append(value.getCOFCENROLLEDDATE());
//        sb.append(", COID_ENROLLED_TYPE=").append(value.getCOIDENROLLEDTYPE());
//        sb.append(", COID_REGIST_USER=").append(value.getCOIDREGISTUSER());
//        sb.append(", COFC_REGIST_DATE=").append(value.getCOFCREGISTDATE());
//        sb.append(", COID_MODIF_USER=").append(value.getCOIDMODIFUSER());
//        sb.append(", COFC_MODIF_DATE=").append(value.getCOFCMODIFDATE());
//        sb.append(", COID_DEREGIST_USER=").append(value.getCOIDDEREGISTUSER());
//        sb.append(", COFC_DEREGIST_DATE=").append(value.getCOFCDEREGISTDATE());
//        sb.append(", CANCEL_REASON=").append(value.getCANCELREASON());
//        sb.append(", COFC_CHECK_DATE=").append(value.getCOFCCHECKDATE());
//        sb.append(", REGISTER_ORIGIN=").append(value.getREGISTERORIGIN());
//        sb.append(", USER_AGENT=").append(value.getUSERAGENT());
//        sb.append(", IP_ADDRESS=").append(value.getIPADDRESS());
        sb.append('}');
        return sb.toString();
    }

    public static String toString(CDCTabletbbv_bs_usuarios value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("CDCTabletbbv_bs_usuarios{");
        sb.append("beforeImage=").append(toString(value.getBeforeImage()));
        sb.append(", afterImage=").append(toString(value.getAfterImage()));
        sb.append(", A_ENTTYP=").append(value.getAENTTYP());
        sb.append(", A_CCID=").append(value.getACCID());
        sb.append(", A_TIMSTAMP=").append(value.getATIMSTAMP());
        sb.append('}');
        return sb.toString();
    }

    private static String toString(TBBV_BS_USUARIOS value) {
        if (value == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("TBBV_BS_USUARIOS{");
        sb.append("PK_CODIGO=").append(value.getPKCODIGO());
//        sb.append(", FK_CODIGO_SERV_CONT=").append(value.getFKCODIGOSERVCONT());
        sb.append(", FK_CODIGO_CONTRATO=").append(value.getFKCODIGOCONTRATO());
//        sb.append(", COIN_TITULAR=").append(value.getCOINTITULAR());
//        sb.append(", CODE_USUARIO_TIT=").append(value.getCODEUSUARIOTIT());
        sb.append(", COID_ESTADO=").append(value.getCOIDESTADO());
//        sb.append(", COID_MOTIVO_ESTADO=").append(value.getCOIDMOTIVOESTADO());
//        sb.append(", CODE_OBSERVACIONES=").append(value.getCODEOBSERVACIONES());
//        sb.append(", CODE_NOMBRE=").append(value.getCODENOMBRE());
//        sb.append(", CODE_IDIOMA=").append(value.getCODEIDIOMA());
//        sb.append(", COSW_PERMISOS=").append(value.getCOSWPERMISOS());
//        sb.append(", COSW_PER_SUBORDINADO=").append(value.getCOSWPERSUBORDINADO());
//        sb.append(", COID_USUARIO_BAJA=").append(value.getCOIDUSUARIOBAJA());
//        sb.append(", COID_ENCUESTA=").append(value.getCOIDENCUESTA());
//        sb.append(", COID_CES=").append(value.getCOIDCES());
//        sb.append(", COFC_FECHA_ALTA=").append(value.getCOFCFECHAALTA());
//        sb.append(", COID_USUARIO_ALTA=").append(value.getCOIDUSUARIOALTA());
//        sb.append(", COFC_FECHA_MODIF=").append(value.getCOFCFECHAMODIF());
//        sb.append(", COID_USUARIO_MODIF=").append(value.getCOIDUSUARIOMODIF());
//        sb.append(", COFC_FECHA_BAJA=").append(value.getCOFCFECHABAJA());
        sb.append('}');
        return sb.toString();
    }
}

