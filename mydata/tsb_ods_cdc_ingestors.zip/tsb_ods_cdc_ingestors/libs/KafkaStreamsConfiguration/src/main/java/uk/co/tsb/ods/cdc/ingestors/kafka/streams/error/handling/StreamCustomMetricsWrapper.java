package uk.co.tsb.ods.cdc.ingestors.kafka.streams.error.handling;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import uk.co.tsb.ods.cdc.ingestors.micrometer.StreamCustomMetrics;


public class StreamCustomMetricsWrapper implements ApplicationContextAware {

    private static final Logger log = LoggerFactory.getLogger(StreamCustomMetricsWrapper.class);

    private static StreamCustomMetrics streamCustomMetrics;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        if (applicationContext.containsBean(StreamCustomMetrics.class.getName())) {
            this.streamCustomMetrics = (StreamCustomMetrics) applicationContext.getBean(StreamCustomMetrics.class.getName());
        } else {
            log.error("Could not get StreamCustomMetrics bean. No exception metrics will be available.");
        }
    }

    public static void countProductionExceptions() {
        if (streamCustomMetrics != null) {
            streamCustomMetrics.countProductionExceptions();
        } else {
            log.warn("StreamCustomMetrics bean is null. No exception metrics will be sent.");
        }
    }

    public static void countDeserializationExceptions() {
        if (streamCustomMetrics != null) {
            streamCustomMetrics.countDeserializationExceptions();
        } else {
            log.warn("StreamCustomMetrics bean is null. No exception metrics will be sent.");
        }
    }
}
