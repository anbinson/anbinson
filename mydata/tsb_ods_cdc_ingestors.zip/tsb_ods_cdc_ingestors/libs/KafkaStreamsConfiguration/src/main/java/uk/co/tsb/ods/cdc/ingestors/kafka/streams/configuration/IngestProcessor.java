package uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration;

import org.apache.kafka.streams.kstream.KStream;
import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;

public interface IngestProcessor {

    String INPUT = "input";
    String OUTPUT = "output";

    @Input(INPUT)
    KStream inputStream();

    @Output(OUTPUT)
    KStream outputStream();
}
