package uk.co.tsb.ods.cdc.ingestors.kafka.streams.keys;

import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Collectors;

public class KeyGenerator {
    private static final String KEY_SEPARATOR = ":";

    public String getPrivateTopicKey(String CODENTID, String TIPPRODUCT, Long CODCONTRAT) {
        return joinValidValues(CODENTID, TIPPRODUCT, CODCONTRAT);
    }

    public String getTbbvAliasPrivateTopicKey(String CODENTID, String TIPPRODUCT, String CODCONTRAT, Long DASUSER) {
        return joinValidValues(CODENTID, TIPPRODUCT, CODCONTRAT, DASUSER);
    }

    public String getPrivateTopicKey(Object... objects) {
        return joinValidValues(objects);
    }

    /**
     * Takes an array of objects, filters out nulls and converts them to String.
     */
    private String joinValidValues(Object... objects) {
        return Arrays.stream(objects)
                .filter(Objects::nonNull)
                .map(String::valueOf)
                .filter(val -> !StringUtils.isEmpty(val))
                .collect(Collectors.joining(KEY_SEPARATOR));
    }
}
