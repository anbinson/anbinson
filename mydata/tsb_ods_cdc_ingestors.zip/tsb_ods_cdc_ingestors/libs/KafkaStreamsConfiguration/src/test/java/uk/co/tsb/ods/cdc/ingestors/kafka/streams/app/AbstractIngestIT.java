package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;
//
//import io.confluent.kafka.streams.serdes.avro.SpecificAvroDeserializer;
//import io.confluent.kafka.streams.serdes.avro.SpecificAvroSerde;
//import org.apache.avro.specific.SpecificRecordBase;
//import org.apache.kafka.clients.consumer.Consumer;
//import org.apache.kafka.clients.consumer.ConsumerConfig;
//import org.apache.kafka.common.serialization.StringDeserializer;
//import org.apache.kafka.common.serialization.StringSerializer;
//import org.junit.After;
//import org.junit.Before;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
//import org.springframework.kafka.core.DefaultKafkaProducerFactory;
//import org.springframework.kafka.test.EmbeddedKafkaBroker;
//import org.springframework.kafka.test.utils.KafkaTestUtils;
//
//import java.util.Map;
//
//public abstract class AbstractIngestIT<IN extends SpecificRecordBase, OUT extends SpecificRecordBase> {
//
//	protected static final Logger log = LoggerFactory.getLogger(AbstractIngestIT.class);
//
//	//@Autowired
//	//private EmbeddedKafkaBroker embeddedKafkaBroker;
//
//	@Value("${kafka.inputTopic}")
//	protected String kafkaInputTopic;
//
//	@Value("${kafka.outputTopic}")
//	protected String kafkaOutputTopic;
//
//	protected Consumer<String, OUT> consumer;
//	protected DefaultKafkaConsumerFactory<String, OUT> cf;
//	protected DefaultKafkaProducerFactory<String, IN> pf;
//
//	@Before
//	public void setUp() throws Exception {
//
//		//Map<String, Object> consumerProps = KafkaTestUtils.consumerProps("group", "false", embeddedKafkaBroker);
//		Map<String, Object> consumerProps = KafkaTestUtils.consumerProps("localhost:9092","group", "false");
//
//		consumerProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
//		consumerProps.put("specific.avro.reader", true);
//		consumerProps.put("schema.registry.url", "http://schema-registry:8081");
//
//		SpecificAvroSerde specificAvroSerde = getSpecificAvroSerde();
//
//		SpecificAvroDeserializer specificAvroDeserializer = (SpecificAvroDeserializer) specificAvroSerde.deserializer();
//		specificAvroDeserializer.configure(consumerProps, false);
//
//
//		      cf = new DefaultKafkaConsumerFactory(
//                consumerProps,
//                new StringDeserializer(),
//                specificAvroDeserializer
//        );
//
//		// Map<String, Object> producerProps = KafkaTestUtils.producerProps(embeddedKafkaBroker);
//		Map<String, Object> producerProps = KafkaTestUtils.producerProps("localhost:9092");
//		producerProps.put("schema.registry.url", "localhost:8081");
//		pf = new DefaultKafkaProducerFactory(
//				producerProps,
//				new StringSerializer(),
//				specificAvroSerde.serializer()
//				);
//
//		consumer = cf.createConsumer();
//		//embeddedKafkaBroker.consumeFromAnEmbeddedTopic(consumer, kafkaOutputTopic);
//	}
//
//	/*
//    @After
//    public void tearDown() {
//        consumer.close();
//        //embeddedKafkaBroker.destroy();
//    }*/
//
//	protected abstract SpecificAvroSerde getSpecificAvroSerde();
//}
//
//
///*package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;

import io.confluent.kafka.streams.serdes.avro.SpecificAvroDeserializer;
import io.confluent.kafka.streams.serdes.avro.SpecificAvroSerde;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.After;
import org.junit.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.utils.KafkaTestUtils;

import java.util.Map;

public abstract class AbstractIngestIT<IN extends SpecificRecordBase, OUT extends SpecificRecordBase> {

    protected static final Logger log = LoggerFactory.getLogger(AbstractIngestIT.class);

    @Autowired
    private EmbeddedKafkaBroker embeddedKafkaBroker;

    @Value("${kafka.inputTopic}")
    protected String kafkaInputTopic;

    @Value("${kafka.outputTopic}")
    protected String kafkaOutputTopic;

    protected Consumer<String, OUT> consumer;
    protected DefaultKafkaConsumerFactory<String, OUT> cf;
    protected DefaultKafkaProducerFactory<String, IN> pf;

    @Before
    public void setUp() throws Exception {

        Map<String, Object> consumerProps = KafkaTestUtils.consumerProps("group", "false", embeddedKafkaBroker);
        consumerProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        consumerProps.put("specific.avro.reader", true);
        consumerProps.put("schema.registry.url", "http://fake:8081");

        SpecificAvroSerde specificAvroSerde = getSpecificAvroSerde();

        SpecificAvroDeserializer specificAvroDeserializer = (SpecificAvroDeserializer) specificAvroSerde.deserializer();
        specificAvroDeserializer.configure(consumerProps, false);


        cf = new DefaultKafkaConsumerFactory(
                consumerProps,
                new StringDeserializer(),
                specificAvroDeserializer
        );

        Map<String, Object> producerProps = KafkaTestUtils.producerProps(embeddedKafkaBroker);
        pf = new DefaultKafkaProducerFactory(
                producerProps,
                new StringSerializer(),
                specificAvroSerde.serializer()
        );

        consumer = cf.createConsumer();
        embeddedKafkaBroker.consumeFromAnEmbeddedTopic(consumer, kafkaOutputTopic);
    }


    @After
    public void tearDown() {
        consumer.close();
        embeddedKafkaBroker.destroy();
    }

    protected abstract SpecificAvroSerde getSpecificAvroSerde();
}