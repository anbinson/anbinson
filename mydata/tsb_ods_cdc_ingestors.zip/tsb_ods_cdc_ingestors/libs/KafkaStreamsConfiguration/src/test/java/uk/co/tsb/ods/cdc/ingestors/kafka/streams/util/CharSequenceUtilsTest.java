package uk.co.tsb.ods.cdc.ingestors.kafka.streams.util;

import org.junit.Test;

import static org.junit.Assert.*;

public class CharSequenceUtilsTest {

    @Test
    public void shouldExtractValFromCDCJson() {
        // given
        String cdcJson = "{\"string\":\"DV 20004\"}";

        // when
        String result = CharSequenceUtils.extractValFromCDCJson(cdcJson);

        // then
        assertEquals("DV 20004", result);
    }

    @Test
    public void shouldPassValFromInvalidCDCJson() {
        // given
        String cdcJson = "invalid json";

        // when
        String result = CharSequenceUtils.extractValFromCDCJson(cdcJson);

        // then
        assertEquals(cdcJson, result);
    }

    @Test
    public void shouldPassValFromInvalidCDCJsonStartingWith2() {
        // given
        String cdcJson = "2 YR BOND FANCY ACCOUNT";

        // when
        String result = CharSequenceUtils.extractValFromCDCJson(cdcJson);

        // then
        assertEquals(cdcJson, result);
    }

}