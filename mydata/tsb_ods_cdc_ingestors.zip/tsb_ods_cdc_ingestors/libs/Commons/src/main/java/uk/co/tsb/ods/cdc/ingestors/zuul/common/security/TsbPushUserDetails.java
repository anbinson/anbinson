package uk.co.tsb.ods.cdc.ingestors.zuul.common.security;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;

public class TsbPushUserDetails implements UserDetails {

    private final String userId;
    private final String deviceId;
    private final Collection<GrantedAuthority> authorities;

    public TsbPushUserDetails(String userId, String deviceId, Collection<GrantedAuthority> authorities) {
        this.userId = userId;
        this.authorities = authorities;
        this.deviceId = deviceId;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
        return "";
    }

    @Override
    public String getUsername() {
        return userId;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getUserId() {
        return userId;
    }
}
