package uk.co.tsb.ods.cdc.ingestors.zuul.common.util;

public interface TsbPushConstants {

     String ROLE = "ROLE_";
     String MOBILE_USER = "MOBILE_USER";

     String SUB_JWT_CLAIM_KEY = "sub";
     String DEVICE_ID_JWT_CLAIM_KEY = "deviceid";
     String AUD_JWT_CLAIM_KEY = "aud";
     String ISS_JWT_CLAIM_KEY = "iss";
     String IAT_JWT_CLAIM_KEY = "iat";
     String EXP_JWT_CLAIM_KEY = "exp";
     String NBF_JWT_CLAIM_KEY = "nbf";

     String CLAIM_USER_ID_HEADER = "claim-user-id";
     String CLAIM_DEVICE_ID_HEADER = "claim-device-id";
    
}

