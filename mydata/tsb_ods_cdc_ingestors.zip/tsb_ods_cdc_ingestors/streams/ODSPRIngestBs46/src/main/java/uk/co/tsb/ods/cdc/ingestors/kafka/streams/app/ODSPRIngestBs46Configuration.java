package uk.co.tsb.ods.cdc.ingestors.kafka.streams.app;


import avro.util.ToStringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.messaging.handler.annotation.SendTo;

import com.tsb.ods.stream.schema.avro.BS4600.BS46TransactionType;

import uk.co.tsb.cdc.bs4600.CDCTablebs4600;
import uk.co.tsb.cdc.utils.CdcToStringUtils;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.EnableKafkaStreamsConfiguration;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.configuration.IngestProcessor;
import uk.co.tsb.ods.cdc.ingestors.kafka.streams.keys.KeyGenerator;
import uk.co.tsb.ods.cdc.ingestors.micrometer.EnableStreamMetricsConfiguration;
import uk.co.tsb.ods.cdc.ingestors.micrometer.StreamCustomMetrics;

import static uk.co.tsb.ods.cdc.ingestors.kafka.streams.util.CharSequenceUtils.safeToString;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;


@Slf4j
@Configuration
@EnableBinding(IngestProcessor.class)
@EnableKafkaStreamsConfiguration
@EnableStreamMetricsConfiguration
@PropertySource(value = "classpath:application.yml")
public class ODSPRIngestBs46Configuration {

	@Autowired
	private KeyGenerator keyGenerator;

	@Autowired
	private StreamCustomMetrics metrics;
	
	@Autowired
	private Environment environment;

	/* public static LocalDateTime datetime(CharSequence charSequence) {
    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
		LocalDateTime dateTime = LocalDateTime.parse(charSequence, formatter);
		CharSequence dateTime1 = dateTime.getMonthValue().
		return dateTime;
    }*/
	public static CharSequence datetime(CharSequence string) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
		LocalDateTime dateTime = LocalDateTime.parse(string, formatter);
		CharSequence dateSequence;
		if(Integer.parseInt(String.valueOf(dateTime.getMonthValue()))<10){
			dateSequence = String.valueOf(dateTime.getYear())+"0"+String.valueOf(dateTime.getMonthValue());
		}
		else {
			dateSequence = String.valueOf(dateTime.getYear())+String.valueOf(dateTime.getMonthValue());
		}
		return dateSequence;
	}

	@StreamListener(IngestProcessor.INPUT)
	@SendTo(IngestProcessor.OUTPUT)
	public KStream<String, BS46TransactionType> process(KStream<String, CDCTablebs4600> rawData) {
		Date date = new Date();
		Timestamp ts = new Timestamp(date. getTime());
		return rawData.peek((key, value) -> {
			metrics.countMsgIn();
			if (log.isDebugEnabled()) {
				log.debug("Consuming {}",CdcToStringUtils.toString(value));
			}
		})
				.map((key, bs46) -> {
					BS46TransactionType BS46TransactionType= null;
					String newKey= null;
					if(bs46.getAfterImage()!=null) {
						BS46TransactionType = BS46TransactionType.newBuilder()
								.setCODCOMOP(safeToString(safeToString(bs46.getAfterImage().getBS4600CODCOMOP())))
								.setDESCOMOP(safeToString(safeToString(bs46.getAfterImage().getBS4600DESCOMOP())))
								.setCODCOMUN(safeToString(safeToString(bs46.getAfterImage().getBS4600CODCOMUN())))
								.setIDIOMA(safeToString(safeToString(bs46.getAfterImage().getBS4600IDIOMA())))
								.setREDUCIDO(safeToString(safeToString(bs46.getAfterImage().getBS4600REDUCIDO())))
								.setATCREATIONTIME(safeToString(ts.toString()))
								.setATCREATIONUSER(safeToString(environment.getProperty("ATCREATIONUSER")))								
								.setATLASTMODIFIEDTIME("")
								.setATLASTMODIFIEDTIME("")
								.setXXCHECKSUM(safeToString(String.valueOf(bs46.getAfterImage().hashCode())))
								.setEXECTYPE("UPSERT")
								.build();

						newKey = keyGenerator.getPrivateTopicKey(BS46TransactionType.getCODCOMOP());
					}
					if(bs46.getAfterImage()==null) {
						BS46TransactionType = BS46TransactionType.newBuilder()
								.setCODCOMOP(safeToString(safeToString(bs46.getAfterImage().getBS4600CODCOMOP())))                                
								.setEXECTYPE("DELETE")
								.build();
						newKey = keyGenerator.getPrivateTopicKey(BS46TransactionType.getCODCOMOP());
					}
					return new KeyValue<>(newKey, BS46TransactionType);
				})
				.peek((key, value) -> {
					metrics.countMsgOut();
					if (log.isInfoEnabled()) {
						log.info("Producing {}", ToStringUtils.toString(value));
					}
				});
	}

}
