package com.tsb.ods.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import com.tsb.ods.stream.schema.avro.BS4600.BS46TransactionType;

import lombok.extern.apachecommons.CommonsLog;


@Service
@CommonsLog(topic = "Consumer Logger")
public class ConsumerClass {

	@Value("${topic.name}")
	private String topicName;

	@KafkaListener(topics = "testtransaction2", groupId = "testtransaction2")
	public void consume(ConsumerRecord<String, BS46TransactionType> record, Acknowledgment acknowledgment) {
		System.out.println(topicName);
		log.info(String.format("Consumed message -> %s", record.value()));
		BS46TransactionType bsobj = record.value();
		System.out.println("bsobj data"
				+ "----"+ bsobj.getCODCOMOP());
		if (acknowledgment != null) {
			System.out.println("Acknowledgment provided");
			acknowledgment.acknowledge();
		}
	}

}
