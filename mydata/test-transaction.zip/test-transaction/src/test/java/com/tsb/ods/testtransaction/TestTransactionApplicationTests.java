package com.tsb.ods.testtransaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestTransactionApplicationTests {

	@Test
	void contextLoads() {
	}

}
