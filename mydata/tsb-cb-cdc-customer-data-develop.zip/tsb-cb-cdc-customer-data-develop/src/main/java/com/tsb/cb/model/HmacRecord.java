package com.tsb.cb.model;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(value = "hmac")
@Data
@Builder
public class HmacRecord {
    @PrimaryKey("hmac")
    private String hmac;

    @Column("hmac_created_at")
    private String hmacCreatedAt;
    @Column("user_id")
    private String userId;
    @Column("device_id")
    private String deviceId;
}
