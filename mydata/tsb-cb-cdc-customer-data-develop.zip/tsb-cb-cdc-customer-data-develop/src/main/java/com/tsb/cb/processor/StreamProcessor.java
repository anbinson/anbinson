//package com.tsb.cb.processor;
//
//import com.tsb.cb.model.HmacRecord;
//import com.tsb.cb.model.UserRecord;
//import com.tsb.cb.repository.HmacRepository;
//import com.tsb.cb.repository.UserRepository;
//import com.tsb.cb.stream.schema.CustomerWriteHmacRequest;
//
//import io.micrometer.core.instrument.Counter;
//import io.micrometer.core.instrument.MeterRegistry;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.apache.kafka.streams.kstream.KTable;
//import org.slf4j.MDC;
//import org.springframework.context.annotation.Bean;
//import org.springframework.stereotype.Service;
//
//import java.util.function.Consumer;
//
//import javax.annotation.PostConstruct;
//
//@Slf4j
//@Service
//@RequiredArgsConstructor
//public class StreamProcessor {
//
//    private final UserRepository userRepository;
//    private final HmacRepository hmacRepository;
//    private final MeterRegistry meterRegistry;
//    
//    private Counter usersInCounter;
//    private Counter usersOutCounter;
//
//    @PostConstruct
//    public void init() {
//    	log.info("Create and register metric counters with Meter registry");
//
//    	
//    	usersInCounter = Counter.builder("tsbcb_cdc_users_in_total")
//									.description("Total number of input users since process start")
//									.register(meterRegistry);
//    	usersOutCounter = Counter.builder("tsbcb_cdc_users_out_total")
//									.description("Total number of output users since process start")
//									.register(meterRegistry);
//   
// 	
//    }
//   
//
//    /**
//     * Consume customer hmac stream and store it in scylladb
//     *
//     * @return a stream of customer data
//     */
//    @Bean
//    public Consumer<KTable<String, CustomerWriteHmacRequest>> processHmacsStream() {
//        return input -> input
//                .toStream()
//                // filter (and trace) messages
//                .filter((k, hmac) -> {
//                    MDC.put("XRequestId", hmac == null ? "" : hmac.getXRequestId());
//                    log.debug("Received a message from CustomerWriteHmacRequest");
//                    return hmac != null &&
//                            StringUtils.isNotBlank(hmac.getUserId()) &&
//                            StringUtils.isNotBlank(hmac.getHmac()) &&
//                            StringUtils.isNotBlank(hmac.getHmacCreatedAt());
//                })
//                .foreach((k, hmac) -> {
//                    // store the hmac in db
//                    if (userRepository.existsById(hmac.getUserId())) {
//                        userRepository.updateHmac(hmac.getHmac(),
//                                hmac.getHmacCreatedAt(),
//                                hmac.getDeviceId(),
//                                hmac.getUserId());
//                        hmacRepository.save(HmacRecord.builder()
//                                .hmac(hmac.getHmac()))
//                                .hmacCreatedAt(hmac.getHmacCreatedAt())
//                                .userId(hmac.getUserId())
//                                .deviceId(hmac.getDeviceId()).build());
//                        log.debug("HMAC stored in Scylladb");
//                    } else {
//                        log.error("Error: HMAC could not be stored in Scylladb. User doesn't exist");
//                    }
//                });
//    }
//
//
//}
